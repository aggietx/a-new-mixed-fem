% nx=4;ny=nx;Lx=1;Ly=1;
%% initial mesh 1/4
Nx=4;Ny=Nx;n2=nx/Nx;n1=ny/Ny;
disp('parallelogram mesh')
    [xp,yp]=meshgrid(0:Lx/Nx:Lx,0:Ly/Ny:Ly);
    for i=1:Nx+1
        for j=1:Ny+1
     x0=xp(j,i);y0=yp(j,i);

    xp(j,i) = x0 + .03*cos(3*pi*x0)*cos(3*pi*y0);
    yp(j,i) = y0 - .04*cos(3*pi*x0)*cos(3*pi*y0);
        end
    end
if nx==Nx

else

    if 1
        
rl=log2(nx/Nx);
for il=1:rl
    nyo=Ny*2^(il-1);nxo=Nx*2^(il-1);%%% previous mesh size
    xp1=zeros(nyo*2+1,nxo*2+1);
    yp1=zeros(nyo*2+1,nxo*2+1);
    for i=1:nxo
        for j=1:nyo
        x1=xp(j,i);x2=xp(j+1,i); x3=xp(j,i+1);x4=xp(j+1,i+1);
        y1=yp(j,i);y2=yp(j+1,i); y3=yp(j,i+1);y4=yp(j+1,i+1);
    
        % [xpi,ypi]=uiformpartition2d_quad(2,2,x1,y1,x2,y2,x3,y3,x4,y4);
        [xpi,ypi]=refinequad2d(x1,y1,x2,y2,x3,y3,x4,y4);
        yp1(j*2-1:j*2+1,i*2-1:i*2+1)=ypi;
        xp1(j*2-1:j*2+1,i*2-1:i*2+1)=xpi;
        end
    end
    xp=xp1;
    yp=yp1;
end
    
% mesh(xp,yp,zeros(ny+1,nx+1));
    

    else
        
    [xpc,ypc]=meshgrid(0:Lx/Nx:Lx,0:Ly/Ny:Ly);
 for i=1:Nx+1
    for j=1:Ny+1
     x0=xpc(j,i);y0=ypc(j,i);

  xpc(j,i) = x0 + .03*cos(3*pi*x0)*cos(3*pi*y0);
 ypc(j,i) = y0 - .03*cos(3*pi*x0)*cos(3*pi*y0);
    end
 end
xp=zeros(ny+1,nx+1);
yp=zeros(ny+1,nx+1);
  for i=1:Nx
    for j=1:Ny
        x1=xpc(j,i);x2=xpc(j+1,i); x3=xpc(j,i+1);x4=xpc(j+1,i+1);
        y1=ypc(j,i);y2=ypc(j+1,i); y3=ypc(j,i+1);y4=ypc(j+1,i+1);
        [xpi,ypi]=uiformpartition2d_quad(n1,n2,x1,y1,x2,y2,x3,y3,x4,y4);

        xp( (j-1)*n1+1:j*n1+1,(i-1)*n2+1:i*n2+1 )=xpi;
        yp( (j-1)*n1+1:j*n1+1,(i-1)*n2+1:i*n2+1 )=ypi;
    end
  end
    end
  % mesh(xp,yp,zeros(ny+1,nx+1));
end

