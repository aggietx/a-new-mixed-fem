%%%% basis are the same as rt0, all vector basis are (1,0) or (0,1), no
%%%% negative, block diagonal
clear;
close all

nx=32*2;ny=nx;ne=nx*ny;nvet=2*ny*(nx+1);nhor=2*nx*(ny+1);nvdof=nvet+nhor;nedge=ny*(nx+1)+nx*(ny+1);
Lx=1;Ly=1;hx=Lx/nx;hy=Ly/ny;vol=hx*hy;np=(nx+1)*(ny+1);

[edge_hor,edge_vec,nodedof] = getedgedof(ny,nx);
nodv=zeros(16,ne);

poission_ratio=0.1;
% load k1;young_modulus=k1;
young_modulus=1*ones(ny,nx);% % depends on x
lambda=poission_ratio/((1+poission_ratio)*(1-2*poission_ratio))*young_modulus;
mu=1/2/(1+poission_ratio)*young_modulus;
lambda=lambda(:);mu=mu(:);

s=lambda(1,1);t=mu(1,1);
lambda_bar=-lambda./(4*mu.*(lambda+mu));
mu_bar=1/2./(mu);
lambdabar_mubar=lambda_bar+mu_bar;
%% (As,s) matrix
ir1=zeros(16^2,ne);
ic1=zeros(16^2,ne);
localA12=zeros(16,16);
localA12(1,10)=1;localA12(3,12)=1;localA12(5,14)=1;localA12(7,16)=1;
localA12(10,1)=1;localA12(12,3)=1;localA12(14,5)=1;localA12(16,7)=1;
localA11a=zeros(16,16);localA11b=zeros(16,16);localA22a=zeros(16,16);localA22b=zeros(16,16);

for i=1:2:7;localA11a(i,i)=1;end
for i=[9,11,13,15];localA11b(i,i)=1;end
for i=2:2:8;localA22a(i,i)=1;end
for i=[10,12,14,16];localA22b(i,i)=1;end

nodedge=zeros(16,ne);
id=1;
for i=1:nx
    for j=1:ny
        dof1=edge_vec(j*2-1,i);dof2=edge_vec(j*2,i); dof3=edge_vec(j*2-1,i+1);dof4=edge_vec(j*2,i+1);
        dof5=edge_hor(j,i*2-1);dof6=edge_hor(j+1,i*2-1);dof7=edge_hor(j,i*2);dof8=edge_hor(j+1,i*2);
localedof=[dof1*2-1:dof1*2,dof2*2-1:dof2*2,dof3*2-1:dof3*2,dof4*2-1:dof4*2,dof5*2-1:dof5*2,dof6*2-1:dof6*2,dof7*2-1:dof7*2,dof8*2-1:dof8*2]';
nodedge(:,id)=localedof;
ir1(:,id)=repmat(localedof,16,1);
temp=repmat(localedof,1,16);temp=temp';ic1(:,id)=temp(:);
id=id+1;
    end
end

Ass=sparse(ir1,ic1,localA11a(:)*lambdabar_mubar'*vol/4+localA11b(:)*mu_bar'*vol/4+...
                     1*localA12(:)*lambda_bar'*vol/4+...
                     localA22a(:)*mu_bar'*vol/4+localA22b(:)*lambdabar_mubar'*vol/4);
% spy(Ass)
invAss_local=cell(np,1);
id=0;
for i=1:np
localdof=nodedof(:,i);ndof=length(find(localdof))*2;

invAss_local{i}=inv(Ass(id+1:id+ndof,id+1:id+ndof));
id=id+ndof;
end
invAss=blkdiag(invAss_local{:});


%% 
localsp=zeros(16,2);
localsp([1,3,5,7,9,11,13,15],1)=[-1,-1,1,1,-1,1,-1,1]'*hx/2;
localsp([2,4,6,8,10,12,14,16],2)=[-1,-1,1,1,-1,1,-1,1]'*hx/2;


ir=zeros(16*2,ne);
ic=zeros(16*2,ne);
id=1;
for i=1:nx
    for j=1:ny
localedof=nodedge(:,id); ir(:,id)=repmat(localedof,2,1);
localudof=[id,id+ne];localudof=localudof(:);temp=repmat(localudof,1,16);temp=temp';ic(:,id)=temp(:);

id=id+1;
    end
end
Asu=sparse(ir,ic,repmat(localsp(:),1,ne));
% return
%% 
localsr=zeros(16,4);
localsr(9,1)=-1;localsr(11,2)=-1;localsr(13,3)=-1;localsr(15,4)=-1;
localsr(2,1)=1;localsr(4,2)=1;localsr(6,3)=1;localsr(8,4)=1;

localsr=localsr*vol/4;
allrdof=reshape(1:(nx+1)*(ny+1),ny+1,nx+1);
ir=zeros(16*4,ne);
ic=zeros(16*4,ne);
id=1;
for i=1:nx
    for j=1:ny
localedof=nodedge(:,id); ir(:,id)=repmat(localedof,4,1);
localrdof=allrdof(j:j+1,i:i+1);localrdof=localrdof(:);temp=repmat(localrdof,1,16);temp=temp';ic(:,id)=temp(:);

id=id+1;
    end
end
Ars=sparse(ir,ic,repmat(localsr(:),1,ne));


A=[Ass, Ars,Asu;
   Ars',sparse(np,2*ne+np);
   Asu',sparse(2*ne,2*ne+np)];
%% solve
% return
f1 =@(x,y) -(4*(s+t)*pi^2*cos(2*pi*x).*cos(2*pi*y)-4*(s+3*t)*pi^2*sin(2*pi*x).*sin(2*pi*y));
[xe,ye]=meshgrid(hx/2:hx:Lx-hx/2,hy/2:hy:Ly-hy/2);F1=f1(xe(:),ye(:));
F=zeros(2*ne+2*nvdof+np,1);
F(2*nvdof+1+np:2*nvdof+2*ne+np)=-1*vol;
F(2*nvdof+1+np:2*nvdof+2*ne+np)=-[F1;1*F1]*vol;

% 

% Aaug1=A(1:nvdof*2,nvdof*2+1:end);D=sparse(np+2*ne,np+2*ne);[Aeli,Feli,u1,uf]=eli(invAss,Aaug1,D,F);rnorm(u,uf);
% invArr=sparse(1:np,1:np,1./diag(Aeli(1:np,1:np)));D=Aeli(np+1:end,np+1:end); Aaug=Aeli(1:np,np+1:end);[Aeli0,Feli0,u0,uf0]=eli(invArr,Aaug,D,Feli);rnorm(uf0,u1);

if 1
    
u=A\F;uu=u(2*nvdof+1+np:2*nvdof+2*ne+np);%rnorm(u0,uu);
else
    %Aaug1=A(1:nvdof*2,nvdof*2+1:end);
    Aaug1=[Ars,Asu];D=sparse(np+2*ne,np+2*ne);[Aeli,Feli]=eli_matrix(invAss,Aaug1,D,F);
invArr=sparse(1:np,1:np,1./diag(Aeli(1:np,1:np)));D=Aeli(np+1:end,np+1:end); Aaug=Aeli(1:np,np+1:end);[Aeli0,Feli0,u0,uf0]=eli(invArr,Aaug,D,Feli);

uf=zeros(2*nvdof+2*ne+np,1);uf(2*nvdof+1:end)=uf0;uf(1:2*nvdof)=-invAss*Aaug1*uf0;
u=uf;
end
% Aeli=-(Asrp'*invAss)*Asrp;
% Feli=F(2*nvdof+1:end);
% u1=Aeli\Feli;uf=zeros(size(u));uf(2*nvdof+1:end)=u1;uf(1:2*nvdof)=-invAss*Asrp*u1;

% imagescsquare(u(2*nvdof+1:2*nvdof+ne))

%% post
u1_exact_f=@(x,y) sin(2*pi*x).*sin(2*pi*y);ue=u1_exact_f(xe(:),ye(:));
u2_exact_f=@(x,y) sin(2*pi*x).*sin(2*pi*y);

[xe,ye]=meshgrid(hx/2:hx:Lx-hx/2,hy/2:hy:Ly-hy/2);
u1_exact=@(x,y) sin(2*pi*x).*sin(2*pi*y);ue1=u1_exact(xe(:),ye(:));
u2_exact=@(x,y) sin(2*pi*x).*sin(2*pi*y);ue2=u2_exact(xe(:),ye(:));
cigma_11_f=@(x,y) (s+2*t)*2*pi*cos(2*pi*x).*sin(2*pi*y)+s*2*pi*sin(2*pi*x).*cos(2*pi*y);
cigma_12_f=@(x,y) 2*t*pi*cos(2*pi*y).*sin(2*pi*x)+2*t*pi*sin(2*pi*y).*cos(2*pi*x);
cigma_22_f=@(x,y) (s+2*t)*2*pi*sin(2*pi*x).*cos(2*pi*y)+s*2*pi*cos(2*pi*x).*sin(2*pi*y);
cigma_21_f=cigma_12_f;
ua1=u(2*nvdof+1+np:2*nvdof+ne+np);
ua2=u(2*nvdof+1+ne+np:2*nvdof+2*ne+np);
rnorm(sqrt(ua1.^2+ua2.^2),sqrt(ue1.^2+ue2.^2));

imagescsquare1(ue1);title('exact u1');imagescsquare1(u(2*nvdof+1:2*nvdof+ne));title('app u1');
% imagescsquare1(ue2);title('exact u2');imagescsquare1(u(2*nvdof+1+ne:2*nvdof+2*ne));title('app u2');

% return
s11e=zeros(ne,1);s11a=zeros(ne,1);
s12e=zeros(ne,1);s12a=zeros(ne,1);
s21e=zeros(ne,1);s21a=zeros(ne,1);
s22e=zeros(ne,1);s22a=zeros(ne,1);
id=1;
for i=1:nx
    for j=1:ny
localsdof=nodedge(:,id);
locals=u(localsdof);
y1=(j-1)*hy+hy/4;x1=(i-1)*hx+hx/4;
y2=(j-1)*hy+3*hy/4;x2=x1;
y3=y1;x3=(i-1)*hx+3*hx/4;
y4=y2;x4=x3;

s11e(id)=(cigma_11_f(x1,y1)+cigma_11_f(x2,y2)+cigma_11_f(x3,y3)+cigma_11_f(x4,y4));s11a(id)=(locals(1)+locals(3)+locals(5)+locals(7));
s12e(id)=(cigma_12_f(x1,y1)+cigma_12_f(x2,y2)+cigma_12_f(x3,y3)+cigma_12_f(x4,y4));s12a(id)=(locals(9)+locals(11)+locals(13)+locals(15));
s21e(id)=(cigma_21_f(x1,y1)+cigma_21_f(x2,y2)+cigma_21_f(x3,y3)+cigma_21_f(x4,y4));s21a(id)=(locals(2)+locals(4)+locals(6)+locals(8));
s22e(id)=(cigma_22_f(x1,y1)+cigma_22_f(x2,y2)+cigma_22_f(x3,y3)+cigma_22_f(x4,y4));s22a(id)=(locals(10)+locals(12)+locals(14)+locals(16));

        id=id+1;
    end
end
rnorm(s11a,s11e);
rnorm(s12a,s12e);
rnorm(s21a,s21e);
rnorm(s22a,s22e);

% norm(s12a-s21a)
% figure();plot(u(2*nvdof+2*ne+1:end))
% figure();plot(s12a-s21a)
% figure();plot(s21a-s21e)
% norm(u(2*nvdof+2*ne+1:end))
imagescsquare(s12e)
imagescsquare(s12a)
return
if 1
    disp('velocity elimination....')
diagAvv=fsparse(ones(size(nodv)),nodv,ones(8,1)*alpha(:)')*vol/4;diagAvv=1./diagAvv;
Aeli=-(Asu'.*diagAvv)*Asu;
F=-1*vol*ones(ne,1);
ueli=Aeli\F;
imagescsquare1(ueli)
end