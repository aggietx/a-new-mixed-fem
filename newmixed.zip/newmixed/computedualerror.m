
return
[xp,yp]=meshgrid(0:hx:Lx,0:hy:Ly);
s11p=cigma_11_f(xp,yp);s12p=cigma_12_f( xp,yp);
s21p=cigma_21_f( xe,ye);s22p=cigma_22_f( xp,yp);


s11ap=zeros(ny+1,nx+1);s12ap=zeros(ny+1,nx+1);
s21ap=zeros(ny+1,nx+1);s22ap=zeros(ny+1,nx+1);

yy=0*hy/4*ones(1,nx+1);xx=0:hx:Lx;
s11p(1,:)=cigma_11_f(xx,yy);s11p(end,:)=cigma_11_f(xx,1-yy);
svet=u(dofvet);svet=reshape(svet,2*ny,nx+1);

[xpf,ypf]=meshgrid(0:hx:Lx,hy/4:hy/2:Ly);
s11p=cigma_11_f(xpf,ypf);svet1=svet;svet1(2:2:end,:)=-svet1(2:2:end,:);
rnorm(svet1,s11p);%%%% full vs full
return
b=(svet(3:2:end,:)-svet(2:2:end-1,:))/2;
s11ap(2:end-1,:)=b;

s11ap(1,:)=svet(1,:);s11ap(end,:)=-svet(end,:);

mass=assemblemass(ny,nx,1,1,ones(ny,nx));
computeweightmasserror2d(s11ap,s11p,hx,hy,ny,nx,ones(ny,nx));
% rnorm(s11ap,s11p);
rnorm(s11ap(2:end-1,:),s11p(2:end-1,:));

a=zeros(ny+1,nx+1);b=zeros(ny+1,nx+1);
a(2:end-1,:)=s11ap(2:end-1,:);
b(2:end-1,:)=s11p(2:end-1,:);
computeweightmasserror2d(a,b,hx,hy,ny,nx,ones(ny,nx));

return
a=(s11ap(1:end-1,1:end-1)+s11ap(2:end,1:end-1)+s11ap(1:end-1,2:end)+s11ap(2:end,2:end));
b=(s11p(1:end-1,1:end-1)+s11p(2:end,1:end-1)+s11p(1:end-1,2:end)+s11p(2:end,2:end));
rnorm(a,b);
return
a=s11p(2:end-1,:);
rnorm(b,a);
return
for i=1:nx
    for j=1:ny

    end
end
return
se2=sqrt(s11p.^2+s12p.^2+s21p.^2+s22p.^2);se2=se2(:);
diff1=se-sa;diff2=se2-sa;

fprintf('ave vs center, relative error and error of stress are %2.4e %2.4e\n',norm(diff2)/norm(se2),sqrt(sum(diff2.^2)*vol) );
