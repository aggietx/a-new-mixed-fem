function [ir,ic,localsr]=assemble_Asr3d_continuous_part1(nx,ny,nz,ne,map,vol,np,nodedge)
% disp('generate stress and rotation matrix part a, continuous case...')
% tic
index1=[1,3,5,7,2,4,6,8];index2=[1,2,5,6,3,4,7,8];index3=1:8;
localsr=zeros(72,3*8);
for i=9:16;localsr(map(i),16+index2(i-8))=-1;end
for i=17:24;localsr(map(i),8+index3(i-16))=-1;end
for i=25:32;localsr(map(i),16+index1(i-24))=1;end
for i=41:48;localsr(map(i),index3(i-40))=-1;end
for i=49:56;localsr(map(i),8+index1(i-48))=1;end
for i=57:64;localsr(map(i),index2(i-56))=1;end
nzid=find(localsr(:));
localsr=localsr*vol/8;
allrdof=reshape(1:(nx+1)*(ny+1)*(nz+1),nx+1,ny+1,nz+1);


    nodnodedof0=zeros(8,ne);nodnodedof=zeros(24,ne);
id=1;
for iz=1:2
    for iy=1:2
        for ix=1:2
temp1=allrdof(ix:end-2+ix,iy:end-2+iy,iz:end-2+iz);
nodnodedof0(id,:)=temp1(:);
id=id+1;
        end
    end
end
clear temp1
nodnodedof(1:8,:)=nodnodedof0;nodnodedof(9:16,:)=nodnodedof0+np;
nodnodedof(17:24,:)=nodnodedof0+2*np;
ir=kron(nodedge,ones(1,24));ir=reshape(ir(:),72*24,ne);ir=ir(nzid,:);
ic=kron(nodnodedof,ones(72,1));

ic=ic(nzid,:);
localsr=localsr(nzid);
% Ars=sparse(ir,ic,localsr*mu_bar',3*nvdof,3*np+3*ne);

% toc