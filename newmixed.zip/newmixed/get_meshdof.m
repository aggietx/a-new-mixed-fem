function mesh_nodes=get_meshdof(nx0,ny0,p)

all_nodes=reshape(1:(p*nx0+1)*(p*ny0+1),nx0*p+1,ny0*p+1);
mesh_nodes=all_nodes(1:p:end,1:p:end);
mesh_nodes=sort(mesh_nodes(:));