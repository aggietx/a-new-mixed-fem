%%%% high contrast, continuous, local eli, dual assemble
clear;
close all
disp('generate mesh...')
nx1=8;
tg2=tic;

nx2=nx1;nx3=nx1;nx=nx1;ny=nx2;nz=nx3;
Lx1=1;Lx2=1;Lx3=1;ne=nx1*nx2*nx3;hx1=1/nx1;hx2=1/nx2;hx3=1/nx3;vol=hx1*hx2*hx3;np=(nx1+1)*(nx2+1)*(nx3+1);
nface=(nx1+1)*nx2*nx3+(nx2+1)*nx1*nx3+(nx3+1)*nx1*nx2;nvdof=4*nface;hx=hx1;hy=hx2;hz=hx3;

% return
model=6;maxvalue=10^8;nmaxbasis=10;gs=1;q0=0;eigvalue_tol=.03;tol=10^(-5);regvalue=10^(-14);
agmgsolve=0;amgclsolve=0;
twogridsolve=1;threegrid=0;if q0==1;threegrid=0;end
nmaxbasis1=30;eigvalue_tol1=2*eigvalue_tol;
Nx=8;n=nx/Nx;Ny=nz/n;Nz=nz/n;
N1=Nx;n1=nx/N1;na=Nx/N1;%% 3 level grid, 
fprintf('grid size are %d %d %d \n',nx,Nx,N1);
tg=toc(tg2);
dis=0;
fprintf('t mesh is %2.1f\n',tg);
fprintf('eigvalue tolerance are %2.3f %2.3f\n',eigvalue_tol,eigvalue_tol1);
fprintf('model is %d\n',model);
young_modulus=ones(nx,ny,nz);

poission_ratio=0.3;
lambda=poission_ratio/((1+poission_ratio)*(1-2*poission_ratio))*young_modulus;
mu=1/2/(1+poission_ratio)*young_modulus;

lambda_bar=-lambda./(2*mu.*(3*lambda+2*mu));
mu_bar=1/2./(mu);
lambdabar_mubar=lambda_bar+mu_bar;
mu_bare=zeros(nx+2,ny+2,nz+2);lambda_bare=zeros(nx+2,ny+2,nz+2);
mu_bare(2:end-1,2:end-1,2:end-1)=reshape(mu_bar,nx,ny,nz);
lambda_bare(2:end-1,2:end-1,2:end-1)=reshape(lambda_bar,nx,ny,nz);
lambda=lambda(:);mu=mu(:);
% mu_bare=zeros(nx+2,ny+2,nz+2);lambda_bare=zeros(nx+2,ny+2,nz+2);
% mu_bare(2:end-1,2:end-1,2:end-1)=reshape(mu_bar,nx,ny,nz);
% lambda_bare(2:end-1,2:end-1,2:end-1)=reshape(lambda_bar,nx,ny,nz);
ratio=max(young_modulus(:))/min(young_modulus(:));
fprintf('contrast is %2.1e\n',ratio );
% parfor i=1:100;i;end %%% to keep parallel toolbox alive
   
%% matrix
gx1=zeros(nx+1,2*ny+2,2*nz+2);gx2=gx1;gx3=gx1;%%%%face x
gy1=zeros(2*nx+2,ny+1,2*nz+2);gy2=gy1;gy3=gy1;%%%% face y
gz1=zeros(2*nx+2,2*ny+2,nz+1);gz2=gz1;gz3=gz1;%%%% face z
F1=ones(nx,ny,nz);F2=F1;F3=F1;
assembledual_continuous_localeli_fullneu %%% with local eli
Aeli0=Aeli0+Aeli0.';
Meig0=sparse(1:3*ne,1:3*ne,[young_modulus(:);young_modulus(:);young_modulus(:)])*vol;
[v,d]=eigs(-Aeli0,Meig0,10,'sm');
d=diag(d);
d
