function [h1,h2,h3,h4]=computesizequad(x1,y1,x2,y2,x3,y3,x4,y4)

h1=sqrt( (x2-x1)^2+(y2-y1)^2);
h2=sqrt( (x3-x4)^2+(y3-y4)^2);
h3=sqrt( (x3-x1)^2+(y3-y1)^2);
h4=sqrt( (x2-x4)^2+(y2-y4)^2);
