function model=generate_3dbbdc_model1(N,n,maxval)
%%%% model (figure 4.1) in paper "A FRUGAL FETI-DP AND BDDC COARSE SPACE
% % FOR HETEROGENEOUS PROBLEMS"


% model=generate_3dbbdc_model1(3,12,100);imagescsquare1(model(:,:,1));

if mod(n,6)~=0
disp('n must be divided by 6')
end
disp('bddc model 1')
% n0=floor(n/6);
n1=floor(n/3);
% range1=n0+1:n0+n1;range2=n0+n1+1:n0+n1+n1;
range=n1+1:n1+n1;

model=ones(n,n,n);
model(range,range,:)=maxval;

model=repmat(model,N,N,N);