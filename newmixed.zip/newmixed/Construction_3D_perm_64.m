% [X,Y,Z] = meshgrid(1:10, 1:10,1:10);
% perm=ones(10,10,10);
% perm(2:3, 8:9,:)=10;
% perm(2:8,4:5,3:4)=15;
% figure
% slice(X,Y,Z,perm,[7  8],1:2,[2,5])
% figure
% slice(X,Y,Z,perm,1:2:10,1:2:10,1:2:10)
% close all
function perm=Construction_3D_perm_64(high_k)
disp('unstructured, long and short channel')
fine_a=64;% set grid points in each direction
% high_k=10^4;% set the highest value of the permeability
% [X,Y,Z] = meshgrid(1:fine_a, 1:fine_a,1:fine_a);
perm=ones(fine_a,fine_a,fine_a);
perm(8:55, 30:33,27:30)=high_k;%1
perm(5:9, 45:48,10:55)=high_k;%2
perm(11:13, 45:48,10:55)=high_k;%3

perm(10:14, 21:26,20:55)=high_k;%4

perm(15:19, 22:28,40:60)=high_k;%5

perm(28:33, 42:47, 44:48)=high_k;%6

perm(31:34, 32:37, 44:48)=high_k;%7

perm(42:48, 12:17, 42:48)=high_k;%8

perm(50:54, 20:25, 44:50)=high_k;%9


perm(15:20, 11:15,20:25)=high_k;%10
%perm(25:35, 16:20,20:30)=high_k;
perm(36:40, 21:25,20:25)=high_k;%11

 perm(20:25, 38:43,25:30)=high_k;%12
 perm(25:30, 44:49,25:30)=high_k;%13
 %perm(30:40, 50:55,25:30)=high_k;
 perm(42:46, 42:50,25:30)=high_k;%14
 
 perm(15:25, 22:28,8:13)=high_k;%15
perm(28:33, 42:47, 9:15)=high_k;%16
perm(31:35, 42:45, 11:15)=high_k;%17

perm(42:46, 12:17, 18:23)=high_k;%18

perm(50:56, 20:25, 26:31)=high_k;%19


perm(40:45,10:50,45:50)=high_k;%20
perm(50:54,10:50,52:54)=high_k;%21

perm(40:45,10:60,15:20)=high_k;%22
%perm(46:50,10:50,7:13)=high_k;

perm(55:60,15:55,11:14)=high_k;%23
perm(15:45,10:50,11:14)=high_k;%24

perm(15:50,10:15,30:34)=high_k;%25
perm(15:50,10:15,50:54)=high_k;%26

perm(15:30,50:55,10:14)=high_k;%27
perm(15:50,50:55,10:14)=high_k;%28

%perm(35:50,56:60,30:34)=high_k;
%perm(10:25,56:60,30:34)=high_k;

perm(15:25,52:56,50:54)=high_k;%29
perm(35:50,52:56,50:54)=high_k;%30
return
save permeability perm
 
figure
slice(X,Y,Z,perm,[7  8],1:2,[2,5])
figure
imagesc(perm(:,:,25)')
figure
imagesc(perm(:,:,10)')