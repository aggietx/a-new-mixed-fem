function compute_areaerror_2d(a,b,area)
a=a(:);b=b(:);
area=area(:);
n=length(area);
if 1
w=sparse(1:n,1:n,area);
diff=a-b;
error=(diff'*w*diff)/(b'*w*b);
error=sqrt(error);
% fprintf('weight mass error and relative error are %2.4e %2.4e\n',sqrt(diff'*diff),error);
fprintf('weight mass relative error is %2.4e\n',error);
else
a=area.*a/sum(area);
b=area.*b/sum(area);


diff=a-b;

error=(diff'*diff)/(b'*b);
error=sqrt(error);
% fprintf('weight mass error and relative error are %2.4e %2.4e\n',sqrt(diff'*diff),error);
fprintf('weight mass relative error is %2.4e\n',error);
end