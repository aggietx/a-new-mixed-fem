function invAss=assemble_Ass3d_part2(lambdabar_mubar,mu_bar,lambda_bar,ir1,ic1,ne,nodedge,vol,localA12,np,nodedof)
%% (As,s) matrix
% tic
% disp('generate (As,s) matrix part b...')
id1=1:3:72;id2=2:3:72;id3=3:3:72;iv11=zeros(72,ne);iv22=zeros(72,ne);iv33=zeros(72,ne);
iv11(id1,:)=[ones(8,1)*lambdabar_mubar';ones(8,1)*mu_bar';ones(8,1)*mu_bar'];
iv22(id2,:)=[ones(8,1)*mu_bar';ones(8,1)*lambdabar_mubar';ones(8,1)*mu_bar'];
iv33(id3,:)=[ones(8,1)*mu_bar';ones(8,1)*mu_bar';ones(8,1)*lambdabar_mubar'];

iv=iv11+iv22+iv33;clear iv11 iv22 iv33



diagAssa=sparse(nodedge,ones(72,ne),iv)*vol/8;clear iv
Assb=sparse(ir1,ic1,localA12*lambda_bar'*vol/8);
Ass=diag(diagAssa)+Assb;clear Assa Assb
invAss_local=cell(np,1);
id=0;
all_localmatrix=cell(np,1);
for i=1:np
ndof=nodedof(i)*3;
all_localmatrix{i}=Ass(id+1:id+ndof,id+1:id+ndof);
id=id+ndof;
end
parfor i=1:np
invAss_local{i}=inv(all_localmatrix{i});
end
clear Ass
invAss=blkdiag(invAss_local{:});clear invAss_local
% toc
