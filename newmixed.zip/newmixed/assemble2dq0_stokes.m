
function  [phimatrix_pa]=assemble2dq0_stokes(Nx,Ny,n)


disp('generate 2d q0 stokes basis...')

nx=Nx*n;ny=Ny*n;ne=nx*ny;
basismap=3*ones(Ny,Nx);
% % kappa=K*10^6;
% nmaxbasis=2;
ts=tic;



p_dof=reshape(1:nx*ny,ny,nx);

Ncb=Nx*Ny;


 iivaluepcell=cell(Ncb,1);

 alllocal_pdof=cell(Ncb,1);

    for ii2=1:Nx
        for ii1=1:Ny
    iie=(ii2-1)*Ny+ii1;

             global_p_dof=p_dof( (ii1-1)*n+1:ii1*n,(ii2-1)*n+1:ii2*n);


alllocal_pdof{iie}=global_p_dof;

        end
    end



% np=(n+1)^2;
% [Aaug1,D,ir1,ic1,nodedof,bddof]=assemble2d_matrix_partb(n,n,h,h);
% Aaug1(bddof,:)=0;
parfor iie=1:Ny*Nx

basis=zeros(3*n^2,2);
basis(1:n^2,1)=1;basis(1+n^2:n^2*2,2)=1;
basis(1+2*n^2:n^2*3,3)=1;
       basismap(iie)=size(basis,2);

iivaluepcell{iie}=basis;

end

dim_pc=sum(basismap(:));
ixp=zeros(dim_pc,3*n^2);
ivaluep=zeros(dim_pc,3*n^2);
iyp=(1:dim_pc)'*ones(1,3*n^2);
ind=1;

    for ii2=1:Nx
        for ii1=1:Ny
    iie=(ii2-1)*Ny+ii1;
    basis=iivaluepcell{iie};
    nlocal_basis=basismap(iie);
    ivaluep(ind:ind+nlocal_basis-1,:)=basis';   
    global_p_dof=alllocal_pdof{iie};

   global_p_dof=[global_p_dof(:);global_p_dof(:)+ne;global_p_dof(:)+2*ne];
global_p_dof=sort( global_p_dof(:));

    ixp(ind:ind+nlocal_basis-1,:)= repmat( global_p_dof,1,nlocal_basis)';
ind=ind+nlocal_basis;  
        end
    end

% if max(imag(allbasis(:)))>10^(-8)
%     disp('complex eigenfunction')
% end
% return
disp('assembling coarse matrix...')
clear alllocal_pdof allbasis p_dof
 phimatrix_pa=sparse(iyp,ixp,ivaluep,dim_pc,ne*3);clear ixp iyp ivaluep
 fprintf('dim of are %d %d\n',dim_pc,3*ne);
 fprintf('average basis number is %2.2f\n',dim_pc/(Nx*Ny));
 disp('END of generating gms basis')
 tb=toc(ts);
  fprintf('Tbasis is %2.2f seconds\n',tb);