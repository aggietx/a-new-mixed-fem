function [X,Y,Z,M] = getelidof3d(x,y,z)
pointline = zeros((x+1),(y+1),(z+1));
point = cell(x+1,y+1,z+1);
a = 1;
faceX = zeros(x+1,2*y,2*z);
faceY = zeros(2*x,y+1,2*z);
faceZ = zeros(2*x,2*y,z+1);
count = 1;
for k = 1:z+1
    for j = 1:y+1
        for i = 1:x+1

            point{i,j,k} = Point3D(i,j,k,a);

            %赋值X平面
            if(k>1)&&(j>1) %y-z-
                point{i,j,k}.x1 = count;
                count = count+1;
            end
            if(k>1)&&(j<y+1) %y+z-
                point{i,j,k}.x2= count;
                count = count+1;
            end
            if(k<z+1)&&(j>1)%y-z+
                point{i,j,k}.x3 = count;
                count = count+1;
            end
            if(k<z+1)&&(j<y+1)%y+z+
                point{i,j,k}.x4 = count;
                count = count+1;
            end
            %赋值Y平面
            if(k>1)&&(i>1)%x-z-
                point{i,j,k}.y1 = count;
                count = count+1;
            end
            if(i<x+1)&&(k>1)%x+z-
                point{i,j,k}.y2 = count;
                count = count+1;
            end
            if(i>1)&&(k<z+1)%z+x-
                point{i,j,k}.y3= count;
                count = count+1;
            end
            if(k<z+1)&&(i<x+1)%x+z+
                point{i,j,k}.y4 = count;
                count = count+1;
            end

            %赋值Z平面
            if(i>1)&&(j>1)%x-y-
                point{i,j,k}.z1 = count;
                count = count+1;
            end
            if(j>1)&&(i<x+1)%x+y-
                point{i,j,k}.z2= count;
                count = count+1;
            end
            if(j<y+1)&&(i>1)%x-y+
                point{i,j,k}.z3 = count;
                count = count+1;
            end
            if(i<x+1)&&(j<y+1)%x+y+
                point{i,j,k}.z4 = count;
                count = count+1;
            end
            pointline(i,j,k) = point{i,j,k}.facenumber();
            %disp(point{i,j,k})
            a = a+1;
        end
    end
end


for k = 1:z+1
    for j = 1:y+1
        for i = 1:x+1
            
            if point{i,j,k}.x4 ~= 0
            faceX(i,2*j-1,2*k-1) = point{i,j,k}.x4;
            end
            if point{i,j,k}.x2 ~= 0
            faceX(i,2*j-1,2*k-2) = point{i,j,k}.x2;
            end
            if point{i,j,k}.x3 ~= 0
            faceX(i,2*j-2,2*k-1) = point{i,j,k}.x3;
            end
            if point{i,j,k}.x1 ~= 0
            faceX(i,2*j-2,2*k-2) = point{i,j,k}.x1;
            end
            
            if point{i,j,k}.y4 ~= 0
            faceY(2*i-1,j,2*k-1) = point{i,j,k}.y4;
            end
            if point{i,j,k}.y2 ~= 0
            faceY(2*i-1,j,2*k-2) = point{i,j,k}.y2;
            end
            if point{i,j,k}.y3 ~= 0
            faceY(2*i-2,j,2*k-1) = point{i,j,k}.y3;
            end
            if point{i,j,k}.y1 ~= 0
            faceY(2*i-2,j,2*k-2) = point{i,j,k}.y1;
            end
            
            if point{i,j,k}.z4 ~= 0
            faceZ(2*i-1,2*j-1,k) = point{i,j,k}.z4;
            end
            if point{i,j,k}.z2 ~= 0
            faceZ(2*i-1,2*j-2,k) = point{i,j,k}.z2;
            end
            if point{i,j,k}.z3 ~= 0
            faceZ(2*i-2,2*j-1,k) = point{i,j,k}.z3;
            end
            if point{i,j,k}.z1 ~= 0
            faceZ(2*i-2,2*j-2,k) = point{i,j,k}.z1;
            end

        end
    end
end
X = faceX;Y = faceY;Z = faceZ;
% A = permute(faceX, [3, 2, 1]);
% X = flipud(A);
% faceX = X
% 
% Y= permute(faceY, [1,3,2]);
% Y = flipud(rot90(Y, -1));
% faceY = Y
% Z = faceZ;
% faceZ
M = pointline;
%disp(point)