classdef Point3D
    %UNTITLED2 此处显示有关此类的摘要
    %   此处显示详细说明

    properties
        x1 = 0
        x2 = 0
        x3 = 0
        x4 = 0
        y1 = 0
        y2 = 0
        y3 = 0
        y4 = 0
        z1 = 0
        z2 = 0
        z3 = 0
        z4 = 0
        iskey = false
        x
        y
        z
        number
    end

    methods
        function obj = Point3D(x,y,z,number)
            %UNTITLED2 构造此类的实例
            %   此处显示详细说明
            obj.x = x;
            obj.y = y;
            obj.z = z;
            obj.number = number;
        end

        function flag = iskeypoint(obj)
            if((obj.x==obj.y)&&(obj.y==obj.z))
                flag = true;
            elseif((obj.x==obj.y)&&(obj.y==obj.z-2))
                flag = true;
            elseif((obj.x==obj.y-2)&&(obj.y==obj.z))
                flag = true;
            elseif((obj.x-2==obj.y)&&(obj.y==obj.z))
                flag = true;
            elseif((obj.x==obj.y)&&(obj.y==obj.z+2))
                flag = true;
            elseif((obj.x==obj.y-2)&&(obj.y-2==obj.z))
                flag = true;
            elseif((obj.x==obj.y+2)&&(obj.y+2==obj.z))
                flag = true;
            else
                flag = false;
            end
        end
       
        function number = facenumber(obj)
            a = 0;
            if obj.x4 ~= 0
            a = a + 1;
            end
            if obj.x2 ~= 0
            a = a + 1;
            end
            if obj.x3 ~= 0
            a = a + 1;
            end
            if obj.x1 ~= 0
            a = a + 1;
            end
            if obj.y4 ~= 0
            a = a + 1;
            end
            if obj.y2 ~= 0
            a = a + 1;
            end
            if obj.y3 ~= 0
            a = a + 1;
            end
            if obj.y1 ~= 0
            a = a + 1;
            end
            if obj.z4 ~= 0
            a = a + 1;
            end
            if obj.z2 ~= 0
            a = a + 1;
            end
            if obj.z3 ~= 0
            a = a + 1;
            end
            if obj.z1 ~= 0
            a = a + 1;
            end
            number = a;


        end


    end
end