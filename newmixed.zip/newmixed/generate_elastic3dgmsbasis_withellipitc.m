function [phimatrix_pa,allratio,basismap,alleigval,iivaluepcell]=generate_elastic3dgmsbasis_withellipitc(n,Nx,Ny,Nz,alpha,localvp,...
    hx,hy,hz,nmaxbasis,eigvalue_tol,regvalue)
disp('generate elastic gms basis with scalar spectral problem....');
ts=tic;
ne=n^3;nx=Nx*n;ny=Ny*n;nz=Nz*n;ne1=nx*ny*nz;
alpha=reshape(alpha,nx,ny,nz);
Nc=Nx*Ny*Nz;
nx=Nx*n;ny=Ny*n;nz=Nz*n;
[nodv,facex1,facex2,facey1,facey2,facez1,facez2,bddof]=getrt0_3ddof(n,n,n);
p_dof=reshape(1:nx*ny*nz,nx,ny,nz);
alllocalalpha=cell(Nc,1);
basismap=ones(Nx,Ny,Nz);
  alllocal_pdof=cell(Nc,1);
id=1;
for ii3=1:Nz
    for ii2=1:Ny
        for ii1=1:Nx
    

global_p_dof=p_dof( (ii1-1)*n+1:ii1*n,(ii2-1)*n+1:ii2*n,(ii3-1)*n+1:ii3*n);global_p_dof=global_p_dof(:);
  alllocalalpha{id}=alpha(global_p_dof);
  alllocal_pdof{id}=global_p_dof;
id=id+1;

        end
    end
end
alleigval=cell(Nc,1);
allratio=zeros(Nc,1);
D=sparse(ne,ne);
iivaluepcell=cell(Nc,1);
Avp=sparse(nodv,repmat(1:ne,6,1),localvp*ones(1,ne));
Avp(bddof,:)=[];
for id=1:Nc
    localalpha=alllocalalpha{id};
invdiagAvv=sparse(nodv,ones(6,ne),1/2*hx*hy*hz*ones(6,1)*localalpha');
invdiagAvv(bddof)=[];

Aeig=-eli_matrix0(1./invdiagAvv',Avp,D);
Meig=sparse(1:ne,1:ne,localalpha);
Aeig=Aeig+Aeig.';
Aeig=Aeig+regvalue*diag(diag(Aeig));
Meig=Meig+regvalue*diag(diag(Meig));
[eigfun,eigvalue]=eigs(Aeig,Meig,nmaxbasis,'sm');
[d, order] = sort((diag(eigvalue)), 'ascend'); 

        eigfun=eigfun(:,order);eigvalue=eigvalue(:,order);
        thredhold=find(d>=eigvalue_tol);%% adaptive local number of basis
       if size(thredhold,2)*size(thredhold,1)==0  %%%% all eigvalue less than tolerance
        nlocalbasis=nmaxbasis;
       else
       nlocalbasis=thredhold(1);
       end 
       basis0=eigfun(:,1:nlocalbasis);
       basis=zeros(3*ne,3*nlocalbasis);
       basis(1:ne,1:nlocalbasis)=basis0;
       basis(1+ne:2*ne,1+nlocalbasis:2*nlocalbasis)=basis0;
       basis(1+2*ne:3*ne,1+2*nlocalbasis:3*nlocalbasis)=basis0;
       iivaluepcell{id}=basis;
       basismap(id)=size(basis,2);
       allratio(id)=min(localalpha(:))/max(localalpha(:));
       alleigval{id}=diag(eigvalue);
end

dim_pc=sum(basismap(:));
ixp=zeros(dim_pc,3*n^3);
ivaluep=zeros(dim_pc,3*n^3);
iyp=(1:dim_pc)'*ones(1,3*n^3);

ind=1;
iie=1;
for ii3=1:Nz
    for ii2=1:Ny
        for ii1=1:Nx
    
    basis=iivaluepcell{iie};
    nlocal_basis=basismap(iie);
    ivaluep(ind:ind+nlocal_basis-1,:)=basis';   
    global_p_dof=alllocal_pdof{iie};

   global_p_dof=[global_p_dof(:);global_p_dof(:)+ne1;global_p_dof(:)+2*ne1];
global_p_dof=sort( global_p_dof(:));

    ixp(ind:ind+nlocal_basis-1,:)= repmat( global_p_dof,1,nlocal_basis)';
ind=ind+nlocal_basis;  
iie=iie+1;
        end
    end
end
% if max(imag(allbasis(:)))>10^(-8)
%     disp('complex eigenfunction')
% end
% return
disp('assembling coarse matrix...')
clear alllocal_pdof allbasis p_dof

 phimatrix_pa=sparse(iyp,ixp,ivaluep,dim_pc,ne1*3);

 fprintf('dim of are %d %d\n',dim_pc,size(phimatrix_pa,2));
 fprintf('average basis number is %2.2f\n',dim_pc/(Nx*Ny*Nz));
 fprintf('2grid basis number is %d~%d\n',min(basismap(:)),max(basismap(:)) );
 clear ixp iyp ivaluep
 disp('END of generating ms basis')
 tb=toc(ts);
  fprintf('Tbasis is %2.2f seconds\n',tb);
  disp('............')