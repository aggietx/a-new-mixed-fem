%%% unstructed mesh,  continuous
%%%%  (3,4) (7,8) | (11,12) (15,16)
                    % ------- 
%%%%% (1,2) (5,6) | (9,10) (13,14)
% u1_exact=@(x,y) cos(pi*x).*sin(2*pi*y);
% u2_exact=@(x,y) sin(pi*x).*cos(pi*y);
clear;
close all
rng(10);plotsol1=1;rotmesh=3;cp=0;alpha=2;
nx=4*2^4;ny=nx;ne=nx*ny;nvet=2*ny*(nx+1);nhor=2*nx*(ny+1);nvdof=nvet+nhor;
Lx=2;Ly=1;hx=Lx/nx;hy=Ly/ny;vol=hx*hy;nedge=ny*(nx+1)+nx*(ny+1);np=(nx+1)*(ny+1);
% [nodv,dofx1,dofx2,dofy1,dofy2]=local2globaldof(nx,ny);
[nodedge,dofx1,dofx2,dofy1,dofy2,nodedof]=getelidof2delastic(nx,ny);
fprintf('nx is %d\n',nx);
%% coeff
lambda=123*ones(ny,nx);
mu=79.3*ones(ny,nx);
lambda=lambda(:);mu=mu(:);

s=lambda(1,1);t=mu(1,1);
lambda_bar=-lambda./(4*mu.*(lambda+mu));
mu_bar=1/2./(mu);
lambdabar_mubar=lambda_bar+mu_bar;
F=zeros(2*ne+2*nvdof+np,1);
u1_exact=@(x,y) cos(pi*x).*sin(2*pi*y);ue1=zeros(ne,1);
u2_exact=@(x,y) sin(pi*x).*cos(pi*y);ue2=zeros(ne,1);
f1 =@(x,y) -(s+2*t)*pi^2*cos(pi*x).*sin(2*pi*y)-s*pi^2*cos(pi*x).*sin(pi*y)-4*pi^2*t*sin(2*pi*y).*cos(pi*x)-t*pi^2*sin(pi*y).*cos(pi*x);
f2 =@(x,y) -2*t*pi^2*cos(2*pi*y).*sin(pi*x)-t*pi^2*sin(pi*x).*cos(pi*y)-pi^2*(s+2*t)*cos(pi*y).*sin(pi*x)-2*s*pi^2*sin(pi*x).*cos(2*pi*y);

%% mesh and matrix
map=zeros(16,1);map(1:2:end)=1:8;map(2:2:end)=9:16;
ir=zeros(16^2,ne);
ic=zeros(16^2,ne);
ivalue=zeros(16^2,ne);
ix=repmat(1:ne,8,1);
ivaluesp=zeros(32,ne);
[xp,yp]=meshgrid(0:hx:Lx,0:hy:Ly);
if rotmesh==1
R=cp*(hx).^(alpha);
% R=0;
fprintf('coefficient, and order of randomly perturbed grids %2.1f %2.1f\n',cp, alpha);
for i=2:nx
    for j=2:ny
     x0=xp(j,i);y0=yp(j,i);
     t1 = 2*pi*rand;
     r = R*(rand);
 xp(j,i) = x0 + r.*cos(t1);
 yp(j,i) = y0 + r.*sin(t1);    
    end
end

elseif rotmesh==2
    generateparallelogram_mesh2d
elseif rotmesh==3
disp('smooth quadrilateral mesh')
 for i=1:nx+1
    for j=1:ny+1
     x0=xp(j,i);y0=yp(j,i);
 xp(j,i) = x0 + .1*sin(2*pi*x0)*sin(2*pi*y0);
 yp(j,i) = y0 + .1*sin(2*pi*x0)*sin(2*pi*y0);    
    end
 end   
elseif rotmesh==4
    disp('twister mesh')
    value=0.1;x0=xp;y0=yp;
    xp=x0-value * sin(pi * x0) .* sin(3 * (-pi/2 + pi*y0));
    yp=y0+value * sin(pi * y0) .* sin(3 * (-pi/2 + pi*x0));
fprintf('twister value is %2.1f\n',value);
elseif rotmesh==5
    disp('non K-orthogonal')
    makeSkew = @(c) c(:,1) + .4*(1-(c(:,1)-1).^2).*(1-c(:,2));
    c=[xp(:),yp(:)];
    xp=2*makeSkew(c);
    xp=reshape(xp,ny+1,nx+1);
end
% mesh(xp,yp,zeros(ny+1,nx+1));

[~,nodp]=assemblemass(ny,nx,hx,hy,ones(ny,nx));
xpnod=xp(nodp);ypnod=yp(nodp);
xe=zeros(ny,nx);ye=zeros(ny,nx);
area=zeros(5,ne);
normal1=zeros(8,ne);normal2=zeros(8,ne);normal3=zeros(8,ne);normal4=zeros(8,ne);
normal0=zeros(8,ne);
size1=zeros(4,ne);size2=zeros(4,ne);size3=zeros(4,ne);size4=zeros(4,ne);
size0=zeros(4,ne);
ir2=zeros(16*4,ne);
ic2=zeros(16*4,ne);
isr=zeros(16*4,ne);

ir3=zeros(16*2,ne);
ic3=zeros(16*2,ne);

allpdof=reshape(1:(nx+1)*(ny+1),ny+1,nx+1);
alls=zeros(2,16,ne);
xe2=zeros(2*ny,2*nx);
ye2=xe2;
F1=ones(ne,1);F2=F1;

id=1;
for i=1:nx
    for j=1:ny
        clm=lambdabar_mubar(id);cm=mu_bar(id);cl=lambda_bar(id);
        x1=xp(j,i);x2=xp(j+1,i); x3=xp(j,i+1);x4=xp(j+1,i+1);
        y1=yp(j,i);y2=yp(j+1,i); y3=yp(j,i+1);y4=yp(j+1,i+1);
        x5=(x1+x2)/2;y5=(y1+y2)/2;x6=(x3+x4)/2;y6=(y3+y4)/2;
        x7=(x1+x3)/2;y7=(y1+y3)/2;x8=(x2+x4)/2;y8=(y2+y4)/2;
        xe(j,i)=mean(xpnod(:,id));
        ye(j,i)=mean(ypnod(:,id));
        x0=mean(xpnod(:,id));y0=mean(ypnod(:,id));
        F1(id)=f1(xe(j,i),ye(j,i));F2(id)=f2(xe(j,i),ye(j,i));
        ue1(id)=u1_exact(xe(j,i),ye(j,i));ue2(id)=u2_exact(xe(j,i),ye(j,i));

        % norm([x1,x2,x3,x4]'-xpnod(:,id))
        area1=polyarea([x1;x3/2+x1/2;x0;x2/2+x1/2],[y1;y3/2+y1/2;y0;y2/2+y1/2] );
        area2=polyarea([x1/2+x2/2;x0;x2/2+x4/2;x2],[y1/2+y2/2;y0;y2/2+y4/2;y2] );
        area3=polyarea([x1/2+x3/2;x3;x3/2+x4/2;x0],[y1/2+y3/2;y3;y3/2+y4/2;y0] );
        area4=polyarea([x0;x3/2+x4/2;x4;x2/2+x4/2],[y0;y3/2+y4/2;y4;y2/2+y4/2] );
        areas=polyarea([x1;x3;x4;x2],[y1;y3;y4;y2] );
        area(:,id)=[area1;area2;area3;area4;areas];
%%% quad 1
[n11,n12,n13,n14]=findoutnormalquad(x1,y1,x5,y5,x7,y7,x0,y0);
normal1(1:2,id)=n11;normal1(3:4,id)=n12;normal1(5:6,id)=n13;normal1(7:8,id)=n14;
[h11,h12,h13,h14]=computesizequad(x1,y1,x5,y5,x7,y7,x0,y0);
size1(1,id)=h11;size1(2,id)=h12;size1(3,id)=h13;size1(4,id)=h14;
%%% quad 2
[n21,n22,n23,n24]=findoutnormalquad(x5,y5,x2,y2,x0,y0,x8,y8);
normal2(1:2,id)=n21;normal2(3:4,id)=n22;normal2(5:6,id)=n23;normal2(7:8,id)=n24;
[h21,h22,h23,h24]=computesizequad(x5,y5,x2,y2,x0,y0,x8,y8);
size2(1,id)=h21;size2(2,id)=h22;size2(3,id)=h23;size2(4,id)=h24;
%%% quad 3
[n31,n32,n33,n34]=findoutnormalquad(x7,y7,x0,y0,x3,y3,x6,y6);
normal3(1:2,id)=n31;normal3(3:4,id)=n32;normal3(5:6,id)=n33;normal3(7:8,id)=n34;
[h31,h32,h33,h34]=computesizequad(x7,y7,x0,y0,x3,y3,x6,y6);
size3(1,id)=h31;size3(2,id)=h32;size3(3,id)=h33;size3(4,id)=h34;
%%% quad 4
[n41,n42,n43,n44]=findoutnormalquad(x0,y0,x8,y8,x6,y6,x4,y4);
normal4(1:2,id)=n41;normal4(3:4,id)=n42;normal4(5:6,id)=n43;normal4(7:8,id)=n44;
[h41,h42,h43,h44]=computesizequad(x0,y0,x8,y8,x6,y6,x4,y4);
size4(1,id)=h41;size4(2,id)=h42;size4(3,id)=h43;size4(4,id)=h44;
%%% quad 0
[n1,n2,n3,n4]=findoutnormalquad(x1,y1,x2,y2,x3,y3,x4,y4);
normal0(1:2,id)=n1;normal0(3:4,id)=n2;normal0(5:6,id)=n3;normal0(7:8,id)=n4;
[h1,h2,h3,h4]=computesizequad(x1,y1,x2,y2,x3,y3,x4,y4);
size0(1,id)=h1;size0(2,id)=h2;size0(3,id)=h3;size0(4,id)=h4;
%% local matrix
n1=n11;n2=n21;n3=n32;n4=n42;n5=n13;n7=n33;n6=n24;n8=n44;
h1=h11;h2=h21;h3=h32;h4=h42;h5=h13;h7=h33;h6=h24;h8=h44;

v1=[x7-x1;y7-y1];v1=-v1/dot(v1,n1);v2=[x8-x2;y8-y2];v2=-v2/dot(v2,n2);
v3=[x3-x7;y3-y7];v3=v3/dot(v3,n3);v4=[x4-x8;y4-y8];v4=v4/dot(v4,n4);
v5=[x5-x1;y5-y1];v5=-v5/dot(v5,n5);v6=[x2-x5;y2-y5];v6=v6/dot(v6,n6);
v7=[x6-x3;y6-y3];v7=-v7/dot(v7,n7);v8=[x4-x6;y4-y6];v8=v8/dot(v8,n8);


%% stress stress

v=[v1,v2,v3,v4,v5,v6,v7,v8,v1,v2,v3,v4,v5,v6,v7,v8];
alls(:,:,id)=v;
arear=repmat([area1,area2,area3,area4],1,4);
localAssa=zeros(16,16);
    for ixx=1:4
idxx=[1,5,9,13]+ixx-1;
localAssa(ixx,idxx(1))=cl*v(1,idxx(1))*v(1,idxx(1))+cm*v(:,idxx(1))'*v(:,idxx(1));
localAssa(ixx,idxx(2))=cl*v(1,idxx(1))*v(1,idxx(2))+cm*v(:,idxx(1))'*v(:,idxx(2));
localAssa(ixx,idxx(3))=cl*v(1,idxx(1))*v(2,idxx(3));
localAssa(ixx,idxx(4))=cl*v(1,idxx(1))*v(2,idxx(4));
localAssa(ixx,idxx)=localAssa(ixx,idxx).*arear(idxx);
    end
    
    for ixx=5:8
idxx=[5,1,9,13]+ixx-5;

localAssa(ixx,idxx(1))=cl*v(1,idxx(1))*v(1,idxx(1))+cm*v(:,idxx(1))'*v(:,idxx(1));
localAssa(ixx,idxx(2))=cl*v(1,idxx(1))*v(1,idxx(2))+cm*v(:,idxx(1))'*v(:,idxx(2));
localAssa(ixx,idxx(3))=cl*v(1,idxx(1))*v(2,idxx(3));
localAssa(ixx,idxx(4))=cl*v(1,idxx(1))*v(2,idxx(4));
localAssa(ixx,idxx)=localAssa(ixx,idxx).*arear(idxx);
    end
  
     for ixx=9:12
idxx=[9,13,1,5]+ixx-9;
localAssa(ixx,idxx(1))=cl*v(2,idxx(1))*v(2,idxx(1))+cm*v(:,idxx(1))'*v(:,idxx(1));
localAssa(ixx,idxx(2))=cl*v(2,idxx(1))*v(2,idxx(2))+cm*v(:,idxx(1))'*v(:,idxx(2));
localAssa(ixx,idxx(3))=cl*v(2,idxx(1))*v(1,idxx(3));
localAssa(ixx,idxx(4))=cl*v(2,idxx(1))*v(1,idxx(4));
localAssa(ixx,idxx)=localAssa(ixx,idxx).*arear(idxx);
     end

    for ixx=13:16
idxx=[13,9,1,5]+ixx-13;
localAssa(ixx,idxx(1))=cl*v(2,idxx(1))*v(2,idxx(1))+cm*v(:,idxx(1))'*v(:,idxx(1));
localAssa(ixx,idxx(2))=cl*v(2,idxx(1))*v(2,idxx(2))+cm*v(:,idxx(1))'*v(:,idxx(2));
localAssa(ixx,idxx(3))=cl*v(2,idxx(1))*v(1,idxx(3));
localAssa(ixx,idxx(4))=cl*v(2,idxx(1))*v(1,idxx(4));
localAssa(ixx,idxx)=localAssa(ixx,idxx).*arear(idxx);
    end
localAss=localAssa(map,map);

ivalue(:,id)=localAss(:);

%% stress and displacement
localsp=zeros(16,2);

localsp(1,1)=v1'*n1*h1+v1'*n5*h5;%%% basis*normal
localsp(2,1)=v2'*n2*h2+v2'*n6*h6;
localsp(3,1)=v3'*n3*h3+v3'*n7*h7;
localsp(4,1)=v4'*n4*h4+v4'*n8*h8;
localsp(5,1)=v5'*n5*h5+v5'*n1*h1;
localsp(7,1)=v7'*n7*h7+v7'*n3*h3;
localsp(6,1)=v6'*n6*h6+v6'*n2*h2;
localsp(8,1)=v8'*n8*h8+v8'*n4*h4;

localsp(1+8,2)=v1'*n1*h1+v1'*n5*h5;%%% basis*normal
localsp(2+8,2)=v2'*n2*h2+v2'*n6*h6;
localsp(3+8,2)=v3'*n3*h3+v3'*n7*h7;
localsp(4+8,2)=v4'*n4*h4+v4'*n8*h8;
localsp(5+8,2)=v5'*n5*h5+v5'*n1*h1;
localsp(7+8,2)=v7'*n7*h7+v7'*n3*h3;
localsp(6+8,2)=v6'*n6*h6+v6'*n2*h2;
localsp(8+8,2)=v8'*n8*h8+v8'*n4*h4;
localsp=localsp(map,:);
ivaluesp(:,id)=localsp(:);

%% rotation and stress
localsr=zeros(16,4);
r1=-v1(2);r2=-v2(2);r3=-v3(2);r4=-v4(2);r5=-v5(2);r6=-v6(2);r7=-v7(2);r8=-v8(2);
r9=v1(1);r10=v2(1);r11=v3(1);r12=v4(1);r13=v5(1);r14=v6(1);r15=v7(1);r16=v8(1);
localsr(1,1)=r1*area1;localsr(2,2)=r2*area2;localsr(3,3)=r3*area3;localsr(4,4)=r4*area4;
localsr(5,1)=r5*area1;localsr(6,2)=r6*area2;localsr(7,3)=r7*area3;localsr(8,4)=r8*area4;
localsr(9,1)=r9*area1;localsr(10,2)=r10*area2;localsr(11,3)=r11*area3;localsr(12,4)=r12*area4;
localsr(13,1)=r13*area1;localsr(14,2)=r14*area2;localsr(15,3)=r15*area3;localsr(16,4)=r16*area4;
localsr=localsr(map,:);
isr(:,id)=localsr(:);
%% dof
localedof=nodedge(:,id);
ir(:,id)=repmat(localedof,16,1);
temp=repmat(localedof,1,16);temp=temp';ic(:,id)=temp(:);

ir2(:,id)=repmat(localedof,4,1);
localpdof=allpdof(j:j+1,i:i+1);localpdof=localpdof(:);temp=repmat(localpdof,1,16);temp=temp';ic2(:,id)=temp(:);

ir3(:,id)=repmat(localedof,2,1);
localudof=[id,id+ne];localudof=localudof(:);temp=repmat(localudof,1,16);temp=temp';ic3(:,id)=temp(:);
%% diribd
if i==1 %%left

F(dofx1(j*2-1,1))=v1'*n1*h1*u1_exact( x5,y5);
F(dofx1(j*2),1)=v2'*n2*h2*u1_exact( x5,y5);%
F(dofx1(j*2-1,2))=v1'*n1*h1*u2_exact( x5,y5);
F(dofx1(j*2,2))=v2'*n2*h2*u2_exact( x5,y5);%
end
if  i==nx %% right 
F(dofx2(j*2-1,1))=v3'*n3*h3*u1_exact(x6,y6);
F(dofx2(j*2,1))=v4'*n4*h4*u1_exact( x6,y6);%
F(dofx2(j*2-1,2))=v3'*n3*h3*u2_exact(x6,y6);
F(dofx2(j*2,2))=v4'*n4*h4*u2_exact( x6,y6);%
end
if j==1 %%% bottom
F(dofy1(i*2-1,1))=v5'*n5*h5*u1_exact(x7,y7);
F(dofy1(i*2,1))=v7'*n7*h7*u1_exact(x7,y7);%
F(dofy1(i*2-1,2))=v5'*n5*h5*u2_exact(x7,y7);
F(dofy1(i*2,2))=v7'*n7*h7*u2_exact(x7,y7);%
end
if j==ny %%%%top
F(dofy2(i*2-1,1))=v6'*n6*h6*u1_exact(x8,y8);
F(dofy2(i*2,1))=v8'*n8*h8*u1_exact( x8,y8);%
F(dofy2(i*2-1,2))=v6'*n6*h6*u2_exact(x8,y8);
F(dofy2(i*2,2))=v8'*n8*h8*u2_exact( x8,y8);%
end
        id=id+1;
    end
end
Ars=sparse(ir2,ic2,isr,2*nvdof,2*ne+np);

Ass=sparse(ir,ic,ivalue);
Asp=sparse(ir3,ic3+np,ivaluesp,2*nvdof,2*ne+np);
invAss_local=cell(np,1);
id=0;
for i=1:np
localdof=nodedof(:,i);ndof=length(find(localdof))*2;

invAss_local{i}=inv(Ass(id+1:id+ndof,id+1:id+ndof));
id=id+ndof;
end
invAss=blkdiag(invAss_local{:});

Aaug1=Ars+Asp;

% A=[Ass, Aaug1;
%    Aaug1',sparse(2*ne+np,2*ne+np)];
%% force
cigma_11_f=@(x,y) -(s+2*t)*pi*sin(pi*x).*sin(2*pi*y)-s*pi*sin(pi*x).*sin(pi*y);
cigma_12_f=@(x,y) 2*t*pi*cos(2*pi*y).*cos(pi*x)+t*pi*cos(pi*x).*cos(pi*y);
cigma_22_f=@(x,y) -(s+2*t)*pi*sin(pi*y).*sin(pi*x)-s*pi*sin(pi*x).*sin(2*pi*y);
cigma_21_f=cigma_12_f;
% F1=f1(xe,ye);F2=f2(xe,ye);F1=F1(:);F2=F2(:);
F1=F1.*area(5,:)';F2=1*F2.*area(5,:)';

if 0

%%%% diri for u1
ya=(2*hy/4:hy:1);yb=(2*hy/4:hy:1);x=zeros(1,ny);
F(dofx1(1:2:end,1))=-u1_exact(x,ya)*hy/2;F(dofx1(2:2:end,1))=-u1_exact(x,yb)*hy/2;%%% u1,x=0,
ya=(2*hy/4:hy:1);yb=(2*hy/4:hy:1);x=ones(1,ny);
F(dofx2(1:2:end,1))=u1_exact(x,ya)*hy/2;F(dofx2(2:2:end,1))=u1_exact(x,yb)*hy/2;%%% u1,x=1,%%
xa=(2*hx/4:hx:1);xb=(2*hx/4:hx:1);y=zeros(1,nx);
F(dofy1(1:2:end,1))=-u1_exact(xa,y)*hx/2;F(dofy1(2:2:end,1))=-u1_exact(xb,y)*hx/2;%%% u1,y=0,%%
xa=(2*hx/4:hx:1);xb=(2*hx/4:hx:1);y=ones(1,nx);
F(dofy2(1:2:end,1))=u1_exact(xa,y)*hx/2;F(dofy2(2:2:end,1))=u1_exact(xb,y)*hx/2;%%% u1,y=1,


%%%% diri for u2
ya=(2*hy/4:hy:1);yb=(2*hy/4:hy:1);x=zeros(1,ny);
F(dofx1(1:2:end,2))=-u2_exact(x,ya)*hy/2;F(dofx1(2:2:end,2))=-u2_exact(x,yb)*hy/2;%%% u2,x=0,
ya=(2*hy/4:hy:1);yb=(2*hy/4:hy:1);x=ones(1,ny);
F(dofx2(1:2:end,2))=u2_exact(x,ya)*hy/2;F(dofx2(2:2:end,2))=u2_exact(x,yb)*hy/2;%%% u2,x=1,%%
xa=(2*hx/4:hx:1);xb=(2*hx/4:hx:1);y=zeros(1,nx);
F(dofy1(1:2:end,2))=-u2_exact(xa,y)*hx/2;F(dofy1(2:2:end,2))=-u2_exact(xb,y)*hx/2;%%% u2,y=0,%%
xa=(2*hx/4:hx:1);xb=(2*hx/4:hx:1);y=ones(1,nx);
F(dofy2(1:2:end,2))=u2_exact(xa,y)*hx/2;F(dofy2(2:2:end,2))=u2_exact(xb,y)*hx/2;%%% u2,y=1,

end
F(2*nvdof+1+np:2*nvdof+2*ne+np)=[F1;F2];


D=sparse(np+2*ne,np+2*ne);
[Aeli,Feli]=eli_matrix(invAss,Aaug1,D,F);
invArr=sparse(1:np,1:np,1./diag(Aeli(1:np,1:np)));D=Aeli(np+1:end,np+1:end); Aaug=Aeli(1:np,np+1:end);
[Aeli0,Feli0,u0,uf0]=eli(invArr,Aaug,D,Feli);

uf=zeros(2*nvdof+2*ne+np,1);uf(2*nvdof+1:end)=uf0;uf(1:2*nvdof)=invAss*(F(1:2*nvdof)-Aaug1*uf0);
u=uf;
% u=A\F;
% imagescsquare1(ue1);title('exact u1');
% imagescsquare1(u(2*nvdof+1:2*nvdof+ne));title('app u1');
% imagescsquare1(ue2);title('exact u2');imagescsquare1(u(2*nvdof+1+ne:2*nvdof+2*ne));title('app u2');
ua1=u(2*nvdof+1+np:2*nvdof+ne+np);
ua2=u(2*nvdof+1+ne+np:2*nvdof+2*ne+np);

%% displacement
diff=sqrt(ua1.^2+ua2.^2)-sqrt(ue1.^2+ue2.^2);
exact=sqrt(ue1.^2+ue2.^2);
fprintf('size is %d\n',nx)
fprintf('relative error of displacement are %2.4e\n',norm(diff)/norm(exact));
ua=sqrt(ua1.^2+ua2.^2);
ue=sqrt(ue1.^2+ue2.^2);
% figure();mesh(xe,ye,reshape(ua,ny,nx));colormap jet;title('app u')
% figure();mesh(xe,ye,reshape(ue,ny,nx));colormap jet;title('exact u')
%% stress mean
s11a=zeros(ne,1);s12a=zeros(ne,1);s21a=zeros(ne,1);s22a=zeros(ne,1);
id=1;
for i=1:nx
    for j=1:ny
localsdof=nodedge(:,id);
locals=u(localsdof);

        x1=xp(j,i);x2=xp(j+1,i); x3=xp(j,i+1);x4=xp(j+1,i+1);
        y1=yp(j,i);y2=yp(j+1,i); y3=yp(j,i+1);y4=yp(j+1,i+1);
localarea=area(1:4,id);
localsbasis=alls(:,:,id);

s11a(id)=computeweightaverage2d([locals(1)*localsbasis(1,1)+locals(9)*localsbasis(1,5);...
    locals(3)*localsbasis(1,2)+locals(11)*localsbasis(1,6);...
    locals(5)*localsbasis(1,3)+locals(13)*localsbasis(1,7);...
    locals(7)*localsbasis(1,4)+locals(15)*localsbasis(1,8)],localarea);

s12a(id)=computeweightaverage2d([locals(1)*localsbasis(2,1)+locals(9)*localsbasis(2,5);...
    locals(3)*localsbasis(2,2)+locals(11)*localsbasis(2,6);...
    locals(5)*localsbasis(2,3)+locals(13)*localsbasis(2,7);...
    locals(7)*localsbasis(2,4)+locals(15)*localsbasis(2,8)],localarea);

s21a(id)=computeweightaverage2d([locals(2)*localsbasis(1,1+8)+locals(10)*localsbasis(1,5+8);...
    locals(4)*localsbasis(1,2+8)+locals(12)*localsbasis(1,6+8);...
    locals(6)*localsbasis(1,3+8)+locals(14)*localsbasis(1,7+8);...
    locals(8)*localsbasis(1,4+8)+locals(16)*localsbasis(1,8+8)],localarea);

s22a(id)=computeweightaverage2d([locals(2)*localsbasis(2,1+8)+locals(10)*localsbasis(2,5+8);...
    locals(4)*localsbasis(2,2+8)+locals(12)*localsbasis(2,6+8);...
    locals(6)*localsbasis(2,3+8)+locals(14)*localsbasis(2,7+8);...
    locals(8)*localsbasis(2,4+8)+locals(16)*localsbasis(2,8+8)],localarea);

        id=id+1;
    end
end
s11a=s11a(:);s12a=s12a(:);s21a=s21a(:);s22a=s22a(:);
sa=sqrt(s11a.^2+s12a.^2+s21a.^2+s22a.^2);
s11e2=cigma_11_f( xe,ye);s12e2=cigma_12_f( xe,ye);
s21e2=cigma_21_f( xe,ye);s22e2=cigma_22_f( xe,ye);
se2=sqrt(s11e2.^2+s12e2.^2+s21e2.^2+s22e2.^2);se2=se2(:);
diff2=se2-sa;
% fprintf('ave vs center, relative error of stress are %2.4e \n',norm(diff2)/norm(se2) );
% imagescsquare1(sa);title('app stress')
% imagescsquare1(se2);title('exact stress')

%% stress full
s11e=zeros(2*ny,2*nx);s11a=zeros(2*ny,2*nx);s12e=zeros(2*ny,2*nx);s12a=zeros(2*ny,2*nx);
s21e=zeros(2*ny,2*nx);s21a=zeros(2*ny,2*nx);s22e=zeros(2*ny,2*nx);s22a=zeros(2*ny,2*nx);
id=1;
for i=1:nx
    for j=1:ny
localsdof=nodedge(:,id);
locals=u(localsdof);

        x1=xp(j,i);x2=xp(j+1,i); x3=xp(j,i+1);x4=xp(j+1,i+1);
        y1=yp(j,i);y2=yp(j+1,i); y3=yp(j,i+1);y4=yp(j+1,i+1);
        x5=(x1+x2)/2;y5=(y1+y2)/2;x6=(x3+x4)/2;y6=(y3+y4)/2;
        x7=(x1+x3)/2;y7=(y1+y3)/2;x8=(x2+x4)/2;y8=(y2+y4)/2;
x1a=(x1+x7)/2;y1a=(y1+y5)/2;
x2a=(x2+x8)/2;y2a=(y2+y5)/2;
x3a=(x3+x7)/2;y3a=(y3+y6)/2;
x4a=(x4+x8)/2;y4a=(y4+y6)/2;
localarea=area(1:4,id);
localsbasis=alls(:,:,id);
% localsbasis=localsbasis(:,:);
s11e( j*2-1:j*2,i*2-1:i*2)=[cigma_11_f(x1a,y1a),cigma_11_f(x3a,y3a);cigma_11_f(x2a,y2a),cigma_11_f(x4a,y4a)];
s12e( j*2-1:j*2,i*2-1:i*2)=[cigma_12_f(x1a,y1a),cigma_12_f(x3a,y3a);cigma_12_f(x2a,y2a),cigma_12_f(x4a,y4a)];
s21e( j*2-1:j*2,i*2-1:i*2)=[cigma_21_f(x1a,y1a),cigma_21_f(x3a,y3a);cigma_21_f(x2a,y2a),cigma_21_f(x4a,y4a)];
s22e( j*2-1:j*2,i*2-1:i*2)=[cigma_22_f(x1a,y1a),cigma_22_f(x3a,y3a);cigma_22_f(x2a,y2a),cigma_22_f(x4a,y4a)];

s11a( j*2-1:j*2,i*2-1:i*2)=reshape([locals(1)*localsbasis(1,1)+locals(9)*localsbasis(1,5);...
    locals(3)*localsbasis(1,2)+locals(11)*localsbasis(1,6);...
    locals(5)*localsbasis(1,3)+locals(13)*localsbasis(1,7);...
    locals(7)*localsbasis(1,4)+locals(15)*localsbasis(1,8)],2,2);
s12a( j*2-1:j*2,i*2-1:i*2)=reshape([locals(1)*localsbasis(2,1)+locals(9)*localsbasis(2,5);...
    locals(3)*localsbasis(2,2)+locals(11)*localsbasis(2,6);...
    locals(5)*localsbasis(2,3)+locals(13)*localsbasis(2,7);...
    locals(7)*localsbasis(2,4)+locals(15)*localsbasis(2,8)],2,2);
s21a( j*2-1:j*2,i*2-1:i*2)=reshape([locals(2)*localsbasis(1,1+8)+locals(10)*localsbasis(1,5+8);...
    locals(4)*localsbasis(1,2+8)+locals(12)*localsbasis(1,6+8);...
    locals(6)*localsbasis(1,3+8)+locals(14)*localsbasis(1,7+8);...
    locals(8)*localsbasis(1,4+8)+locals(16)*localsbasis(1,8+8)],2,2);
s22a( j*2-1:j*2,i*2-1:i*2)=reshape([locals(2)*localsbasis(2,1+8)+locals(10)*localsbasis(2,5+8);...
    locals(4)*localsbasis(2,2+8)+locals(12)*localsbasis(2,6+8);...
    locals(6)*localsbasis(2,3+8)+locals(14)*localsbasis(2,7+8);...
    locals(8)*localsbasis(2,4+8)+locals(16)*localsbasis(2,8+8)],2,2);


        id=id+1;
    end
end
s11a=s11a(:);s12a=s12a(:);s21a=s21a(:);s22a=s22a(:);s11e=s11e(:);s12e=s12e(:);s21e=s21e(:);s22e=s22e(:);

se=sqrt(s11e.^2+s12e.^2+s21e.^2+s22e.^2);sa=sqrt(s11a.^2+s12a.^2+s21a.^2+s22a.^2);
diff1=se-sa;
fprintf('relative error of stress are %2.4e\n',norm(diff1)/norm(se));
fprintf('ave vs center, relative error of stress are %2.4e \n',norm(diff2)/norm(se2) );

%% rotation
rota=u(2*nvdof+1:2*nvdof+np);
du1dy=@(x,y) 2*pi*cos(pi*x).*cos(2*pi*y);
du2dx=@(x,y) pi*cos(pi*x).*cos(pi*y);
% [xp,yp]=meshgrid(0:hx:Lx,0:hy:Ly);
rote=du2dx(xp,yp)-du1dy(xp,yp);rote=rote(:)/2;
rotacell=zeros(ny,nx);
rotecell=zeros(ny,nx);
id=1;
for i=1:nx
    for j=1:ny
localpdof=allpdof(j:j+1,i:i+1);localpdof=localpdof(:);
ra=rota(localpdof);
re=rote(localpdof);
localarea=area(1:4,id);
rotacell(id)=sum(ra.*localarea)/sum(localarea);
rotecell(id)=sum(re.*localarea)/sum(localarea);
        id=id+1;
    end
end
rotacell=rotacell(:);
rotecell=rotecell(:);
fprintf('relative error of rotation are %2.4e \n',...
    norm(rotecell-rotacell)/norm(rotecell) );

% diff=[ua1;ua2]-[ue1;ue2];
% eh1=sqrt( (diff'*Aeli0(1:2*ne,1:2*ne)*diff)/([ue1;ue2]'*Aeli0(1:2*ne,1:2*ne)*[ue1;ue2]));
% fprintf('h1 error of displacement is %2.4e\n',eh1)
