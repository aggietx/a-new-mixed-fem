function [Aeli]=eli_matrix0(invAss,Aaug,D)
if size(invAss,1)>1 %%% inverse is matrix case
Aeli=-(Aaug'*invAss)*Aaug+D;

else %%%% inverse is diagonal case
    Aeli=-(Aaug'.*invAss)*Aaug+D;
end
% notherdof=size(Aaug,2);
% u1=Aeli\Feli;uf=zeros(nelidof+notherdof,1);uf(nelidof+1:end)=u1;uf(1:nelidof)=-invAss*Aaug*u1;
