function [A]=dirisetA2(A,fixeddofs)
%%%% symmetric must be zero dirichlet 
ndof=size(A,1);
N = ones(ndof,1); N(fixeddofs) = 0; Null = spdiags(N,0,ndof,ndof);

    A = Null'*A*Null - (Null-speye(ndof,ndof));

