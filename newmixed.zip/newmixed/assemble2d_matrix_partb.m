function [Aaug1,D,ir1,ic1,nodedof,bddof,nodedge,facex1,facex2,facey1,facey2]=assemble2d_matrix_partb(nx,ny,hx,hy,mu_bar)


ne=nx*ny;nvet=2*ny*(nx+1);nhor=2*nx*(ny+1);nvdof=nvet+nhor;nedge=ny*(nx+1)+nx*(ny+1);
vol=hx*hy;np=(nx+1)*(ny+1);
[edge_hor,edge_vec,nodedof] = getedgedof(ny,nx);
bddof=[edge_hor(1,:)';edge_hor(end,:)';edge_vec(:,1);edge_vec(:,end)];bddof=sort(bddof);bddof=[bddof*2-1;bddof*2];

facex1=edge_vec(:,1);[~,facex1]=vectorize_eli2d(facex1); facex1=reshape(facex1,2*ny,2);  
facex2=edge_vec(:,end);[~,facex2]=vectorize_eli2d(facex2);facex2=reshape(facex2(:),2*ny,2);
facey1=edge_hor(1,:);[~,facey1]=vectorize_eli2d(facey1);facey1=reshape(facey1(:),2*nx,2); 
facey2=edge_hor(end,:);[~,facey2]=vectorize_eli2d(facey2);facey2=reshape(facey2(:),2*nx,2);

nodedge=zeros(16,ne);
ir1=zeros(16^2,ne);
ic1=zeros(16^2,ne);
id=1;
for i=1:nx
    for j=1:ny
        dof1=edge_vec(j*2-1,i);dof2=edge_vec(j*2,i); dof3=edge_vec(j*2-1,i+1);dof4=edge_vec(j*2,i+1);
        dof5=edge_hor(j,i*2-1);dof6=edge_hor(j+1,i*2-1);dof7=edge_hor(j,i*2);dof8=edge_hor(j+1,i*2);%%%%%%%%%%%%%%%%%%%%%%%
localedof=[dof1*2-1:dof1*2,dof2*2-1:dof2*2,dof3*2-1:dof3*2,dof4*2-1:dof4*2,dof5*2-1:dof5*2,dof6*2-1:dof6*2,dof7*2-1:dof7*2,dof8*2-1:dof8*2]';
nodedge(:,id)=localedof;
id=id+1;
    end
end

%% 
localsr=zeros(16,4);
localsr(9,1)=-1;localsr(11,2)=-1;localsr(13,3)=-1;localsr(15,4)=-1;
localsr(2,1)=1;localsr(4,2)=1;localsr(6,3)=1;localsr(8,4)=1;

localsr=localsr*vol/4;
allrdof=reshape(1:(nx+1)*(ny+1),ny+1,nx+1);
ir=zeros(16*4,ne);
ic=zeros(16*4,ne);
id=1;
for i=1:nx
    for j=1:ny
localedof=nodedge(:,id); ir(:,id)=repmat(localedof,4,1);
localrdof=allrdof(j:j+1,i:i+1);localrdof=localrdof(:);temp=repmat(localrdof,1,16);temp=temp';ic(:,id)=temp(:);
ir1(:,id)=repmat(localedof,16,1);
temp=repmat(localedof,1,16);temp=temp';ic1(:,id)=temp(:);
id=id+1;
    end
end
% Ars=sparse(ir,ic,repmat(localsr(:),1,ne).*(mu_bar*ones(1,64))',2*nvdof,2*ne+np);
Ars=sparse(ir,ic,localsr(:)*mu_bar',2*nvdof,2*ne+np);
%% 
localsp=zeros(16,2);
localsp([1,3,5,7,9,11,13,15],1)=[-1,-1,1,1,-1,1,-1,1]'*hx/2;
localsp([2,4,6,8,10,12,14,16],2)=[-1,-1,1,1,-1,1,-1,1]'*hx/2;


ir=zeros(16*2,ne);
ic=zeros(16*2,ne);
id=1;
for i=1:nx
    for j=1:ny
localedof=nodedge(:,id); ir(:,id)=repmat(localedof,2,1);
localudof=[id,id+ne];localudof=localudof(:);temp=repmat(localudof,1,16);temp=temp';ic(:,id)=temp(:);

id=id+1;
    end
end
Asu=sparse(ir,ic+np,repmat(localsp(:),1,ne),2*nvdof,2*ne+np);

Aaug1=Ars+Asu;
D=sparse(np+2*ne,np+2*ne);
