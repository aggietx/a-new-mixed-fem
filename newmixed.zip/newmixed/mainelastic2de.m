%%% ex 1 in yotov's paper
% u1_exact=@(x,y) cos(pi*x).*sin(2*pi*y);
% u2_exact=@(x,y) sin(pi*x).*cos(pi*y);
%%% no stress elimination, all basis are positive
clear;
close all
errcase=1;%%%% 1:average
nx=32;ny=nx;ne=nx*ny;nvet=2*ny*(nx+1);nhor=2*nx*(ny+1);nvdof=nvet+nhor;nedge=ny*(nx+1)+nx*(ny+1);
Lx=1;Ly=1;hx=Lx/nx;hy=Ly/ny;vol=hx*hy;np=(nx+1)*(ny+1);
[nodv,dofx1,dofx2,dofy1,dofy2]=local2globaldof(nx,ny);nodv2=[nodv;nodv+2*nedge];

% poission_ratio=0.49999999;
% load k1;young_modulus=k1;
% young_modulus=1*ones(ny,nx);% % depends on x
% lambda=poission_ratio/((1+poission_ratio)*(1-2*poission_ratio))*young_modulus;
% mu=1/2/(1+poission_ratio)*young_modulus;
% lambda=lambda(:);mu=mu(:);


lambda=123*ones(ny,nx);
mu=79.3*ones(ny,nx);
lambda=lambda(:);mu=mu(:);

s=lambda(1,1);t=mu(1,1);
lambda_bar=-lambda./(4*mu.*(lambda+mu));
mu_bar=1/2./(mu);
lambdabar_mubar=lambda_bar+mu_bar;

Ass11=sparse(nodv,nodv,[ones(4,1)*lambdabar_mubar';ones(4,1)*mu_bar'])*vol/4;
Ass22=sparse(nodv,nodv,[ones(4,1)*mu_bar';ones(4,1)*lambdabar_mubar'])*vol/4;
ir1=zeros(16^2,ne);
ic1=zeros(16^2,ne);
localA12=zeros(16,16);
localA12(1,5+8)=1;localA12(2,6+8)=1;localA12(3,7+8)=1;localA12(4,8+8)=1;
localA12(5+8,1)=1;localA12(6+8,2)=1;localA12(7+8,3)=1;localA12(8+8,4)=1;
id=1;
for i=1:nx
    for j=1:ny
localedof=[nodv(:,id);nodv(:,id)+nvdof];  ir1(:,id)=repmat(localedof,16,1);
temp=repmat(localedof,1,16);temp=temp';ic1(:,id)=temp(:);
id=id+1;
    end
end
Ass=[1*Ass11,sparse(nedge*2,nedge*2);
    sparse(nedge*2,nedge*2), 1*Ass22]+sparse(ir1,ic1,localA12(:)*lambda_bar'*vol/4);


%%
localsp=[-1,-1,1,1,-1,1,-1,1]'*hx/2;
ivalue=repmat(localsp,1,ne);
ix=repmat(1:ne,8,1);
Asp0=sparse(nodv,ix,ivalue);clear ivalue ix 
Asp=[Asp0,sparse(2*nedge,ne);
    sparse(2*nedge,ne),Asp0];

%% 
localsr=zeros(16,4);
localsr(5,1)=-1;localsr(6,2)=-1;localsr(7,3)=-1;localsr(8,4)=-1;
localsr(9,1)=1;localsr(10,2)=1;localsr(11,3)=1;localsr(12,4)=1;

localsr=localsr*vol/4;
allpdof=reshape(1:(nx+1)*(ny+1),ny+1,nx+1);
ir=zeros(16*4,ne);
ic=zeros(16*4,ne);
id=1;
for i=1:nx
    for j=1:ny
localedof=[nodv(:,id);nodv(:,id)+nvdof];  ir(:,id)=repmat(localedof,4,1);
localpdof=allpdof(j:j+1,i:i+1);localpdof=localpdof(:);temp=repmat(localpdof,1,16);temp=temp';ic(:,id)=temp(:);

id=id+1;
    end
end
Ars=sparse(ir,ic,repmat(localsr(:),1,ne));
A=[Ass, Asp,Ars;
   -Asp',sparse(2*ne,2*ne+np);
   Ars',sparse(np,2*ne+np)];
cigma_11_f=@(x,y) -(s+2*t)*pi*sin(pi*x).*sin(2*pi*y)-s*pi*sin(pi*x).*sin(pi*y);
cigma_12_f=@(x,y) 2*t*pi*cos(2*pi*y).*cos(pi*x)+t*pi*cos(pi*x).*cos(pi*y);
cigma_22_f=@(x,y) -(s+2*t)*pi*sin(pi*y).*sin(pi*x)-s*pi*sin(pi*x).*sin(2*pi*y);
cigma_21_f=cigma_12_f;
[xe,ye]=meshgrid(hx/2:hx:Lx-hx/2,hy/2:hy:Ly-hy/2);
u1_exact=@(x,y) cos(pi*x).*sin(2*pi*y);ue1=u1_exact(xe(:),ye(:));
u2_exact=@(x,y) sin(pi*x).*cos(pi*y);ue2=u2_exact(xe(:),ye(:));
du1dy=@(x,y) 2*pi*cos(pi*x).*cos(2*pi*y);
du2dx=@(x,y) pi*cos(pi*x).*cos(pi*y);
[xp,yp]=meshgrid(0:hx:Lx,0:hy:Ly);
rote=du2dx(xp,yp)-du1dy(xp,yp);rote=rote(:)/2;

% return
f1 =@(x,y) -(s+2*t)*pi^2*cos(pi*x).*sin(2*pi*y)-s*pi^2*cos(pi*x).*sin(pi*y)-4*pi^2*t*sin(2*pi*y).*cos(pi*x)-t*pi^2*sin(pi*y).*cos(pi*x);
f2 =@(x,y) -2*t*pi^2*cos(2*pi*y).*sin(pi*x)-t*pi^2*sin(pi*x).*cos(pi*y)-pi^2*(s+2*t)*cos(pi*y).*sin(pi*x)-2*s*pi^2*sin(pi*x).*cos(2*pi*y);
F1=-f1(xe(:),ye(:));F2=-f2(xe(:),ye(:));
F=zeros(2*ne+2*nvdof+np,1);
if 1

%%%% diri for u1
ya=(2*hy/4:hy:1);yb=(2*hy/4:hy:1);x=zeros(1,ny);
F(dofx1(1:2:end))=-u1_exact(x,ya)*hy/2;F(dofx1(2:2:end))=-u1_exact(x,yb)*hy/2;%%% u1,x=0,
ya=(2*hy/4:hy:1);yb=(2*hy/4:hy:1);x=ones(1,ny);
F(dofx2(1:2:end))=u1_exact(x,ya)*hy/2;F(dofx2(2:2:end))=u1_exact(x,yb)*hy/2;%%% u1,x=1,%%
xa=(2*hx/4:hx:1);xb=(2*hx/4:hx:1);y=zeros(1,nx);
F(dofy1(1:2:end))=-u1_exact(xa,y)*hx/2;F(dofy1(2:2:end))=-u1_exact(xb,y)*hx/2;%%% u1,y=0,%%
xa=(2*hx/4:hx:1);xb=(2*hx/4:hx:1);y=ones(1,nx);
F(dofy2(1:2:end))=u1_exact(xa,y)*hx/2;F(dofy2(2:2:end))=u1_exact(xb,y)*hx/2;%%% u1,y=1,


%%%% diri for u2
ya=(2*hy/4:hy:1);yb=(2*hy/4:hy:1);x=zeros(1,ny);
F(dofx1(1:2:end)+2*nedge)=-u2_exact(x,ya)*hy/2;F(dofx1(2:2:end)+2*nedge)=-u2_exact(x,yb)*hy/2;%%% u2,x=0,
ya=(2*hy/4:hy:1);yb=(2*hy/4:hy:1);x=ones(1,ny);
F(dofx2(1:2:end)+2*nedge)=u2_exact(x,ya)*hy/2;F(dofx2(2:2:end)+2*nedge)=u2_exact(x,yb)*hy/2;%%% u2,x=1,%%
xa=(2*hx/4:hx:1);xb=(2*hx/4:hx:1);y=zeros(1,nx);
F(dofy1(1:2:end)+2*nedge)=-u2_exact(xa,y)*hx/2;F(dofy1(2:2:end)+2*nedge)=-u2_exact(xb,y)*hx/2;%%% u2,y=0,%%
xa=(2*hx/4:hx:1);xb=(2*hx/4:hx:1);y=ones(1,nx);
F(dofy2(1:2:end)+2*nedge)=u2_exact(xa,y)*hx/2;F(dofy2(2:2:end)+2*nedge)=u2_exact(xb,y)*hx/2;%%% u2,y=1,

end
% F(1:nvdof*2)=-F(1:nvdof*2);
F(2*nvdof+1:2*nvdof+2*ne)=[F1;1*F2]*vol;

u=A\F;

%imagescsquare1(ue1);title('exact u1');imagescsquare1(u(2*nvdof+1:2*nvdof+ne));title('app u1');
% imagescsquare1(ue2);title('exact u2');imagescsquare1(u(2*nvdof+1+ne:2*nvdof+2*ne));title('app u2');
ua1=u(2*nvdof+1:2*nvdof+ne);
ua2=u(2*nvdof+1+ne:2*nvdof+2*ne);
% rnorm(sqrt(ua1.^2+ua2.^2),sqrt(ue1.^2+ue2.^2));
diff=sqrt(ua1.^2+ua2.^2)-sqrt(ue1.^2+ue2.^2);
exact=sqrt(ue1.^2+ue2.^2);
Mass=vol*speye(ne);
err=sqrt(diff'*Mass*diff);
rerr=sqrt(diff'*Mass*diff)/sqrt(exact'*Mass*exact);
fprintf('size is %d\n',nx)
fprintf('relative error and error of displacement are %2.4e %2.4e\n',norm(diff)/norm(exact),sqrt(sum(diff.^2)*vol) );
% % fprintf('error of displacement 1 is %2.6f %2.3e\n',sum(abs(ua1-ue1)*vol),sum(abs(ua1-ue1)*vol));
% % fprintf(''error of displacement 2 is %2.6f %2.3e\n',sum(abs(ua2-ue2)*vol),sum(abs(ua2-ue2)*vol));
% imagescsquare1(sqrt(ue1.^2+ue2.^2));title('exact norm u');
% imagescsquare1(sqrt(ua1.^2+ua2.^2));title('app norm u');
