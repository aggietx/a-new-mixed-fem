%%%% exact test, not elimination
%%%u1_exact_f=@(x,y) sin(2*pi*x).*sin(2*pi*y);ue1=u1_exact_f(xe(:),ye(:));
%%%u2_exact_f=@(x,y) sin(2*pi*x).*sin(2*pi*y);ue2=u2_exact_f(xe(:),ye(:));

clear;
close all
errcase=2;%%%% 1:average
nx=4*2^3;ny=nx;ne=nx*ny;nvet=2*ny*(nx+1);nhor=2*nx*(ny+1);nvdof=nvet+nhor;nedge=ny*(nx+1)+nx*(ny+1);
Lx=1;Ly=1;hx=Lx/nx;hy=Ly/ny;vol=hx*hy;np=(nx+1)*(ny+1);
nodv=local2globaldof(nx,ny);nodv2=[nodv;nodv+2*nedge];
poission_ratio=0.1;
% load k1;young_modulus=k1;
young_modulus=1*ones(ny,nx);% % depends on x
lambda=poission_ratio/((1+poission_ratio)*(1-2*poission_ratio))*young_modulus;
mu=1/2/(1+poission_ratio)*young_modulus;
lambda=lambda(:);mu=mu(:);

s=lambda(1,1);t=mu(1,1);
lambda_bar=-lambda./(4*mu.*(lambda+mu));
mu_bar=1/2./(mu);
lambdabar_mubar=lambda_bar+mu_bar;

Ass11=sparse(nodv,nodv,[ones(4,1)*lambdabar_mubar';ones(4,1)*mu_bar'])*vol/4;
Ass22=sparse(nodv,nodv,[ones(4,1)*mu_bar';ones(4,1)*lambdabar_mubar'])*vol/4;
ir1=zeros(16^2,ne);
ic1=zeros(16^2,ne);
localA12=zeros(16,16);
localA12(1,5+8)=-1;localA12(2,6+8)=1;localA12(3,7+8)=1;localA12(4,8+8)=-1;
localA12(5+8,1)=-1;localA12(6+8,2)=1;localA12(7+8,3)=1;localA12(8+8,4)=-1;
id=1;
for i=1:nx
    for j=1:ny
localedof=[nodv(:,id);nodv(:,id)+nvdof];  ir1(:,id)=repmat(localedof,16,1);
temp=repmat(localedof,1,16);temp=temp';ic1(:,id)=temp(:);
id=id+1;
    end
end
Ass=[1*Ass11,sparse(nedge*2,nedge*2);
    sparse(nedge*2,nedge*2), 1*Ass22]+sparse(ir1,ic1,localA12(:)*lambda_bar'*vol/4);
% Ass=diag(sum(Ass,2));
invAss11=sparse(1:2*nedge,1:2*nedge,1./diag(Ass11));
B=Ass(1:2*nedge,2*nedge+1:end);
C=B';
D=Ass22;
temp=D-C*invAss11*B;

%%
localsp=[-1,1,1,-1,1,-1,-1,1]'*hx/2;
ivalue=repmat(localsp,1,ne);
ix=repmat(1:ne,8,1);
Asp0=sparse(nodv,ix,ivalue);clear ivalue ix 
Asp=[Asp0,sparse(2*nedge,ne);
    sparse(2*nedge,ne),Asp0];

%% stress and rotation
localsr=zeros(16,4);
localsr(5,1)=1;localsr(6,2)=1;localsr(7,3)=-1;localsr(8,4)=-1;
localsr(9,1)=1;localsr(10,2)=-1;localsr(11,3)=1;localsr(12,4)=-1;

localsr=localsr*vol/4;
allpdof=reshape(1:(nx+1)*(ny+1),ny+1,nx+1);
ir=zeros(16*4,ne);
ic=zeros(16*4,ne);
id=1;
for i=1:nx
    for j=1:ny
localedof=[nodv(:,id);nodv(:,id)+nvdof];  ir(:,id)=repmat(localedof,4,1);
localpdof=allpdof(j:j+1,i:i+1);localpdof=localpdof(:);temp=repmat(localpdof,1,16);temp=temp';ic(:,id)=temp(:);

id=id+1;
    end
end
Ars=sparse(ir,ic,repmat(localsr(:),1,ne));
A=[Ass, Asp,Ars;
   -Asp',sparse(2*ne,2*ne+np);
   Ars',sparse(np,2*ne+np)];
%% post
% return
f1 =@(x,y) -(4*(s+t)*pi^2*cos(2*pi*x).*cos(2*pi*y)-4*(s+3*t)*pi^2*sin(2*pi*x).*sin(2*pi*y));
[xe,ye]=meshgrid(hx/2:hx:Lx-hx/2,hy/2:hy:Ly-hy/2);F1=f1(xe(:),ye(:));
F=zeros(2*ne+2*nvdof+np,1);
F(2*nvdof+1:2*nvdof+2*ne)=1*vol;
F(2*nvdof+1:2*nvdof+2*ne)=[F1;1*F1]*vol;

u=A\F;
u1_exact_f=@(x,y) sin(2*pi*x).*sin(2*pi*y);ue1=u1_exact_f(xe(:),ye(:));
u2_exact_f=@(x,y) sin(2*pi*x).*sin(2*pi*y);ue2=u2_exact_f(xe(:),ye(:));
cigma_11_f=@(x,y) (s+2*t)*2*pi*cos(2*pi*x).*sin(2*pi*y)+s*2*pi*sin(2*pi*x).*cos(2*pi*y);
cigma_12_f=@(x,y) 2*t*pi*cos(2*pi*y).*sin(2*pi*x)+2*t*pi*sin(2*pi*y).*cos(2*pi*x);
cigma_22_f=@(x,y) (s+2*t)*2*pi*sin(2*pi*x).*cos(2*pi*y)+s*2*pi*cos(2*pi*x).*sin(2*pi*y);
cigma_21_f=cigma_12_f;

ua1=u(2*nvdof+1:2*nvdof+ne);
ua2=u(2*nvdof+1+ne:2*nvdof+2*ne);
% rnorm(sqrt(ua1.^2+ua2.^2),sqrt(ue1.^2+ue2.^2));
diff=sqrt(ua1.^2+ua2.^2)-sqrt(ue1.^2+ue2.^2);
exact=sqrt(ue1.^2+ue2.^2);
Mass=vol*speye(ne);
err=sqrt(diff'*Mass*diff);
rerr=sqrt(diff'*Mass*diff)/sqrt(exact'*Mass*exact);
fprintf('size is %d\n',nx)
fprintf('relative error and error of displacement are %2.4e %2.4e\n',norm(diff)/norm(exact),sqrt(sum(diff.^2)*vol) );

% imagescsquare(ue);title('exact');
% imagescsquare(u(2*nvdof+1:2*nvdof+ne))
% imagescsquare(u(2*nvdof+1+ne:2*nvdof+2*ne))
if errcase==1
s11e=zeros(ne,1);s11a=zeros(ne,1);s12e=zeros(ne,1);s12a=zeros(ne,1);s21e=zeros(ne,1);s21a=zeros(ne,1);s22e=zeros(ne,1);s22a=zeros(ne,1);
else
s11e=zeros(2*ny,2*nx);s11a=zeros(2*ny,2*nx);s12e=zeros(2*ny,2*nx);s12a=zeros(2*ny,2*nx);s21e=zeros(2*ny,2*nx);s21a=zeros(2*ny,2*nx);s22e=zeros(2*ny,2*nx);s22a=zeros(2*ny,2*nx);
end
id=1;
for i=1:nx
    for j=1:ny
localsdof=[nodv(:,id);nodv(:,id)+nvdof];
locals=u(localsdof);
y1=(j-1)*hy+hy/4;x1=(i-1)*hx+hx/4;
y2=(j-1)*hy+3*hy/4;x2=x1;
y3=y1;x3=(i-1)*hx+3*hx/4;
y4=y2;x4=x3;

if errcase==1
s11e(id)=(cigma_11_f(x1,y1)+cigma_11_f(x2,y2)+cigma_11_f(x3,y3)+cigma_11_f(x4,y4))/4;s11a(id)=(locals(1)-locals(2)+locals(3)-locals(4))/4;
s12e(id)=(cigma_12_f(x1,y1)+cigma_12_f(x2,y2)+cigma_12_f(x3,y3)+cigma_12_f(x4,y4))/4;s12a(id)=(-locals(5)-locals(6)+locals(7)+locals(8))/4;
s21e(id)=(cigma_21_f(x1,y1)+cigma_21_f(x2,y2)+cigma_21_f(x3,y3)+cigma_21_f(x4,y4))/4;s21a(id)=(locals(9)-locals(10)+locals(11)-locals(12))/4;
s22e(id)=(cigma_22_f(x1,y1)+cigma_22_f(x2,y2)+cigma_22_f(x3,y3)+cigma_22_f(x4,y4))/4;s22a(id)=(-locals(13)-locals(14)+locals(15)+locals(16))/4;

% disp('......')
% fprintf('exact %2.3f %2.3f %2.3f %2.3f\n',cigma_11_f(x1,y1),cigma_11_f(x2,y2),cigma_11_f(x3,y3),cigma_11_f(x4,y4) );
% fprintf('app %2.3f %2.3f %2.3f %2.3f\n',locals(5), -locals(6),locals(3),-locals(4));
% 
% fprintf('exact %2.3f %2.3f %2.3f %2.3f\n',cigma_12_f(x1,y1),cigma_12_f(x2,y2),cigma_12_f(x3,y3),cigma_12_f(x4,y4) );
% fprintf('app %2.3f %2.3f %2.3f %2.3f\n',-locals(5), -locals(6),locals(7),locals(8));
% s11e(id)
% s11a(id)

% s11e(id)=(cigma_11_f(x1,y1)+0*cigma_11_f(x2,y2)+0*cigma_11_f(x3,y3)+0*cigma_11_f(x4,y4))/1;s11a(id)=(locals(1)-0*locals(2)+0*locals(3)-0*locals(4))/1;
% s12e(id)=(cigma_12_f(x1,y1)+0*cigma_12_f(x2,y2)+0*cigma_12_f(x3,y3)+0*cigma_12_f(x4,y4))/1;s12a(id)=(-locals(5)-0*locals(6)+0*locals(7)+0*locals(8))/1;
% s21e(id)=(cigma_21_f(x1,y1)+0*cigma_21_f(x2,y2)+0*cigma_21_f(x3,y3)+0*cigma_21_f(x4,y4))/1;s21a(id)=(locals(9)-0*locals(10)+0*locals(11)-0*locals(12))/1;
% s22e(id)=(cigma_22_f(x1,y1)+0*cigma_22_f(x2,y2)+0*cigma_22_f(x3,y3)+0*cigma_22_f(x4,y4))/1;s22a(id)=(-locals(13)-0*locals(14)+0*locals(15)+0*locals(16))/1;
else
s11e( j*2-1:j*2,i*2-1:i*2)=[cigma_11_f(x1,y1),cigma_11_f(x3,y3);cigma_11_f(x2,y2),cigma_11_f(x4,y4)];
s12e( j*2-1:j*2,i*2-1:i*2)=[cigma_12_f(x1,y1),cigma_12_f(x3,y3);cigma_12_f(x2,y2),cigma_12_f(x4,y4)];
s21e( j*2-1:j*2,i*2-1:i*2)=[cigma_21_f(x1,y1),cigma_21_f(x3,y3);cigma_21_f(x2,y2),cigma_21_f(x4,y4)];
s22e( j*2-1:j*2,i*2-1:i*2)=[cigma_22_f(x1,y1),cigma_22_f(x3,y3);cigma_22_f(x2,y2),cigma_22_f(x4,y4)];
s11a( j*2-1:j*2,i*2-1:i*2)=[locals(1),locals(3);-locals(2),-locals(4)];
s12a( j*2-1:j*2,i*2-1:i*2)=[-locals(5),locals(7);-locals(6),locals(8)];
s21a( j*2-1:j*2,i*2-1:i*2)=[locals(9),locals(11);-locals(10),-locals(12)];
s22a( j*2-1:j*2,i*2-1:i*2)=[-locals(13),locals(15);-locals(14),locals(16)];
end
% disp('.....')
% fprintf('exact %2.3f %2.3f %2.3f %2.3f\n',cigma_11_f(x1,y1),cigma_11_f(x2,y2),cigma_11_f(x3,y3),cigma_11_f(x4,y4) );
% fprintf('app %2.3f %2.3f %2.3f %2.3f\n',locals(1), -locals(2),locals(3),-locals(4));
        id=id+1;
    end
end
s11a=s11a(:);s12a=s12a(:);s21a=s21a(:);s22a=s22a(:);s11e=s11e(:);s12e=s12e(:);s21e=s21e(:);s22e=s22e(:);

se=sqrt(s11e.^2+s12e.^2+s21e.^2+s22e.^2);sa=sqrt(s11a.^2+s12a.^2+s21a.^2+s22a.^2);
diff1=se-sa;
if errcase==1
fprintf('relative error and error of stress are %2.4e %2.4e\n',norm(diff1)/norm(se),sqrt(sum(diff1.^2)*vol) );
% norm(s11a-s11e)
% norm(s12a-s12e)
% norm(s21a-s21e)
% norm(s22a-s22e)
else
fprintf('relative error and error of stress are %2.4e %2.4e\n',norm(diff1)/norm(se),sqrt(sum(diff1.^2)*vol/4) );

end
% rnorm(s11a,s11e);
% rnorm(s12a,s12e);
% rnorm(s21a,s21e);
% rnorm(s22a,s22e);

% sum(abs(s11a-s11e)*vol)
% sum(abs(s12a-s12e)*vol)
% sum( abs(s12a-s21a)*vol)
rot=u(2*nvdof+2*ne:end);
% figure();plot(rot)
% norm(s12a-s21a)
% norm(s12e-s21e)
% norm(s12a-s21a)
% figure();plot(u(2*nvdof+2*ne+1:end))
% figure();plot(s12a-s21a)
% figure();plot(s21a-s21e)
% norm(u(2*nvdof+2*ne+1:end))
% imagescsquare(s12e)
% imagescsquare(s12a)
return
if 1
    disp('velocity elimination....')
diagAvv=fsparse(ones(size(nodv)),nodv,ones(8,1)*alpha(:)')*vol/4;diagAvv=1./diagAvv;
Aeli=-(Asp'.*diagAvv)*Asp;
F=-1*vol*ones(ne,1);
ueli=Aeli\F;
imagescsquare1(ueli)
end