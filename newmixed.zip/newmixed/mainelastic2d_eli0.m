%%%% ex 1 from yotov's mpsa paper, eli
% u1_exact=@(x,y) cos(pi*x).*sin(2*pi*y);
% u2_exact=@(x,y) sin(pi*x).*cos(pi*y);
clear;
close all

nx=16*1;ny=nx;ne=nx*ny;nvet=2*ny*(nx+1);nhor=2*nx*(ny+1);nvdof=nvet+nhor;nedge=ny*(nx+1)+nx*(ny+1);
Lx=1;Ly=1;hx=Lx/nx;hy=Ly/ny;vol=hx*hy;np=(nx+1)*(ny+1);
n=20;Nx=nx/n;Ny=ny/n;
nmaxbasis=10;gs=0;q0=1;eigvalue_tol=10;tol=10^(-5);regvalue=10^(-18);
poission_ratio=0.2;
[xe,ye]=meshgrid(hx/2:hx:Lx,hy/2:hy:Ly);

lambda=123*ones(ny,nx);
mu=79.3*ones(ny,nx);
s=lambda(1,1);t=mu(1,1);
lambda=lambda(:);mu=mu(:);
lambda_bar=-lambda./(4*mu.*(lambda+mu));
mu_bar=1/2./(mu);
lambdabar_mubar=lambda_bar+mu_bar;

fprintf('nx is %d\n',nx);

%% (As,s) matrix
localA12=zeros(16,16);
localA12(1,10)=1;localA12(3,12)=1;localA12(5,14)=1;localA12(7,16)=1;
localA12(10,1)=1;localA12(12,3)=1;localA12(14,5)=1;localA12(16,7)=1;
localA11a=zeros(16,16);localA11b=zeros(16,16);localA22a=zeros(16,16);localA22b=zeros(16,16);

for i=1:2:7;localA11a(i,i)=1;end
for i=[9,11,13,15];localA11b(i,i)=1;end
for i=2:2:8;localA22a(i,i)=1;end
for i=[10,12,14,16];localA22b(i,i)=1;end
tic
[Aaug1,D,ir1,ic1,nodedof,~,nodedge,dofx1,dofx2,dofy1,dofy2]=assemble2d_matrix_partb(nx,ny,hx,hy,mu_bar);
[invAss,Ass]=assemble2d_matrix_parta(nx,ny,hx,hy,lambda,mu,localA12,localA11a,localA11b,localA22a,localA22b,ir1,ic1,nodedof);
toc

%% force
u1_exact=@(x,y) cos(pi*x).*sin(2*pi*y);ue1=u1_exact(xe(:),ye(:));
u2_exact=@(x,y) sin(pi*x).*cos(pi*y);ue2=u2_exact(xe(:),ye(:));


f1 =@(x,y) -(s+2*t)*pi^2*cos(pi*x).*sin(2*pi*y)-s*pi^2*cos(pi*x).*sin(pi*y)-4*pi^2*t*sin(2*pi*y).*cos(pi*x)-t*pi^2*sin(pi*y).*cos(pi*x);
f2 =@(x,y) -2*t*pi^2*cos(2*pi*y).*sin(pi*x)-t*pi^2*sin(pi*x).*cos(pi*y)-pi^2*(s+2*t)*cos(pi*y).*sin(pi*x)-2*s*pi^2*sin(pi*x).*cos(2*pi*y);

F1=f1(xe(:),ye(:));
F2=f2(xe(:),ye(:));
F=zeros(2*ne+2*nvdof+np,1);

%%%% diri for u1
ya=(2*hy/4:hy:1);yb=(2*hy/4:hy:1);x=zeros(1,ny);
F(dofx1(1:2:end,1))=-u1_exact(x,ya)*hy/2;F(dofx1(2:2:end,1))=-u1_exact(x,yb)*hy/2;%%% u1,x=0,
ya=(2*hy/4:hy:1);yb=(2*hy/4:hy:1);x=ones(1,ny);
F(dofx2(1:2:end,1))=u1_exact(x,ya)*hy/2;F(dofx2(2:2:end,1))=u1_exact(x,yb)*hy/2;%%% u1,x=1,%%
xa=(2*hx/4:hx:1);xb=(2*hx/4:hx:1);y=zeros(1,nx);
F(dofy1(1:2:end,1))=-u1_exact(xa,y)*hx/2;F(dofy1(2:2:end,1))=-u1_exact(xb,y)*hx/2;%%% u1,y=0,%%
xa=(2*hx/4:hx:1);xb=(2*hx/4:hx:1);y=ones(1,nx);
F(dofy2(1:2:end,1))=u1_exact(xa,y)*hx/2;F(dofy2(2:2:end,1))=u1_exact(xb,y)*hx/2;%%% u1,y=1,


%%%% diri for u2
ya=(2*hy/4:hy:1);yb=(2*hy/4:hy:1);x=zeros(1,ny);
F(dofx1(1:2:end,2))=-u2_exact(x,ya)*hy/2;F(dofx1(2:2:end,2))=-u2_exact(x,yb)*hy/2;%%% u2,x=0,
ya=(2*hy/4:hy:1);yb=(2*hy/4:hy:1);x=ones(1,ny);
F(dofx2(1:2:end,2))=u2_exact(x,ya)*hy/2;F(dofx2(2:2:end,2))=u2_exact(x,yb)*hy/2;%%% u2,x=1,%%
xa=(2*hx/4:hx:1);xb=(2*hx/4:hx:1);y=zeros(1,nx);
F(dofy1(1:2:end,2))=-u2_exact(xa,y)*hx/2;F(dofy1(2:2:end,2))=-u2_exact(xb,y)*hx/2;%%% u2,y=0,%%
xa=(2*hx/4:hx:1);xb=(2*hx/4:hx:1);y=ones(1,nx);
F(dofy2(1:2:end,2))=u2_exact(xa,y)*hx/2;F(dofy2(2:2:end,2))=u2_exact(xb,y)*hx/2;%%% u2,y=1,

F(2*nvdof+1+np:2*nvdof+2*ne+np)=[F1;1*F2]*vol;

[Aeli,Feli]=eli_matrix(invAss,Aaug1,D,F);
invArr=sparse(1:np,1:np,1./diag(Aeli(1:np,1:np)));D=Aeli(np+1:end,np+1:end); Aaug=Aeli(1:np,np+1:end);
[Aeli0,Feli0,u0,uf0]=eli(invArr,Aaug,D,Feli);

uf=zeros(2*nvdof+2*ne+np,1);uf(2*nvdof+1:end)=uf0;uf(1:2*nvdof)=-invAss*Aaug1*uf0;
u=uf;

% A=[Ass,Aaug1;
%    Aaug1',zeros(ne*2+np,ne*2+np)];
% u=A\F;
ua=sqrt(u0(1:ne).^2+u0(1+ne:end).^2);
ue=sqrt(ue1.^2+ue2.^2);
rnorm(ua,ue);
% imagescsquare1(u0(1:ne));title('app u1')
% imagescsquare1(ue1(1:ne));title('exact u1')
% imagescsquare1(ue1(1:ne)-u0(1:ne));title('diff u1')