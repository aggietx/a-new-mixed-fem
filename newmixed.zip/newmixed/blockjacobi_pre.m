function x=blockjacobi_pre(Apre,Fpre,D,ne,Lms,Ums,Pms,Qms,phi)
step=1;
x=zeros(2*ne,1);
 omega=.8;
% D=sparse(1:2*ne,1:2*ne,1./diag(Apre));
%% smooothing
for i=1:step
 x = x + omega*D*(Fpre - Apre*x);
end

%% coarse

   r=Fpre - Apre*x;
   r0=phi*r;  

   uc=Qms*(Ums\(Lms\(Pms*(r0))));
   umsfine=phi.'*uc; 
   x=x + umsfine;
%% smooothing
for i=1:step
  x = x + omega*D*(Fpre - Apre*x);
end
