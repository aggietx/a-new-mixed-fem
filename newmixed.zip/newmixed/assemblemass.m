function [mass,nod]=assemblemass(ny,nx,hx,hy,coeff)
np=(nx+1)*(ny+1);
dof=reshape(1:np,ny+1,nx+1);
ne=nx*ny;
nod=zeros(ne,4);
dof1=dof(1:end-1,1:end-1);
dof2=dof(2:end,1:end-1);
dof3=dof(1:end-1,2:end);
dof4=dof(2:end,2:end);
nod(:,1)=dof1(:);
nod(:,2)=dof2(:);
nod(:,3)=dof3(:);
nod(:,4)=dof4(:);
localmass=[1/9,1/18,1/18,1/36;
           1/18,1/9,1/36,1/18;
           1/18,1/36,1/9,1/18;
           1/36,1/18,1/18,1/9];
nod=nod';

ir=zeros(16*1,ne);
ic=zeros(16*1,ne);
id=1;
for i=1:nx
    for j=1:ny
localedof=nod(:,id);  ir(:,id)=repmat(localedof,4,1);
temp=repmat(localedof,1,4);temp=temp';ic(:,id)=temp(:);

id=id+1;
    end
end

mass=sparse(ir,ic,localmass(:)*coeff(:)'*hx*hy);