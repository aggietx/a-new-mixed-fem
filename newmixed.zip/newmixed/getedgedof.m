function [X,Y,Z] = getedgedof(x,y)
%%% eli
point = cell(x+1,y+1);
line = zeros(x+1,2*y);
column = zeros(2*x,y+1);
pointline = zeros(4,(x+1*y+1));
count = 1;
a = 1;
for j = 1:y+1
    for i = 1:x+1
        point{x+2-i,j} = Point(x+2-i,j,a);
        if point{x+2-i,j}.y ~= y+1
            point{x+2-i,j}.right = count;
            count = count + 1;
        end
        if point{x+2-i,j}.x ~= 1
            point{x+2-i,j}.up = count;
            count = count + 1;
        end
        if point{x+2-i,j}.y ~=1
            point{x+2-i,j}.left = count;
            count = count + 1;
        end
        if point{x+2-i,j}.x ~= x+1
            point{x+2-i,j}.down = count;
            count = count + 1;
        end
    end
    a = a + 1;

end

a = 1;
for j = 1:y+1
    for i = 1:x+1
        if point{x+2-i,j}.right ~= 0

            line(x+2-i,2*point{x+2-i,j}.y-1) = point{x+2-i,j}.right;
        end
        if point{x+2-i,j}.left ~= 0

            line(x+2-i,2*point{x+2-i,j}.y-2) = point{x+2-i,j}.left;
        end
        if point{x+2-i,j}.down ~= 0

            column(2*point{x+2-i,j}.x-1,j) = point{x+2-i,j}.down;
        end
        if point{x+2-i,j}.up ~= 0

            column(2*point{x+2-i,j}.x-2,j) = point{x+2-i,j}.up;
        end

        a = a + 1;
    end

end

a = 1;
for j = 1:y+1
    for i = 1:x+1
        pointline(1,a) = point{x+2-i,j}.right;
        pointline(2,a) = point{x+2-i,j}.up;
        pointline(3,a) = point{x+2-i,j}.left;
        pointline(4,a) = point{x+2-i,j}.down;
        a = a + 1;
    end

end


X = line;
Y = column;
X=X(end:-1:1,:);
Y=Y(end:-1:1,:);
Z = pointline;
% disp(X)
% disp(Y)
% disp(Z)
% disp(point)
% disp(point{1,1})
% disp(point{2,1})
% disp(point{2,2})
% disp(point{1,2})