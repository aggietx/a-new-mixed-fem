function computeweightmasserror2d(a,b,hx,hy,ny,nx,masscoeff)
a=a(:);b=b(:);
mass=assemblemass(ny,nx,hx,hy,masscoeff);

diff=a-b;

error=(diff'*mass*diff)/(b'*mass*b);
error=sqrt(error);
fprintf('weight mass relative error is %2.4e\n',error);