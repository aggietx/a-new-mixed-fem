function Avp=assembleAvp2d(hx,ne,nodv)
localvp=[-1,-1,1,1,-1,1,-1,1]'*hx/2;
ivalue=repmat(localvp,1,ne);
ix=repmat(1:ne,8,1);
Avp=sparse(nodv,ix,ivalue);clear ivalue ix 
