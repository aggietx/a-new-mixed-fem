function [As,diagAs]=operatorA(s,t,sigma)
tr=trace(sigma);
n=size(sigma,1);
As=s*tr*eye(n)+t*sigma;
diagAs=diag(As);

