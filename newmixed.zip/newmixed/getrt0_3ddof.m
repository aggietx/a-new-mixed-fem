function [nod,facex1,facex2,facey1,facey2,facez1,facez2,bddof]=getrt0_3ddof(nx,ny,nz)
%%%% (x,y,z)

ne=nx*ny*nz;
dofx=reshape(1:(nx+1)*ny*nz,nx+1,ny,nz);
dofy=reshape(1:(ny+1)*nx*nz,nx,ny+1,nz)+(nx+1)*ny*nz;
dofz=reshape(1:(nz+1)*ny*nx,nx,ny,nz+1)+(nx+1)*ny*nz+(ny+1)*nx*nz;
facex1=dofx(1,:,:);facex1=facex1(:);
facex2=dofx(end,:,:);facex2=facex2(:);
facey1=dofy(:,1,:);facey1=facey1(:);
facey2=dofy(:,end,:);facey2=facey2(:);
facez1=dofz(:,:,1);facez1=facez1(:);
facez2=dofz(:,:,end);facez2=facez2(:);
bddof=[facex1(:);facex2(:);facey1(:);facey2(:);facez1(:);facez2(:)];
nod=zeros(6,ne);
id=1;
for iz=1:nz
    for iy=1:ny
        for ix=1:nx
    ldofyz1=dofx(ix, iy, iz);
    ldofyz2=dofx(ix+1, iy, iz);
    ldofxz1=dofy(ix, iy,     iz);
    ldofxz2=dofy(ix, iy+1,   iz);
    ldofxy1=dofz(ix, iy, iz);
    ldofxy2=dofz(ix, iy, iz+1);
    nod(:,id)=[ldofyz1(:);ldofyz2(:);ldofxz1(:);ldofxz2(:);ldofxy1(:);ldofxy2(:)];
    id=id+1;
        end
    end
end