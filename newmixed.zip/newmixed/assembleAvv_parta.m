function [ir1,ic1,localA23]=assembleAvv_parta(ne,nodv)


localA23=zeros(24,24);
pair=[1,9,17;
     2,13,19;
     3,11,21;
     4,15,23;
     5,10,18;
     6,14,20;
     7,12,22;
     8,16,24];
for i=1:8
localA23(pair(i,2),pair(i,3))=1;
localA23(pair(i,3),pair(i,2))=1;
end
nzid=find(localA23(:));


ir1=kron(nodv,ones(1,24));ir1=reshape(ir1(:),24^2,ne);ir1=ir1(nzid,:);
ic1=kron(nodv,ones(24,1));

ic1=ic1(nzid,:);
localA23=localA23(nzid);
