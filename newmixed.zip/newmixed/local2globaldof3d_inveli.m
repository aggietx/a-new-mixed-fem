function [nod,facex1,facex2,facey1,facey2,facez1,facez2,nodedof]=local2globaldof3d_inveli(nx,ny,nz)
%%%% (x,y,z)

ne=nx*ny*nz;
[dofyz,dofxz,dofxy,nodedof] = getelidof3d(nx,ny,nz);
facex1=dofyz(1,:,:);facex1=reshape(facex1(:),2*ny,2*nz);  
facex2=dofyz(end,:,:);facex2=reshape(facex2(:),2*ny,2*nz);
facey1=dofxz(:,1,:);facey1=reshape(facey1(:),2*nx,2*nz); 
facey2=dofxz(:,end,:);facey2=reshape(facey2(:),2*nx,2*nz);
facez1=dofxy(:,:,1);facez1=reshape(facez1(:),2*nx,2*ny);  
facez2=dofxy(:,:,end);facez2=reshape(facez2(:),2*nx,2*ny);
nod=zeros(24,ne);
id=1;
for iz=1:nz
    for iy=1:ny
        for ix=1:nx
    ldofyz1=dofyz(ix,     2*iy-1:2*iy, 2*iz-1:2*iz);
    ldofyz2=dofyz(ix+1,     2*iy-1:2*iy, 2*iz-1:2*iz);
    ldofxz1=dofxz(2*ix-1:2*ix, iy,     2*iz-1:2*iz);
    ldofxz2=dofxz(2*ix-1:2*ix, iy+1,     2*iz-1:2*iz);
    ldofxy1=dofxy(2*ix-1:2*ix, 2*iy-1:2*iy, iz);
    ldofxy2=dofxy(2*ix-1:2*ix, 2*iy-1:2*iy, iz+1);
    nod(:,id)=[ldofyz1(:);ldofyz2(:);ldofxz1(:);ldofxz2(:);ldofxy1(:);ldofxy2(:)];
    id=id+1;
        end
    end
end