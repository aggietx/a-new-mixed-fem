function [nodedge,facex1,facex2,facey1,facey2,nodedof]=getelidof2delastic(nx,ny)
[edge_hor,edge_vec,nodedof] = getedgedof(ny,nx);
% bddof=[edge_hor(1,:)';edge_hor(end,:)';edge_vec(:,1);edge_vec(:,end)];bddof=sort(bddof);bddof=[bddof*2-1;bddof*2];
ne=nx*ny; 
facex1=edge_vec(:,1);[~,facex1]=vectorize_eli2d(facex1); facex1=reshape(facex1,2*ny,2);  
facex2=edge_vec(:,end);[~,facex2]=vectorize_eli2d(facex2);facex2=reshape(facex2(:),2*ny,2);
facey1=edge_hor(1,:);[~,facey1]=vectorize_eli2d(facey1);facey1=reshape(facey1(:),2*nx,2); 
facey2=edge_hor(end,:);[~,facey2]=vectorize_eli2d(facey2);facey2=reshape(facey2(:),2*nx,2);

nodedge=zeros(16,ne);

id=1;
for i=1:nx
    for j=1:ny
        dof1=edge_vec(j*2-1,i);dof2=edge_vec(j*2,i); dof3=edge_vec(j*2-1,i+1);dof4=edge_vec(j*2,i+1);
        dof5=edge_hor(j,i*2-1);dof6=edge_hor(j+1,i*2-1);dof7=edge_hor(j,i*2);dof8=edge_hor(j+1,i*2);%%%%%%%%%%%%%%%%%%%%%%%
localedof=[dof1*2-1:dof1*2,dof2*2-1:dof2*2,dof3*2-1:dof3*2,dof4*2-1:dof4*2,dof5*2-1:dof5*2,dof6*2-1:dof6*2,dof7*2-1:dof7*2,dof8*2-1:dof8*2]';
nodedge(:,id)=localedof;
id=id+1;
    end
end