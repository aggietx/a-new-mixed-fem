function imagescsquare1(u)
u=real(u);
if size(u,1)==1
    u=u';
end
if size(u,1)==size(u,2)
    n=(size(u,1));
else
n=sqrt(size(u,1));
end
if size(u,1)==size(u,2)
    figure();imagesc(u);colorbar
else
    figure();imagesc(reshape(u,n,n));colorbar
end

colormap(jet)
set(gca,'fontsize',15);
set(gca,'YDir','normal')