function [M,N]=gs_matrix(Kd,omega)
    ne=size(Kd,1);
    D=sparse(1:ne,1:ne,diag(Kd));
    L1 = tril(Kd,-1);
    N = D + omega*L1;
    M = (1 - omega)*D - omega*triu(Kd,1);
