function model=generate_3dbbdc_model2(N,n,maxval)
%%%% model (figure 4.2) in paper "A FRUGAL FETI-DP AND BDDC COARSE SPACE
% % FOR HETEROGENEOUS PROBLEMS"

% model=generate_3dbbdc_model2(3,12,100);imagescsquare1(model(:,:,1));imagescsquare1(model(:,:,13));

if mod(n,6)~=0
disp('n must be divided by 6')
end
disp('bddc model 2')
n0=floor(n/6);
n1=floor(n/3);
range1=n0+1:n0+n1;range2=n0+n1+1:n0+n1+n1;
range=n1+1:n1+n1;

cell1=ones(n,n,n);cell1(range,range1,:)=maxval;
cell2=ones(n,n,n);cell2(range,range2,:)=maxval;

model=zeros(N*n,N*n,N*n);


for i3=1:2:N
    for i2=1:N
        for i1=1:N
           model( (i1-1)*n+1:i1*n,(i2-1)*n+1:i2*n,(i3-1)*n+1:i3*n)=cell1;  
        end
    end
end

for i3=2:2:N
    for i2=1:N
        for i1=1:N
            model((i1-1)*n+1:i1*n,(i2-1)*n+1:i2*n,(i3-1)*n+1:i3*n)=cell2;
        end
    end
end

