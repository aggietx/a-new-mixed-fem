localAss=zeros(36,36);
localAsr=zeros(36,3*8);
localAsp=zeros(36,24);
%% basis x face
% ii=1;id1=getid(1,1,1);id2=getid(2,1,1);
ii=1;id1=1;id2=2;
localAss(1,1)=lm(id1)+lm(id2);localAss(1,14)=l(id1);localAss(1,17)=l(id2);
                                  localAss(1,27)=l(id1);localAss(1,30)=l(id2);
localAss(2,2)=m(id1)+m(id2);localAss(3,3)=m(id1)+m(id2);
%localAsr(ii+1,3)=-m(id1)-m(id2);localAsr(ii+2,2)=-m(id1)-m(id2);
localAsr(ii+1,id1+8*2 )=-mc(id1);localAsr(ii+1,id2+8*2 )=-mc(id2);
localAsr(ii+2,id1+8*1 )=-mc(id1);localAsr(ii+2,id2+8*1 )=-mc(id2);
localAsp(ii,id1 )=-mc(id1);localAsp(ii,id2 )=mc(id2);
localAsp(ii+1,id1+8 )=-mc(id1);localAsp(ii+1,id2+8 )=mc(id2);
localAsp(ii+2,id1+8*2 )=-mc(id1);localAsp(ii+2,id2+8*2 )=mc(id2);

% ii=4;id1=getid(1,2,1);id2=getid(2,2,1);
ii=4;id1=3;id2=4;
localAss(4,4)=lm(id1)+lm(id2);localAss(4,14)=l(id1);localAss(4,17)=l(id2);
                                  localAss(4,33)=l(id1);localAss(4,36)=l(id2);                                 
localAss(5,5)=m(id1)+m(id2);localAss(6,6)=m(id1)+m(id2);  
%localAsr(ii+1,3)=-m(id1)-m(id2);localAsr(ii+2,2)=-m(id1)-m(id2);
localAsr(ii+1,id1+8*2 )=-mc(id1);localAsr(ii+1,id2+8*2 )=-mc(id2);
localAsr(ii+2,id1+8*1 )=-mc(id1);localAsr(ii+2,id2+8*1 )=-mc(id2);
localAsp(ii,id1 )=-mc(id1);localAsp(ii,id2 )=mc(id2);
localAsp(ii+1,id1+8 )=-mc(id1);localAsp(ii+1,id2+8 )=mc(id2);
localAsp(ii+2,id1+8*2 )=-mc(id1);localAsp(ii+2,id2+8*2 )=mc(id2);

% ii=7;id1=getid(1,1,2);id2=getid(2,1,2);
ii=7;id1=5;id2=6;
localAss(ii,ii)=lm(id1)+lm(id2);localAss(ii,20)=l(id1);localAss(ii,23)=l(id2);
                                  localAss(ii,27)=l(id1);localAss(ii,30)=l(id2);
localAss(ii+1,ii+1)=m(id1)+m(id2);localAss(ii+2,ii+2)=m(id1)+m(id2); 
%localAsr(ii+1,3)=-m(id1)-m(id2);localAsr(ii+2,2)=-m(id1)-m(id2);
localAsr(ii+1,id1+8*2 )=-mc(id1);localAsr(ii+1,id2+8*2 )=-mc(id2);
localAsr(ii+2,id1+8*1 )=-mc(id1);localAsr(ii+2,id2+8*1 )=-mc(id2);
localAsp(ii,id1 )=-mc(id1);localAsp(ii,id2 )=mc(id2);
localAsp(ii+1,id1+8 )=-mc(id1);localAsp(ii+1,id2+8 )=mc(id2);
localAsp(ii+2,id1+8*2 )=-mc(id1);localAsp(ii+2,id2+8*2 )=mc(id2);

% ii=10;id1=getid(1,2,2);id2=getid(2,2,2);
ii=10;id1=7;id2=8;
localAss(ii,ii)=lm(id1)+lm(id2);localAss(ii,20)=l(id1);localAss(ii,23)=l(id2);
                                  localAss(ii,33)=l(id1);localAss(ii,36)=l(id2);
localAss(ii+1,ii+1)=m(id1)+m(id2);localAss(ii+2,ii+2)=m(id1)+m(id2);
%localAsr(ii+1,3)=-m(id1)-m(id2);localAsr(ii+2,2)=-m(id1)-m(id2);
localAsr(ii+1,id1+8*2 )=-mc(id1);localAsr(ii+1,id2+8*2 )=-mc(id2);
localAsr(ii+2,id1+8*1 )=-mc(id1);localAsr(ii+2,id2+8*1 )=-mc(id2);
localAsp(ii,id1 )=-mc(id1);localAsp(ii,id2 )=mc(id2);
localAsp(ii+1,id1+8 )=-mc(id1);localAsp(ii+1,id2+8 )=mc(id2);
localAsp(ii+2,id1+8*2 )=-mc(id1);localAsp(ii+2,id2+8*2 )=mc(id2);
%% basis y face
% ii=13;id1=getid(1,1,1);id2=getid(1,2,1);
ii=13;id1=1;id2=3;
localAss(ii+1,ii+1)=lm(id1)+lm(id2);localAss(ii+1,1)=l(id1);localAss(ii+1,4)=l(id2);
                                  localAss(ii+1,27)=l(id1);localAss(ii+1,33)=l(id2);
localAss(ii,ii)=m(id1)+m(id2);localAss(ii+2,ii+2)=m(id1)+m(id2);
% localAsr(ii,3)=m(id1)+m(id2);localAsr(ii+2,1)=-m(id1)-m(id2);
localAsr(ii,id1+8*2 )=mc(id1);localAsr(ii,id2+8*2 )=mc(id2);
localAsr(ii+2,id1+8*0 )=-mc(id1);localAsr(ii+2,id2+8*0 )=-mc(id2);

localAsp(ii,id1 )=-mc(id1);localAsp(ii,id2 )=mc(id2);
localAsp(ii+1,id1+8 )=-mc(id1);localAsp(ii+1,id2+8 )=mc(id2);
localAsp(ii+2,id1+8*2 )=-mc(id1);localAsp(ii+2,id2+8*2 )=mc(id2);

% ii=16;id1=getid(2,1,1);id2=getid(2,2,1);
ii=16;id1=2;id2=4;
localAss(ii+1,ii+1)=lm(id1)+lm(id2);localAss(ii+1,1)=l(id1);localAss(ii+1,4)=l(id2);
                                  localAss(ii+1,30)=l(id1);localAss(ii+1,36)=l(id2);
localAss(ii,ii)=m(id1)+m(id2);localAss(ii+2,ii+2)=m(id1)+m(id2);
% localAsr(ii,3)=m(id1)+m(id2);localAsr(ii+2,1)=-m(id1)-m(id2);
localAsr(ii,id1+8*2 )=mc(id1);localAsr(ii,id2+8*2 )=mc(id2);
localAsr(ii+2,id1+8*0 )=-mc(id1);localAsr(ii+2,id2+8*0 )=-mc(id2);
localAsp(ii,id1 )=-mc(id1);localAsp(ii,id2 )=mc(id2);
localAsp(ii+1,id1+8 )=-mc(id1);localAsp(ii+1,id2+8 )=mc(id2);
localAsp(ii+2,id1+8*2 )=-mc(id1);localAsp(ii+2,id2+8*2 )=mc(id2);

% ii=19;id1=getid(1,1,2);id2=getid(1,2,2);
ii=19;id1=5;id2=7;
localAss(ii+1,ii+1)=lm(id1)+lm(id2);localAss(ii+1,7)=l(id1);localAss(ii+1,10)=l(id2);
                                  localAss(ii+1,27)=l(id1);localAss(ii+1,33)=l(id2);
localAss(ii,ii)=m(id1)+m(id2);localAss(ii+2,ii+2)=m(id1)+m(id2);
% localAsr(ii,3)=m(id1)+m(id2);localAsr(ii+2,1)=-m(id1)-m(id2);
localAsr(ii,id1+8*2 )=mc(id1);localAsr(ii,id2+8*2 )=mc(id2);
localAsr(ii+2,id1+8*0 )=-mc(id1);localAsr(ii+2,id2+8*0 )=-mc(id2);
localAsp(ii,id1 )=-mc(id1);localAsp(ii,id2 )=mc(id2);
localAsp(ii+1,id1+8 )=-mc(id1);localAsp(ii+1,id2+8 )=mc(id2);
localAsp(ii+2,id1+8*2 )=-mc(id1);localAsp(ii+2,id2+8*2 )=mc(id2);

% ii=22;id1=getid(2,1,2);id2=getid(2,2,2);
ii=22;id1=6;id2=8;
localAss(ii+1,ii+1)=lm(id1)+lm(id2);localAss(ii+1,7)=l(id1);localAss(ii+1,10)=l(id2);
                                  localAss(ii+1,30)=l(id1);localAss(ii+1,36)=l(id2);
localAss(ii,ii)=m(id1)+m(id2);localAss(ii+2,ii+2)=m(id1)+m(id2);
% localAsr(ii,3)=m(id1)+m(id2);localAsr(ii+2,1)=-m(id1)-m(id2);
localAsr(ii,id1+8*2 )=mc(id1);localAsr(ii,id2+8*2 )=mc(id2);
localAsr(ii+2,id1+8*0 )=-mc(id1);localAsr(ii+2,id2+8*0 )=-mc(id2);
localAsp(ii,id1 )=-mc(id1);localAsp(ii,id2 )=mc(id2);
localAsp(ii+1,id1+8 )=-mc(id1);localAsp(ii+1,id2+8 )=mc(id2);
localAsp(ii+2,id1+8*2 )=-mc(id1);localAsp(ii+2,id2+8*2 )=mc(id2);

%% basis z face
% ii=25;id1=getid(1,1,1);id2=getid(1,1,2);
ii=25;id1=1;id2=5;
localAss(ii+2,ii+2)=lm(id1)+lm(id2);localAss(ii+2,1)=l(id1);localAss(ii+2,7)=l(id2);
                                  localAss(ii+2,14)=l(id1);localAss(ii+2,20)=l(id2);
localAss(ii,ii)=m(id1)+m(id2);localAss(ii+1,ii+1)=m(id1)+m(id2);
% localAsr(ii,2)=m(id1)+m(id2);localAsr(ii+1,1)=m(id1)+m(id2);
localAsr(ii,id1+8*1 )=mc(id1);localAsr(ii,id2+8*1 )=mc(id2);
localAsr(ii+1,id1+8*0 )=mc(id1);localAsr(ii+1,id2+8*0 )=mc(id2);

localAsp(ii,id1 )=-mc(id1);localAsp(ii,id2 )=mc(id2);
localAsp(ii+1,id1+8 )=-mc(id1);localAsp(ii+1,id2+8 )=mc(id2);
localAsp(ii+2,id1+8*2 )=-mc(id1);localAsp(ii+2,id2+8*2 )=mc(id2);

% ii=28;id1=getid(2,1,1);id2=getid(2,1,2);
ii=28;id1=2;id2=6;
localAss(ii+2,ii+2)=lm(id1)+lm(id2);localAss(ii+2,1)=l(id1);localAss(ii+2,7)=l(id2);
                                  localAss(ii+2,17)=l(id1);localAss(ii+2,23)=l(id2);
localAss(ii,ii)=m(id1)+m(id2);localAss(ii+1,ii+1)=m(id1)+m(id2);
% localAsr(ii,2)=m(id1)+m(id2);localAsr(ii+1,1)=m(id1)+m(id2);
localAsr(ii,id1+8*1 )=mc(id1);localAsr(ii,id2+8*1 )=mc(id2);
localAsr(ii+1,id1+8*0 )=mc(id1);localAsr(ii+1,id2+8*0 )=mc(id2);
localAsp(ii,id1 )=-mc(id1);localAsp(ii,id2 )=mc(id2);
localAsp(ii+1,id1+8 )=-mc(id1);localAsp(ii+1,id2+8 )=mc(id2);
localAsp(ii+2,id1+8*2 )=-mc(id1);localAsp(ii+2,id2+8*2 )=mc(id2);

% ii=31;id1=getid(1,2,1);id2=getid(1,2,2);
ii=31;id1=3;id2=7;
localAss(ii+2,ii+2)=lm(id1)+lm(id2);localAss(ii+2,4)=l(id1);localAss(ii+2,10)=l(id2);
                                  localAss(ii+2,14)=l(id1);localAss(ii+2,20)=l(id2);
localAss(ii,ii)=m(id1)+m(id2);localAss(ii+1,ii+1)=m(id1)+m(id2);
% localAsr(ii,2)=m(id1)+m(id2);localAsr(ii+1,1)=m(id1)+m(id2);
localAsr(ii,id1+8*1 )=mc(id1);localAsr(ii,id2+8*1 )=mc(id2);
localAsr(ii+1,id1+8*0 )=mc(id1);localAsr(ii+1,id2+8*0 )=mc(id2);
localAsp(ii,id1 )=-mc(id1);localAsp(ii,id2 )=mc(id2);
localAsp(ii+1,id1+8 )=-mc(id1);localAsp(ii+1,id2+8 )=mc(id2);
localAsp(ii+2,id1+8*2 )=-mc(id1);localAsp(ii+2,id2+8*2 )=mc(id2);

% ii=34;id1=getid(2,2,1);id2=getid(2,2,2);
ii=34;id1=4;id2=8;
localAss(ii+2,ii+2)=lm(id1)+lm(id2);localAss(ii+2,4)=l(id1);localAss(ii+2,10)=l(id2);
                                  localAss(ii+2,17)=l(id1);localAss(ii+2,23)=l(id2);
localAss(ii,ii)=m(id1)+m(id2);localAss(ii+1,ii+1)=m(id1)+m(id2);
% localAsr(ii,2)=m(id1)+m(id2);localAsr(ii+1,1)=m(id1)+m(id2);
localAsr(ii,id1+8*1 )=mc(id1);localAsr(ii,id2+8*1 )=mc(id2);
localAsr(ii+1,id1+8*0 )=mc(id1);localAsr(ii+1,id2+8*0 )=mc(id2);
localAsp(ii,id1 )=-mc(id1);localAsp(ii,id2 )=mc(id2);
localAsp(ii+1,id1+8 )=-mc(id1);localAsp(ii+1,id2+8 )=mc(id2);
localAsp(ii+2,id1+8*2 )=-mc(id1);localAsp(ii+2,id2+8*2 )=mc(id2);

localAss=localAss*vol/8;
localAsr=localAsr*vol/8;
localAsp=localAsp*hx*hy/4;