disp('generate all matrix in dual grid wiht local elimination, continuous case...')
tm=tic;
%%% generate Ass in dual mesh
% % nodedof=nodeface(nx,ny,nz);
% % nodedofv=zeros(36,np);nodedofv(1:3:end,:)=nodedof*3-2;nodedofv(2:3:end,:)=nodedof*3-1;
% % nodedofv(3:3:end,:)=nodedof*3;%find(nodedofv(:,1)==1);
% % nodedofv2=nodedofv;nodedofv2(nodedofv<=0)=1;



maske=ones(nx+2,ny+2,nz+2);
maske(2:end-1,2:end-1,2:end-1)=reshape(1:nx*ny*nz,nx,ny,nz);
nodee=zeros(24,np); %%% element dof associate with a node
id=1;
for i3=1:nx3+1
  for i2=1:nx2+1
    for i1=1:nx1+1
        locale=maske(i1:i1+1,i2:i2+1,i3:i3+1);locale=locale(:);
nodee(:,id)=[locale;locale+ne;locale+2*ne];
id=id+1;
    end
  end
end
maskcoeff=zeros(nx+2,ny+2,nz+2);maskcoeff(2:end-1,2:end-1,2:end-1)=1;
allm=cell(np,1);alll=cell(np,1);allmc=cell(np,1);
markudof=ones(nx+2,ny+2,nz+2);markudof(2:end-1,2:end-1,2:end-1)=reshape(1:nx*ny*nz,nx,ny,nz);
markudof1=zeros(nx+2,ny+2,nz+2);markudof1(2:end-1,2:end-1,2:end-1)=reshape(1:nx*ny*nz,nx,ny,nz);
alludof=zeros(24,np);
alleli=zeros(24^2,np);
F1=reshape(F1,nx,ny,nz);maskF1=zeros(nx+2,ny+2,nz+2);maskF1(2:end-1,2:end-1,2:end-1)=F1*vol/8;
F2=reshape(F2,nx,ny,nz);maskF2=zeros(nx+2,ny+2,nz+2);maskF2(2:end-1,2:end-1,2:end-1)=F2*vol/8;
F3=reshape(F3,nx,ny,nz);maskF3=zeros(nx+2,ny+2,nz+2);maskF3(2:end-1,2:end-1,2:end-1)=F3*vol/8;
alleliF=zeros(24,np);
alllocalF=zeros(24,np);
id=1;
for i3=1:nx3+1
  for i2=1:nx2+1
    for i1=1:nx1+1
alll{id}=lambda_bare(i1:i1+1,i2:i2+1,i3:i3+1);
allm{id}=mu_bare(i1:i1+1,i2:i2+1,i3:i3+1);
allmc{id}=maskcoeff(i1:i1+1,i2:i2+1,i3:i3+1);
temp0=markudof(i1:i1+1,i2:i2+1,i3:i3+1);temp0=temp0(:);
temp=[temp0;temp0+ne;temp0+2*ne];alludof(:,id)=temp;

temp=maskF1(i1:i1+1,i2:i2+1,i3:i3+1);localF1=temp(:);
temp=maskF2(i1:i1+1,i2:i2+1,i3:i3+1);localF2=temp(:);
temp=maskF3(i1:i1+1,i2:i2+1,i3:i3+1);localF3=temp(:);
alllocalF(:,id)=[localF1;localF2;localF3];
id=id+1;
    end
  end
end
allAaugl=cell(np,1);
alllocalFeli=cell(np,1);
allinvlocalArr=cell(np,1);
allAagul2=cell(np,1);
allinvlocalAss=cell(np,1);
alllocalFface=cell(np,1);
allnzid=cell(np,1);
%%% i1=2;i2=2;i3=2;
%%% i1=1;i1=1;i1=1;
%%% (i3-1)*(nx1+1)*(nx2+1)+(i2-1)*(nx1+1)+i1
parfor id=1:np   
i3 = ceil(id / ( (ny+1) * (nz+1)));
i2 = ceil((id - (i3-1) * (ny+1) * (nz+1)) / (ny+1));
i1 = id - (ny+1) * (i2-1 + (nz+1) * (i3-1));

% localdof=nodedof(:,id);nzid=find(localdof);nzid=vectorize_eli(nzid);   

l=alll{id};m=allm{id};mc=allmc{id};
lm=l+m;
[localAss1,localAsr1,localAsp1]=computelocaldualmatrix_continuous(lm,l,m,mc,vol,hx,hy);
nzid=[];
for i=1:36
    if norm(localAss1(i,:))>0
    nzid=[nzid;i];
    end
end
localAss=localAss1(nzid,nzid);
localAss=sparse(localAss);
%% set bd condition
localF1=zeros(36,1);
a=gx1(i1,i2*2-1:i2*2,i3*2-1:i3*2);a=a(:);
b=gx2(i1,i2*2-1:i2*2,i3*2-1:i3*2);b=b(:);
c=gx3(i1,i2*2-1:i2*2,i3*2-1:i3*2);c=c(:);d=[a,b,c];d=d';localF1(1:12)=d(:);

a=gy1(i1*2-1:i1*2,i2,i3*2-1:i3*2);a=a(:);
b=gy2(i1*2-1:i1*2,i2,i3*2-1:i3*2);b=b(:);
c=gy3(i1*2-1:i1*2,i2,i3*2-1:i3*2);c=c(:);d=[a,b,c];d=d';localF1(1+12:12*2)=d(:);

a=gz1(i1*2-1:i1*2,i2*2-1:i2*2,i3);a=a(:);
b=gz2(i1*2-1:i1*2,i2*2-1:i2*2,i3);b=b(:);
c=gz3(i1*2-1:i1*2,i2*2-1:i2*2,i3);c=c(:);d=[a,b,c];d=d';localF1(1+12*2:12*3)=d(:);
%% local eli

invlocalAss=inv(localAss);
Aaugl=[-localAsr1,-localAsp1];Aaugl=Aaugl(nzid,:);localF1=localF1(nzid);
D=sparse(27,27);localF=[localF1;zeros(3,1);alllocalF(:,id)];
[localAeli,localFeli]=eli_matrix(invlocalAss,Aaugl,D,localF);
invlocalArr=sparse(1:3,1:3,1./diag(localAeli(1:3,1:3)));
D=localAeli(4:end,4:end); Aaug2=localAeli(1:3,4:end);
[localAeli0,localFeli0]=eli_matrix(invlocalArr,Aaug2,D,localFeli);
alleli(:,id)=localAeli0(:);
alleliF(:,id)=localFeli0;
allAaugl{id}=Aaugl;
allAagul2{id}=Aaug2;
allinvlocalAss{id}=invlocalAss;
alllocalFeli{id}=localFeli;
allinvlocalArr{id}=invlocalArr;
alllocalFface{id}=localF1;
allnzid{id}=nzid;
end
nodedofv2=ones(36,np);
id1=1;
for id=1:np
nzid=allnzid{id};
nnzid=length(nzid);
nodedofv2(nzid,id)=id1:id1+nnzid-1;
id1=id1+nnzid;
end
iru=kron(alludof,ones(24,1));
icu=kron(alludof,ones(1,24));icu=reshape(icu(:),24^2,np);
Aeli0=sparse(iru,icu,alleli); %%% with local assemble Aeli
Feli0=sparse(alludof,ones(24,np),alleliF);


clear ivaluesr ir ic invAss_local ir1 ic1 ivaluesr ivaluesp maskcoeff mu_bare lambda_bare nodedofv alleli iru icu 
clear alllocalF1 iru icu
tm1=toc(tm);
fprintf('time assemble matarix in dual grid with local eli is %2.1f seconds\n',tm1);

disp('.............')