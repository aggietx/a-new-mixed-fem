function model=generate_3dbbdc_model3(N,n,maxval)
%%%% model (figure 4.3) in paper "A FRUGAL FETI-DP AND BDDC COARSE SPACE
% % FOR HETEROGENEOUS PROBLEMS"


% model=generate_3dbbdc_model3(3,12,100);imagescsquare1(model(:,:,1));

if mod(n,2)~=0
disp('n must be divided by 2')
end
disp('checkerbroad model')

n1=floor(n/2);
range1=1:n1;range2=n1+1:n;


model=ones(n,n,n);

model(range1,range1,range1)=maxval;
model(range2,range2,range2)=maxval;

model=repmat(model,N,N,N);