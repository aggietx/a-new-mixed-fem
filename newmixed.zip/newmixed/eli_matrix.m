function [Aeli,Feli]=eli_matrix(invAss,Aaug,D,F)
nelidof=size(Aaug,1);
if size(invAss,1)>1 %%% inverse is matrix case
    a=Aaug'*invAss;
Aeli=-(a)*Aaug+D;
Feli=-a*F(1:nelidof,:)+F(nelidof+1:end,:);
else %%%% inverse is diagonal case
    a=Aaug'.*invAss;
    Aeli=-(a)*Aaug+D;
Feli=-a*F(1:nelidof,:)+F(nelidof+1:end,:);
end
% notherdof=size(Aaug,2);
% u1=Aeli\Feli;uf=zeros(nelidof+notherdof,1);uf(nelidof+1:end)=u1;
% uf(1:nelidof)=invAss*(F(1:nelidof)-Aaug*u1);
