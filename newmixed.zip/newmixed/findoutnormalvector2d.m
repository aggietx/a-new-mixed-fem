function n=findoutnormalvector2d(x1,x2,y1,y2,x0,y0)
% % % n=findoutnormalvector2d(1,1,0,1,2,3)
% %% n=findoutnormalvector2d(1,2,3,3,2,4)

tol=10^(-14);
if abs(x1-x2)<tol

n=[x1-x0;0]/abs(x1-x0);

elseif abs(y1-y2)<tol

 n=[0;y1-y0]/abs(y1-y0);   
else

    k1=(y1-y2)/(x1-x2);
    k2=-1/k1;

    % line1: y=k1*(x-x1)+y1
    % line2: y=k2*(x-x0)+y0
    xi=(y0-y1+k1*x1-k2*x0)/(k1-k2);
    yi=k1*(xi-x1)+y1;
    % yi1=k2*(xi-x0)+y0;yi-yi1
    n=[xi-x0;yi-y0];
    n=n/norm(n);
end