function [xpi,ypi]=uiformpartition2d_quad(n1,n2,x1,y1,x2,y2,x3,y3,x4,y4)

% [xpi,ypi]=uiformpartition2d_quad(4,4,0,0,0,1,1,0,1,1);

xpi=zeros(n1+1,n2+1);
ypi=zeros(n1+1,n2+1);
for j=1:n1+1 %% left bd and right bd
    xpi(j,1)=x1+(j-1)*(x2-x1)/n1;ypi(j,1)=y1+(j-1)*(y2-y1)/n1;
    xpi(j,end)=x3+(j-1)*(x4-x3)/n1;ypi(j,end)=y3+(j-1)*(y4-y3)/n1;
end

for j=1:n1+1
    for i=1:n2+1
        xpi(j,i)=xpi(j,1)+(i-1)*(xpi(j,end)-xpi(j,1))/n2;
        ypi(j,i)=ypi(j,1)+(i-1)*(ypi(j,end)-ypi(j,1))/n2;
    end
end

