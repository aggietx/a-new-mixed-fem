function [n1,n2,n3,n4]=findoutnormalquad(x1,y1,x2,y2,x3,y3,x4,y4)
% % [n1,n2,n3,n4]=findoutnormalquad(0,0,0,1,1,0,1,1);
n1=findoutnormalvector2d(x1,x2,y1,y2,x3,y3);
n2=findoutnormalvector2d(x3,x4,y3,y4,x1,y1);
n3=findoutnormalvector2d(x1,x3,y1,y3,x2,y2);
n4=findoutnormalvector2d(x2,x4,y2,y4,x1,y1);