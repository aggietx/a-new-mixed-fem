
function perm=Construction_3D_perm_longchannel(maxval,N,nc)

 % model=Construction_3D_perm_longchannel(100,3,3);imagescsquare1(model(:,:,1));

perm=ones(12,12,12);
disp('long channel model, repmat 12')
%%%% repmat from 12^3 model
if nc==1
disp('one channel')
perm(2:4,2:4,1:end)=maxval;
elseif nc==2
disp('two channels')
perm(2:4,2:4,1:end)=maxval;
perm(6:10,6:10,1:end)=maxval;

elseif nc==3
disp('three channels')
perm(1:4,1:4,1:end)=maxval;
perm(6:7,6:7,1:end)=maxval;
perm(8:11,1:11,1:end)=maxval;


end

perm=repmat(perm,N,N,N);

