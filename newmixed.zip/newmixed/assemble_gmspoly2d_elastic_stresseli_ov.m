
function  [phimatrix_pa,tb,iivaluepcell]=assemble_gmspoly2d_elastic_stresseli_ov(overelement, Nx,Ny,n,lambda,mu,basismap,...
    regvalue,localA12,localA11a,localA11b,localA22a,localA22b,mu_bar,polyorder,hx,hy)
%%% with oversampling, no tolerance adatpvitiy

disp('generate 2d gms poly boundary driven basis...')
nb=(polyorder+1)^2;
nx=Nx*n;ny=Ny*n;ne=nx*ny;h=1/nx;vol=h^2;
% basismap=nmaxbasis*ones(Ny,Nx);
% % kappa=K*10^6;
% overelement=5;
ts=tic;



p_dof=reshape(1:nx*ny,ny,nx);

Ncb=Nx*Ny;

 alllocalsize1=zeros(Ncb,1);
 alllocalsize2=zeros(Ncb,1);
 iivaluepcell=cell(Ncb,1);
 alllocallambda=cell(Ncb,1);
 alllocalmu=cell(Ncb,1);
 alllocal_pdof=cell(Ncb,1);
alltrue_dof=cell(Ncb,1);
allmu_bar=cell(Ncb,1);
    for ii2=1:Nx
        for ii1=1:Ny
    iie=(ii2-1)*Ny+ii1;
                 global_p_dof=p_dof( (ii1-1)*n+1:ii1*n,(ii2-1)*n+1:ii2*n);
global_p_dofov=p_dof( max( (ii1-1)*n+1-overelement,1):min(ii1*n+overelement,ny),...
        max( (ii2-1)*n+1-overelement,1):min(ii2*n+overelement,nx));
[localny,localnx]=size(global_p_dofov);
global_p_dofov=global_p_dofov(:);global_p_dof=global_p_dof(:);

    locallambda=lambda( global_p_dofov);
    localmu=mu(global_p_dofov);    

    alllocalsize1(iie)=localny;
    alllocalsize2(iie)=localnx;
[~,true_dof]=ismember([global_p_dof;global_p_dof+ne],[global_p_dofov;global_p_dofov+ne]);
alltrue_dof{iie}=true_dof;
alllocallambda{iie}=locallambda;
alllocalmu{iie}=localmu;
alllocal_pdof{iie}=global_p_dof;
allmu_bar{iie}=mu_bar(global_p_dofov);
        end
    end


% alleigval=cell(Ncb,1);allratio=zeros(Ncb,1);
% np=(n+1)^2;
% [Aaug1,D,ir1,ic1,nodedof,bddof]=assemble2d_matrix_partb(n,n,h,h);
% Aaug1(bddof,:)=0;
parfor iie=1:Ny*Nx
% for iie=1:Ny*Nx
% localny=n;
% localnx=n;
truedof=alltrue_dof{iie};
% nlocalbasis=basismap(iie);
locallambda=alllocallambda{iie};
localny=alllocalsize1(iie);
localnx=alllocalsize2(iie);
nlocale=localnx*localny;
poly0=get_2d_polybasis_cell(localny,localnx,polyorder);
% 
nlocalp=(localnx+1)*(localny+1);
nlocalv=(localnx+1)*(localny)+(localny+1)*localnx;nlocalv=nlocalv*2;

localmu_bar=allmu_bar{iie};
np=(localnx+1)*(localny+1);
[Aaug1,D,ir1,ic1,nodedof,~,~,dofx1,dofx2,dofy1,dofy2]=assemble2d_matrix_partb(localnx,localny,h,h,localmu_bar);
% Aaug1(bddof,:)=0;%%%%neumann
localpdof=reshape(1:localnx*localny,localny,localnx);
leftdof=localpdof(:,1);rightdof=localpdof(:,end);
bottomdof=localpdof(1,:);topdof=localpdof(end,:);
%% diri bd

F=zeros(2*nlocale+2*nlocalv+nlocalp,2*nb);
%%%% diri for u1

F(dofx1(1:2:end,1),1:nb)=-poly0(leftdof,:)*hy/2;F(dofx1(2:2:end,1),1:nb)=-poly0(leftdof,:)*hy/2;%%% u1,x=0,

F(dofx2(1:2:end,1),1:nb)=poly0(rightdof,:)*hy/2;F(dofx2(2:2:end,1),1:nb)=poly0(rightdof,:)*hy/2;%%% u1,x=1,%%

F(dofy1(1:2:end,1),1:nb)=-poly0(bottomdof,:)*hx/2;F(dofy1(2:2:end,1),1:nb)=-poly0(bottomdof,:)*hx/2;%%% u1,y=0,%%

F(dofy2(1:2:end,1),1:nb)=poly0(topdof,:)*hx/2;F(dofy2(2:2:end,1),1:nb)=poly0(topdof,:)*hx/2;%%% u1,y=1,


%%%% diri for u2

F(dofx1(1:2:end,2),1+nb:2*nb)=-poly0(leftdof,:)*hy/2;F(dofx1(2:2:end,2),1+nb:2*nb)=-poly0(leftdof,:)*hy/2;%%% u2,x=0,

F(dofx2(1:2:end,2),1+nb:2*nb)=poly0(rightdof,:)*hy/2;F(dofx2(2:2:end,2),1+nb:2*nb)=poly0(rightdof,:)*hy/2;%%% u2,x=1,%%

F(dofy1(1:2:end,2),1+nb:2*nb)=-poly0(bottomdof,:)*hx/2;F(dofy1(2:2:end,2),1+nb:2*nb)=-poly0(bottomdof,:)*hx/2;%%% u2,y=0,%%

F(dofy2(1:2:end,2),1+nb:2*nb)=poly0(topdof,:)*hx/2;F(dofy2(2:2:end,2),1+nb:2*nb)=poly0(topdof,:)*hx/2;%%% u2,y=1,

poly=zeros(2*(localnx)*(localny),2*nb);poly(1:(localnx)*(localny),1:nb)=poly0;
poly(1+(localnx)*(localny):2*(localnx)*(localny),nb+1:end)=poly0;
F(2*nlocalv+1+np:2*nlocalv+2*nlocale+np,:)=poly*vol;

%%
localmu=alllocallambda{iie};

[invAss,~]=assemble2d_matrix_parta(localnx,localny,h,h,locallambda,localmu,localA12,localA11a,localA11b,localA22a,localA22b,ir1,ic1,nodedof);

% Aeli=eli_matrix0(invAss,Aaug1,D);
[Aeli,Feli]=eli_matrix(invAss,Aaug1,D,F);
invArr=1./diag(Aeli(1:np,1:np));
D2=Aeli(np+1:end,np+1:end); Aaug=Aeli(1:np,np+1:end);
% Aeig=-eli_matrix0(invArr',Aaug,D2);
[Aeig,Feli]=eli_matrix(invArr',Aaug,D2,Feli);

Aeig=Aeig+Aeig.';Aeig=Aeig+regvalue*diag(diag(Aeig));


sol=Aeig\Feli;

basis=sol(truedof,:);

% basis0=get_2d_polybasis_cell(n,n,3);basis=zeros(2*n^2,32);basis(1:n^2,1:16)=basis0;basis(1+n^2:2*n^2,17:end)=basis0;

%       if 1
% basis=scalar2vector(basis);
%       end

       basismap(iie)=size(basis,2);

iivaluepcell{iie}=basis;
end

dim_pc=sum(basismap(:));
ixp=zeros(dim_pc,2*n^2);
ivaluep=zeros(dim_pc,2*n^2);
iyp=(1:dim_pc)'*ones(1,2*n^2);
ind=1;

    for ii2=1:Nx
        for ii1=1:Ny
    iie=(ii2-1)*Ny+ii1;
    basis=iivaluepcell{iie};
    nlocal_basis=basismap(iie);
    ivaluep(ind:ind+nlocal_basis-1,:)=basis';   
    global_p_dof=alllocal_pdof{iie};

   global_p_dof=[global_p_dof(:);global_p_dof(:)+ne];
global_p_dof=sort( global_p_dof(:));

    ixp(ind:ind+nlocal_basis-1,:)= repmat( global_p_dof,1,nlocal_basis)';
ind=ind+nlocal_basis;  
        end
    end

% if max(imag(allbasis(:)))>10^(-8)
%     disp('complex eigenfunction')
% end
% return
disp('assembling coarse matrix...')
clear alllocal_pdof allbasis p_dof
 phimatrix_pa=sparse(iyp,ixp,ivaluep,dim_pc,ne*2);clear ixp iyp ivaluep
 fprintf('dim of are %d %d\n',dim_pc,ne);
 fprintf('average basis number is %2.2f\n',dim_pc/(Nx*Ny));
 disp('END of generating gms basis')
 tb=toc(ts);
  fprintf('Tbasis is %2.2f seconds\n',tb);