function [invAss,Ass]=assemble2d_matrix_parta(nx,ny,hx,hy,lambda,mu,localA12,localA11a,localA11b,localA22a,localA22b,ir1,ic1,nodedof)
%%%% input has nothing to do with coefficient

ne=nx*ny;nvet=2*ny*(nx+1);nhor=2*nx*(ny+1);nvdof=nvet+nhor;nedge=ny*(nx+1)+nx*(ny+1);
vol=hx*hy;np=(nx+1)*(ny+1);



lambda=lambda(:);mu=mu(:);

lambda_bar=-lambda./(4*mu.*(lambda+mu));
mu_bar=1/2./(mu);
lambdabar_mubar=lambda_bar+mu_bar;
%% (As,s) matrix


Ass=sparse(ir1,ic1,localA11a(:)*lambdabar_mubar'*vol/4+localA11b(:)*mu_bar'*vol/4+...
                     1*localA12(:)*lambda_bar'*vol/4+...
                     localA22a(:)*mu_bar'*vol/4+localA22b(:)*lambdabar_mubar'*vol/4);
% spy(Ass)
invAss_local=cell(np,1);
id=0;
for i=1:np
localdof=nodedof(:,i);ndof=length(find(localdof))*2;

invAss_local{i}=inv(Ass(id+1:id+ndof,id+1:id+ndof));
id=id+ndof;
end
invAss=blkdiag(invAss_local{:});