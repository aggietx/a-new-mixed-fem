G = cartGrid([nx, ny], [Lx,Ly]);
G = computeGeometry(G);
hx=1/nx;[xe,ye]=meshgrid(hx/2:hx:1,hx/2:hx:1);
        k11=(xe+1).^2+ye.^2;k12=sin(xe.*ye);
        k22=(xe+1).^2;
        rock.perm(:,1)=k11(:);
        rock.perm(:,3)=k22(:);
        rock.perm(:,2)=k12(:);
        rock.poro=ones(ne,1);
tic;Aeigfull = getIncomp1PhMatrix(G, getFaceTransmissibility(G,rock) );  


return
invAss=assemble_Ass3d_part2(lambdabar_mubar,mu_bar,lambda_bar,ir1,ic1,ne,nodedge,vol,localA12,np,nodedof);

return
load Aforinv1;a=Aforinv1;
load invA1;b=invA1;

for i=1:401

    range=(i-1)*200+1:i*200;
    norm(full(inv(a(range,range)))-full(b(range,range)))
end