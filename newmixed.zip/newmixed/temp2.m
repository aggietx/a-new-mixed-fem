%%%% basis are the same as rt0, all vector basis are (1,0) or (0,1), no
%%%% negative, no stress elimination
%%% (x,y,z)
%%%% discontinuous rotation
%%%% yotov's 3D example 
clear;
close all
nx1=2*4;nx2=nx1;nx3=nx1;nx=nx1;ny=nx2;nz=nx3;
Lx1=1;Lx2=1;Lx3=1;ne=nx1*nx2*nx3;hx1=1/nx1;hx2=1/nx2;hx3=1/nx3;vol=hx1*hx2*hx3;np=(nx1+1)*(nx2+1)*(nx3+1);
nface=(nx1+1)*nx2*nx3+(nx2+1)*nx1*nx3+(nx3+1)*nx1*nx2;nvdof=4*nface;hx=hx1;hy=hx2;hz=hx3;
[nodv,facex1,facex2,facey1,facey2,facez1,facez2]=local2globaldof3d(nx,ny,nz);

fprintf('nx is %d\n',nx);
poission_ratio=.1;
young_modulus=1*ones(nx1,nx2,nx3);% % depends on x
lambda=poission_ratio/((1+poission_ratio)*(1-2*poission_ratio))*young_modulus;
mu=1/2/(1+poission_ratio)*young_modulus;

% lambda=100*ones(ne,1);mu=100*ones(ne,1);
lambda=lambda(:);mu=mu(:);

s=lambda(1,1);t=mu(1,1);
lambda_bar=-lambda./(4*mu.*(lambda+mu));
mu_bar=1/2./(mu);
lambdabar_mubar=lambda_bar+mu_bar;
fprintf('s over t is %2.2f\n',s/t);
%% (As,s) matrix
Ass11=sparse(nodv,nodv,[ones(8,1)*lambdabar_mubar';ones(8,1)*mu_bar';ones(8,1)*mu_bar'])*vol/8;
Ass22=sparse(nodv,nodv,[ones(8,1)*mu_bar';ones(8,1)*lambdabar_mubar';ones(8,1)*mu_bar'])*vol/8;
Ass33=sparse(nodv,nodv,[ones(8,1)*mu_bar';ones(8,1)*mu_bar';ones(8,1)*lambdabar_mubar'])*vol/8;

ir1=zeros( (3*6*4)^2,ne);%%%3：3d，6，6 faces, 4, each face 4 dof
ic1=zeros( (3*6*4)^2,ne);
localA12=zeros(72,72);
for i=1:8
localA12(i,i+32)=1;
localA12(i,i+32*2)=1;
end
for i=1+32:8+32
localA12(i,i+32)=1;
localA12(i,i-32)=1;
end
for i=1+32*2:8+32*2
localA12(i,i-32*2)=1;
localA12(i,i-32)=1;
end

id=1;
nodedge=zeros(72,ne);
for i3=1:nx3
  for i2=1:nx2
    for i1=1:nx1
localedof=[nodv(:,id);nodv(:,id)+nvdof;nodv(:,id)+2*nvdof];
nodedge(:,id)=localedof;
ir1(:,id)=repmat(localedof,72,1);
temp=repmat(localedof,1,72);temp=temp';ic1(:,id)=temp(:);
id=id+1;
    end
  end
end
Ass=[Ass11,sparse(nvdof,nvdof),sparse(nvdof,nvdof);
    sparse(nvdof,nvdof), Ass22,sparse(nvdof,nvdof);
    sparse(nvdof,nvdof),sparse(nvdof,nvdof), Ass33;]+sparse(ir1,ic1,localA12(:)*lambda_bar'*vol/8);
% tic;a=Ass\speye(size(Ass,1));toc
% return
%% stress and rotation

localsr=zeros(72,3);
for i=9:16;localsr(i,3)=-1;end
for i=17:24;localsr(i,2)=-1;end
for i=25:32;localsr(i,3)=1;end
for i=41:48;localsr(i,1)=-1;end
for i=49:56;localsr(i,2)=1;end
for i=57:64;localsr(i,1)=1;end

localsr=localsr*vol/8;
allrdof=reshape(1:(nx+1)*(ny+1)*(nz+1),nx+1,ny+1,nz+1);
ir=zeros(72*3,ne);
ic=zeros(72*3,ne);
id=1;
for i3=1:nx3
  for i2=1:nx2
    for i1=1:nx1
localedof=nodedge(:,id); ir(:,id)=repmat(localedof,3,1);
localrdof=[id,id+ne,id+2*ne];localrdof=localrdof(:);temp=repmat(localrdof,1,72);temp=temp';ic(:,id)=temp(:);

id=id+1;
    end
   end
end
Ars=sparse(ir,ic,repmat(localsr(:),1,ne));
%% stress and displacement
localsp=zeros(24,1);
for i=[1:4,9:12,17:20];localsp(i)=-1;end
for i=[1:4,9:12,17:20]+4;localsp(i)=1;end
localsp=localsp*hx1*hx2/4;
ivalue=repmat(localsp,1,ne);
ix=repmat(1:ne,24,1);
Asp0=sparse(nodv,ix,ivalue);clear ivalue ix 
Asp=[Asp0,sparse(nvdof,ne),sparse(nvdof,ne);
    sparse(nvdof,ne),Asp0,sparse(nvdof,ne);
    sparse(nvdof,ne),sparse(nvdof,ne),Asp0];
%% 
A=[Ass, Asp,Ars;
   -Asp',sparse(3*ne,3*ne+3*ne);
   Ars',sparse(3*ne,3*ne+3*ne)];
F=zeros(nvdof*3+3*ne+3*ne,1);

% F(nvdof*3+1:nvdof*3+3*ne)=vol;

% disp('solve linear system...')
% tic;u=A\F;toc
%% post
[ye,xe,ze]=meshgrid(hx/2:hx:1,hy/2:hy:1,hz/2:hz:1);%%[x,y,z]=meshgrid(0:1/5:1,0:1/4:1,0:1/3:1);
uexact1=@(x,y,z) sin(pi*x).*sin(pi*y)+1/2/s.*x;
uexact2=@(x,y,z) cos(pi*x).*cos(pi*y)+1/2/s.*y;
uexact3=@(x,y,z) 0;
ue2=uexact2(xe,ye,ze);ue2=ue2(:);ue3=uexact3(xe,ye,ze);ue3=ue3(:);ue1=uexact1(xe,ye,ze);ue1=ue1(:);


f1 =@(x,y,z) 2*pi^2*sin(pi*x).*sin(pi*y);
f2 =@(x,y,z) 2*pi^2*cos(pi*x).*cos(pi*y);
f3=@(x,y,z) 0;
F1=f1(xe,ye,1);F2=f2(xe,ye,1);F3=f3(xe,ye,ze);F3=zeros(ne,1);
%%%% diribd
[ze1,ye1]=meshgrid(hy/2:hy:1,hz/2:hz:1);x1a=zeros(ny,nz);x1b=ones(ny,nz);%[aa,bb]=meshgrid(0:1/5:1,0:1/4:1);
[ze2,xe2]=meshgrid(hx/2:hx:1,hz/2:hz:1);y2a=zeros(nx,nz);y2b=ones(nx,nz);
[ye3,xe3]=meshgrid(hx/2:hx:1,hy/2:hy:1);z3a=zeros(nx,ny);z3b=ones(nx,ny);
for i=1:2
    for j=1:2
F(facex1(j:2:end,i:2:end)+1*nvdof)=-uexact2(x1a,ye1,ze1)*hz*hy/4;%%% u2,x=0,
F(facex2(j:2:end,i:2:end)+1*nvdof)=uexact2(x1b,ye1,ze1)*hz*hy/4;%%% u2,x=1,
F(facey1(j:2:end,i:2:end)+1*nvdof)=-uexact2(xe2,y2a,ze2)*hz*hx/4;%%% u2,y=0,
F(facey2(j:2:end,i:2:end)+1*nvdof)=uexact2(xe2,y2b,ze2)*hz*hx/4;%%% u2,y=1,
F(facez1(j:2:end,i:2:end)+1*nvdof)=-uexact2(xe3,ye3,z3a)*hx*hy/4;%%% u2,z=0,
F(facez2(j:2:end,i:2:end)+1*nvdof)=uexact2(xe3,ye3,z3b)*hx*hy/4;%%% u2,z=1,

F(facex1(j:2:end,i:2:end)+0*nvdof)=-uexact1(x1a,ye1,ze1)*hz*hy/4;%%% u3,x=0,
F(facex2(j:2:end,i:2:end)+0*nvdof)=uexact1(x1b,ye1,ze1)*hz*hy/4;%%% u3,x=1,
F(facey1(j:2:end,i:2:end)+0*nvdof)=-uexact1(xe2,y2a,ze2)*hz*hx/4;%%% u3,y=0,
F(facey2(j:2:end,i:2:end)+0*nvdof)=uexact1(xe2,y2b,ze2)*hz*hx/4;%%% u3,y=1,
F(facez1(j:2:end,i:2:end)+0*nvdof)=-uexact1(xe3,ye3,z3a)*hx*hy/4;%%% u3,z=0,
F(facez2(j:2:end,i:2:end)+0*nvdof)=uexact1(xe3,ye3,z3b)*hx*hy/4;%%% u3,z=1,
    end
end
F(3*nvdof+1:3*nvdof+3*ne)=-[F1(:);F2(:);F3(:)]*vol;

% a=zeros(16,16);a1=rand(8,8);
% for i=1:2
%     for j=1:2
%         a(j:2:end,i:2:end)=a1;
%     end
% end
if 0
h=1/32;[ye,xe,ze]=meshgrid(h/2:h:1,h/2:h:1,h/2:h:1);
u2e=uexact2(xe,ye,ze);u3e=uexact3(xe,ye,ze);
un=sqrt(u2e.^2+u3e.^2);
imagesc3dsquare(un(:),0)
a=sqrt(cigma11(xe,ye,ze).^2+cigma12(xe,ye,ze).^2+cigma13(xe,ye,ze).^2);imagesc3dsquare(a(:),0)
b=sqrt(cigma21(xe,ye,ze).^2+cigma22(xe,ye,ze).^2+cigma23(xe,ye,ze).^2);imagesc3dsquare(b(:),0)
c=sqrt(cigma31(xe,ye,ze).^2+cigma32(xe,ye,ze).^2+cigma33(xe,ye,ze).^2);imagesc3dsquare(c(:),0)
end 

disp('solve linear system...')
tic;u=A\F;toc
% ua1=u(nvdof*3+1:nvdof*3+ne);
% imagesc3dsquare(ua1,1);title('approx u1')
% imagesc3dsquare(ue1(:),1);title('exact u1')
%% post
ua1=u(nvdof*3+1+0:nvdof*3+1*ne);
ua2=u(nvdof*3+1+ne:nvdof*3+2*ne);
ua3=u(nvdof*3+1+2*ne:nvdof*3+3*ne);

ua=sqrt(ua1.^2+ua2.^2+ua3.^2);ue=sqrt(ue1.^2+ue2.^2+ue3.^2);
% imagesc3dsquare(ue2(:),0);title('exact u2');imagesc3dsquare(ua2,0);title('approx u2')
imagesc3dsquare(ue(:),0);title('exact u');imagesc3dsquare(ua,0);title('approx u')

diff=sqrt(ua1.^2+ua2.^2+ua3.^2)-sqrt(ue1.^2+ue2.^2+ue3.^2);
exact=sqrt(ue1.^2+ue2.^2+ue3.^2);
Mass=vol*speye(ne);
err=sqrt(diff'*Mass*diff);
rerr=sqrt(diff'*Mass*diff)/sqrt(exact'*Mass*exact);
fprintf('size is %d\n',nx)
fprintf('relative error and error of displacement are %2.4e %2.4e\n',norm(diff)/norm(exact),sqrt(sum(diff.^2)*vol) );

% rnorm(ua2,ue2);rnorm(ua3,ue3);
return
diff1=se-sa;
if errcase==1
fprintf('relative error and error of stress are %2.4e %2.4e\n',norm(diff1)/norm(se),sqrt(sum(diff1.^2)*vol) );
% norm(s11a-s11e)
% norm(s12a-s12e)
% norm(s21a-s21e)
% norm(s22a-s22e)
else
fprintf('relative error and error of stress are %2.4e %2.4e\n',norm(diff1)/norm(se),sqrt(sum(diff1.^2)*vol/4) );

end

% b=reshape(ua2,nx,ny,nz);b=permute(b,[1,3,2]);rnorm(b(:),ue2);
% rnorm(ua2,ue2);
% a=reshape(ua1,nx,ny,nz);
% imagescsquare1(a(:,:,nz/2))