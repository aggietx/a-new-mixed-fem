function [nod,dofx1,dofx2,dofy1,dofy2,dofvet,dofhor]=local2globaldof(nx,ny)
ne=nx*ny;
nvet=2*ny*(nx+1);
nhor=2*nx*(ny+1);
dofvet=reshape(1:nvet,2*ny,nx+1);
dofhor=reshape(1:nhor,ny+1,ny*2)+nvet;
dofx1=dofvet(:,1);dofx2=dofvet(:,end);
dofy1=dofhor(1,:)';dofy2=dofhor(end,:)';
nod=zeros(8,ne);
id=1;
for i2=1:nx
    for i1=1:ny
        ldofvet=dofvet(i1*2-1:i1*2,i2:i2+1);
        ldofhor=dofhor(i1:i1+1,i2*2-1:i2*2);
nod(:,id)=[ldofvet(:);ldofhor(:)];
        id=id+1;
    end
end