xe=reshape(xe(:),ny,nx);
ye=reshape(ye(:),ny,nx);
close all;
imagesc_uns2d1(Lx,Ly,nx,ny,xe,ye,xp,yp,ua);
hold on;quiver(xe,ye,reshape(ua1,ny,nx),reshape(ua2,ny,nx),'black','linewidth',.7)
t = title('Displacement, magnitude', 'Units', 'normalized', 'Position', [0.5, -0.15, 0]);
% figure();mesh(xp,yp,ones(1+ny,1+nx));colormap jet;view(90,90)
axis square;set(gca,'fontsize',14)
% axis equal;
% axis image;
% return
imagesc_uns2d1(Lx,Ly,nx,ny,xe,ye,xp,yp,sqrt(s11a.^2+s12a.^2));
hold on;quiver(xe,ye,reshape(s11a,ny,nx),reshape(s12a,ny,nx),'black','linewidth',.7)
t = title('StressX, magnitude', 'Units', 'normalized', 'Position', [0.5, -0.15, 0]);
axis equal;set(gca,'fontsize',14)

imagesc_uns2d1(Lx,Ly,nx,ny,xe,ye,xp,yp,sqrt(s21a.^2+s22a.^2));
hold on;quiver(xe,ye,reshape(s21a,ny,nx),reshape(s22a,ny,nx),'black','linewidth',.7)
t = title('StressY, magnitude', 'Units', 'normalized', 'Position', [0.5, -0.15, 0]);
axis equal;set(gca,'fontsize',14)

imagesc_uns2d1(Lx,Ly,nx,ny,xe,ye,xp,yp,reshape(-rota(:),ny,nx));

t = title('Rotation', 'Units', 'normalized', 'Position', [0.5, -0.15, 0]);
axis equal;set(gca,'fontsize',14)
imagesc_uns2d1(Lx,Ly,nx,ny,xe,ye,xp,yp,-rota.*mu(:)*2);

t = title('Scaled rotation', 'Units', 'normalized', 'Position', [0.5, -0.15, 0]);
axis equal;set(gca,'fontsize',14)





