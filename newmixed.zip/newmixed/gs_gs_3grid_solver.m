function  [u,relres2,iter2]=gs_gs_3grid_solver(Kd,F,phi,phic,varargin)
%%% inner gs, outside gs
    opt = struct('tol'     , 10^(-8)                      , ...
                 'initype' , 1              , ...
                 'bicg', 1,...
                 'omega'    , 1.8, ...
                 'omega1', 1.8,...
                 'step', 5 ,...
                 'step1', 5 );
    opt = merge_options(opt, varargin{:});
    tol=opt.tol;
    initype=opt.initype;
    bicg=opt.bicg;
    omega=opt.omega;
    step=opt.step;
    step1=opt.step1;
    omega1=opt.omega1;
    ne=size(Kd,1);
    nc=size(phi,1);
if initype
    disp('zero initial')
uinit=zeros(size(F));
end
        t2grid0=tic ;
[M,N]=gs_matrix(Kd,omega);
fprintf('dim are %d %d %d\n',ne,nc,size(phic,1));
      phiA=phi*Kd; Apms=phiA*phi';% Apms=Apms+10^(-16)*diag(diag(Apms));
      phiAc=phic*Apms; Apmsc=phiAc*phic';
     [M1,N1]=gs_matrix(Apms,omega1); 
     [L,U,P,Q] = lu(Apmsc); 
   if initype~=1;  disp('ms initial');Fc=phi*F; uc=Q*(U\(L\(P*(phic*Fc))));uinit=phi.'*(phic.'*uc);end

      tsolve2grid0=toc(t2grid0);
      t2grid1=tic ;
          prec=@(inc)pre2grid2_gs(Apms, inc, zeros(nc,1),N1,M1,phic,step1,step1, phiAc,L,U,P,Q);
          precond2=@(inc)pre3grid_gs(Kd, inc,N,M,phi,zeros(ne,1),phiA,step,step,prec);
disp('solve with three_grid preconditioner gs+gs ...')
% ua=precond2(F);
% rnorm(ua,Kd\F);
if bicg
 [u,~,relres1,iter2]=bicgstab(Kd,F,tol, 5000,precond2,[],uinit);tsolve2grid1=toc(t2grid1);
 relres2=norm(F-Kd*u)/norm(F);
  fprintf('bicgstab number,residual,tsolve(3grid) are %d %2.2e %2.2e %2.2f + %2.2f = %2.2f seconds\n',ceil(iter2*2),relres1,relres2,tsolve2grid0,tsolve2grid1,tsolve2grid0+tsolve2grid1);   %%floor(iter2(size(iter2,2)))
else
  [u,~,relres1,iter2]=gmres(Kd,F,10,tol, 50,precond2,[],uinit);tsolve2grid1=toc(t2grid1);
   relres2=norm(F-Kd*u)/norm(F);
 fprintf('gmres number,residual,tsolve(3grid) are %d %2.2e %2.2e %2.2f + %2.2f = %2.2f seconds\n',ceil(iter2(1)*iter2(2)),relres1,relres2,tsolve2grid0,tsolve2grid1,tsolve2grid0+tsolve2grid1);   %%floor(iter2(size(iter2,2)))
end
disp('....................')
end


function  x=pre3grid_gs(Apre,Fpre, N,M,phi,x,RA,step1,step2,prec)

% uc=prec(phi*Fpre);
% x=phi.'*uc; 
%% smooothing
   for k = 1:step1
     x =  N\(Fpre + M*x);
   end
%% coarse  

   % r=Fpre - Apre*x;
   % r0=phi*r;  
    r0=phi*Fpre-RA*x;
   uc=prec(r0);
   umsfine=phi.'*uc; 
   x=x + umsfine;

  %% smoothing
   for k = 1:step2
       x =  N\(Fpre + M*x);
   end

end


function  x=pre2grid2_gs(Apre, Fpre, x,N,M,phimatrix_enriched,step1,step2,RA,L,U,P,Q)
   % uc=Q*(U\(L\(P*(phimatrix_enriched*Fpre))));
   % x= phimatrix_enriched.'*uc;
%% smooothing
   for k = 1:step1
     x =  N\(Fpre + M*x);
   end

%% coarse correction 
   r0=phimatrix_enriched*Fpre-RA*x;
   uc=Q*(U\(L\(P*(r0))));
   x=x + phimatrix_enriched.'*uc;
   
  %% smoothing
   for k = 1:step2
       x =  N\(Fpre + M*x);
   end
% 
end
