function onlinebasis1=scalar2vector(basis)

nb=size(basis,2);
n=size(basis,1)/2;
onlinebasis1=zeros(2*n,2*nb);
id=1;
for i=1:nb
       onlinebasis=basis(:,i);
      onlinebasis1(1:n,id)=onlinebasis(1:n);onlinebasis1(1+n:end,id)=0;
      onlinebasis1(1:n,id+1)=0;               onlinebasis1(1+n:end,id+1)=onlinebasis(1+n:end);
      id=id+2;
end
