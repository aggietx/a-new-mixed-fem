function [nod,nod0,facex1,facex2,facey1,facey2,facez1,facez2,nodedof]=local2globaldof3d_inveli_elastic(nx,ny,nz)
%%%% (x,y,z)

ne=nx*ny*nz;
[dofyz,dofxz,dofxy,nodedof] = getelidof3d(nx,ny,nz);nodedof=nodedof(:);
facex1=dofyz(1,:,:);[~,facex1]=vectorize_eli(facex1); facex1=reshape(facex1,2*ny,2*nz,3);  
facex2=dofyz(end,:,:);[~,facex2]=vectorize_eli(facex2);facex2=reshape(facex2(:),2*ny,2*nz,3);
facey1=dofxz(:,1,:);[~,facey1]=vectorize_eli(facey1);facey1=reshape(facey1(:),2*nx,2*nz,3); 
facey2=dofxz(:,end,:);[~,facey2]=vectorize_eli(facey2);facey2=reshape(facey2(:),2*nx,2*nz,3);
facez1=dofxy(:,:,1);[~,facez1]=vectorize_eli(facez1);facez1=reshape(facez1(:),2*nx,2*ny,3);  
facez2=dofxy(:,:,end);[~,facez2]=vectorize_eli(facez2);facez2=reshape(facez2(:),2*nx,2*ny,3);
nod=zeros(24*3,ne);
nod0=zeros(24*1,ne);
id=1;
for iz=1:nz
    for iy=1:ny
        for ix=1:nx

    ldofyz1=dofyz(ix,     2*iy-1:2*iy, 2*iz-1:2*iz);
    ldofyz2=dofyz(ix+1,     2*iy-1:2*iy, 2*iz-1:2*iz);
    ldofxz1=dofxz(2*ix-1:2*ix, iy,     2*iz-1:2*iz);
    ldofxz2=dofxz(2*ix-1:2*ix, iy+1,     2*iz-1:2*iz);
    ldofxy1=dofxy(2*ix-1:2*ix, 2*iy-1:2*iy, iz);
    ldofxy2=dofxy(2*ix-1:2*ix, 2*iy-1:2*iy, iz+1);
    localdof=zeros(24,1);
    localdof(1:4)=ldofyz1(:);localdof(5:8)=ldofyz2(:);localdof(9:12)=ldofxz1(:);
    localdof(13:16)=ldofxz2(:);localdof(17:20)=ldofxy1(:);localdof(21:24)=ldofxy2(:);
    % localdof=[ldofyz1(:);ldofyz2(:);ldofxz1(:);ldofxz2(:);ldofxy1(:);ldofxy2(:)];
    % localdof3=[localdof*3-2,localdof*3-1,localdof*3];
    % localdof3=localdof3';
    localdof3=vectorize_eli(localdof);
    nod(:,id)=localdof3;
    nod0(:,id)=localdof;
    id=id+1;
        end
    end
end