clear;close all
model=3;
if model==1
  nx =1000;n=10;
elseif model==2
    nx =800;n=10;
else
  nx =400;n=20;
end
ny=nx;ne=nx*ny;nvet=2*ny*(nx+1);nhor=2*nx*(ny+1);nvdof=nvet+nhor;nedge=ny*(nx+1)+nx*(ny+1);
Lx=1;Ly=1;hx=Lx/nx;hy=Ly/ny;vol=hx*hy;np=(nx+1)*(ny+1);
Nx=nx/n;Ny=ny/n;
fre=20;samplingratio=35;v0=samplingratio*fre*hx;
gs=0;q0=1;eigvalue_tol=10^10;tol=10^(-5);
poission_ratio=0.3;xs=.500*Lx;ys=.500*Ly;
[xe,ye]=meshgrid(hx/2:hx:Lx,hy/2:hy:Ly);
rho=ones(ny,nx);
    if model==1
        disp('scatter model')
    v=floadbin('../hmsfem_acoustic/model_ld_1001.bin') ;v=reshape(v,1001,1001);
v=v(1:end-1,1:end-1);v(v~=0)=v0*1.4;v(v==0)=v0;
    elseif model==2
        disp('fracture model')
            v=floadbin('../hmsfem_acoustic/frac_model.bin');v=reshape(v,801,801);
v=v(1:end-1,1:end-1);v(v~=0)=v0*1.4;v(v==0)=v0;
    elseif model==3
        disp('inclusion model')
 vc=v0*ones(n,n);vc(6:16,6:16)=1.4*v0;v=repmat(vc,Ny,Nx);
    end
v_p=v;v_s=.6*v_p;% % velocity for p and s wave;
mu=rho.*v_s.^2;lambda=-2*mu+rho.*v_p.^2;
T=.6;dt=2.0*10^(-4);step=floor(T/dt);source_support=hx;
alpha=0.3;dt=alpha*hx/max(v_s(:));
fricker = @(t) (1 - 2*pi^2*fre^2*(t-2/fre).^2).*exp(-pi^2*fre^2*(t-2/fre).^2);% % time part
ft=fricker(dt*(0:step));
Fgauss = @(x,y)exp(-((x-xs).^2+(y-ys).^2)/(source_support)^2);% % space part
F1=Fgauss(xe,ye);F2=Fgauss(xe,ye);%%%imagesc(reshape(force_odd,nny,nnx));

lambda=lambda(:);mu=mu(:);
% s=lambda(1,1);t=mu(1,1);
lambda_bar=-lambda./(4*mu.*(lambda+mu));
mu_bar=1/2./(mu);
lambdabar_mubar=lambda_bar+mu_bar;
ratio=min(v_s(:))/fre/hx;
fprintf('min sampling ration is %2.1f\n',ratio );
fprintf('nx Nx are %d %d\n',nx,Nx);
disp('assemble fine matrix...')
%% (As,s) matrix
localA12=zeros(16,16);
localA12(1,10)=1;localA12(3,12)=1;localA12(5,14)=1;localA12(7,16)=1;
localA12(10,1)=1;localA12(12,3)=1;localA12(14,5)=1;localA12(16,7)=1;
localA11a=zeros(16,16);localA11b=zeros(16,16);localA22a=zeros(16,16);localA22b=zeros(16,16);

for i=1:2:7;localA11a(i,i)=1;end
for i=[9,11,13,15];localA11b(i,i)=1;end
for i=2:2:8;localA22a(i,i)=1;end
for i=[10,12,14,16];localA22b(i,i)=1;end
tic
[Aaug1,D,ir1,ic1,nodedof,~,nodedge,dofx1,dofx2,dofy1,dofy2]=assemble2d_matrix_partb(nx,ny,hx,hy,mu_bar);
[invAss,Ass]=assemble2d_matrix_parta(nx,ny,hx,hy,lambda,mu,localA12,localA11a,localA11b,localA22a,localA22b,ir1,ic1,nodedof);

F=zeros(2*ne+2*nvdof+np,1);
F(2*nvdof+1+np:2*nvdof+2*ne+np)=[F1(:);1*F2(:)]*vol;
[Aeli,Feli]=eli_matrix(invAss,Aaug1,D,F);
invArr=sparse(1:np,1:np,1./diag(Aeli(1:np,1:np)));D=Aeli(np+1:end,np+1:end); Aaug=Aeli(1:np,np+1:end);
[Aeli0,Feli0]=eli_matrix(invArr,Aaug,D,Feli);
toc
F=Feli0;
Astiff=-Aeli0;
%% online
disp('solve fine...')   
Mass_weight_v=ones(2*ne,1)*hx*hy;
Mass_damp_v=zeros(ne*2,1);
Mass_damp=sparse(1:2*ne,1:2*ne,Mass_damp_v);
Mass_weight=sparse(1:2*ne,1:2*ne,Mass_weight_v);

   FF=dt^2*F;
   beta_b=1/2;
   M_abc_lump=1./(Mass_weight_v+beta_b*dt*Mass_damp_v);
   M_abc_lump_matrix=sparse(1:2*ne,1:2*ne,M_abc_lump);
   A2=2*Mass_weight-dt^2*Astiff-dt*(1-2*beta_b)*Mass_damp;
   A1=Mass_weight+(beta_b-1)*dt*Mass_damp;
   AA2=M_abc_lump_matrix*A2;
   AA1=M_abc_lump_matrix*A1;
   FF1=M_abc_lump.*FF;
   tf=tic;
  u=onlinewaveabc(AA2,AA1,FF1,ft,step,0.9*T,dt,5);
   tf=toc(tf);
fprintf('t fine is %2.1f seconds\n',tf);
imagescsquare1(u(1:ne));title('fine solution')
