function [localdof1,localdof]=vectorize_eli(localdof0)
localdof0=localdof0(:);
n=size(localdof0,1);
localdof=zeros(n,3);
localdof(:,1)=localdof0*3-2;
localdof(:,2)=localdof0*3-1;
localdof(:,3)=localdof0*3;
localdof1=localdof';localdof1=localdof1(:);
  