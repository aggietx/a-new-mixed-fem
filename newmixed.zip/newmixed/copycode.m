			% % % % $1/4$& 2.5009e-03  & & 2.2111e-01 &   & 3.5651e-02& &   \tabularnewline\hline
			% % % % $1/8$&   9.4662e-04& &  9.9777e-02&   & 6.8630e-03& &   \tabularnewline\hline
			% % % % $1/16$% % 	&2.9016e-04   & &4.8401e-02  &   &1.7005e-03 & &   \tabularnewline\hline

computerate([2.5009e-03,9.4662e-04,2.9016e-04 ]);
computerate([2.2111e-01,9.9777e-02,4.8401e-02 ]);
computerate([3.5651e-02,6.8630e-03,1.7005e-03 ]);

return
            % du1dy=@(x,y) 2*pi*cos(pi*x).*cos(2*pi*y);
% du2dx=@(x,y) pi*cos(pi*x).*cos(pi*y);

[xp,yp]=meshgrid(0:hx:Lx,0:hy:Ly);
rote=du2dx(xp,yp)-du1dy(xp,yp);rote=rote(:)/2;
rota=u(end-np+1:end);
rote=reshape(rote,ny+1,nx+1);
rota=reshape(rota,ny+1,nx+1);
rote=rote(1:end-1,1:end-1)+rote(2:end,1:end-1)+rote(1:end-1,2:end)+rote(2:end,2:end);
rota=rota(1:end-1,1:end-1)+rota(2:end,1:end-1)+rota(1:end-1,2:end)+rota(2:end,2:end);
rote=rote(:)/4;rota=rota(:)/4;
fprintf('relative error and error of rotation are %2.4e %2.4e\n',norm(rote-rota)/norm(rote),sqrt(sum((rote-rota).^2)*vol) );

u1_exact=@(x,y) cos(pi*x).*sin(2*pi*y);ue1=u1_exact(xe(:),ye(:));
u2_exact=@(x,y) sin(pi*x).*cos(pi*y);ue2=u2_exact(xe(:),ye(:));
du1dy=@(x,y) 2*pi*cos(pi*x).*cos(2*pi*y);
du2dx=@(x,y) pi*cos(pi*x).*cos(pi*y);
rote=du2dx(xe,ye)-du1dy(xe,ye);rote=rote(:)/2;
rota=u(end-ne+1:end);
fprintf('relative error and error of rotation are %2.4e %2.4e\n',norm(rote-rota)/norm(rote),sqrt(sum((rote-rota).^2)*vol) );
