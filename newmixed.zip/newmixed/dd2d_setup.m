
function  [alllocalL,alllocalU,alltrue_dof,alllocal_pdof,alllocal_pdofov,allinveli0]=dd2d_setup(Nx,Ny,n,lambda,mu,...
    localA12,localA11a,localA11b,localA22a,localA22b,ddov)


disp('dd 2d setup...')

nx=Nx*n;ny=Ny*n;ne=nx*ny;h=1/nx;vol=h^2;

% % kappa=K*10^6;
% ddov=0;
ts=tic;




p_dof=reshape(1:nx*ny,ny,nx);

Ncb=Nx*Ny;

 alllocalsize=zeros(2,Ncb);
 alllocallambda=cell(Ncb,1);
 alllocalmu=cell(Ncb,1);
 alllocal_pdof=cell(Ncb,1);
 alllocal_pdofov=cell(Ncb,1);
alltrue_dof=cell(Ncb,1);
allinveli0=cell(Ncb,1);
    for ii2=1:Nx
        for ii1=1:Ny
    iie=(ii2-1)*Ny+ii1;
    locallambda=lambda( max( (ii1-1)*n+1-ddov,1):min(ii1*n+ddov,ny),...
        max( (ii2-1)*n+1-ddov,1):min(ii2*n+ddov,nx));
    localmu=mu( max( (ii1-1)*n+1-ddov,1):min(ii1*n+ddov,ny),...
        max( (ii2-1)*n+1-ddov,1):min(ii2*n+ddov,nx));    
[localny,localnx]=size(locallambda);
    alllocalsize(:,iie)=[localny,localnx];
             global_p_dof=p_dof( (ii1-1)*n+1:ii1*n,(ii2-1)*n+1:ii2*n);
global_p_dof=global_p_dof(:);
global_p_dofov=p_dof( max( (ii1-1)*n+1-ddov,1):min(ii1*n+ddov,ny),...
        max( (ii2-1)*n+1-ddov,1):min(ii2*n+ddov,nx));
global_p_dofov=global_p_dofov(:);
[~,true_dof]=ismember([global_p_dof;global_p_dof+ne],[global_p_dofov;global_p_dofov+ne]);
alltrue_dof{iie}=true_dof(:);
alllocallambda{iie}=locallambda;
alllocalmu{iie}=localmu;
alllocal_pdof{iie}=[global_p_dof;global_p_dof+ne];
alllocal_pdofov{iie}=[global_p_dofov;global_p_dofov+ne];
        end
    end


alllocalL=cell(Ncb,1);
alllocalU=cell(Ncb,1);
% np=(n+1)^2;
% [Aaug1,D,ir1,ic1,nodedof,bddof]=assemble2d_matrix_partb(n,n,h,h);
% Aaug1(bddof,:)=0;
for iie=1:Ny*Nx
% for iie=1:Ny*Nx
% localny=n;
% localnx=n;
locallambda=alllocallambda{iie};
[localny,localnx]=size(locallambda);
% nlocale=localnx*localny;
localmu=alllocalmu{iie};
localmu_bar=1/2./(localmu);

np=(localnx+1)*(localny+1);
[Aaug1,D,ir1,ic1,nodedof,bddof]=assemble2d_matrix_partb(localnx,localny,h,h,localmu_bar(:));
% Aaug1(bddof,:)=0;%%% neumann

localmu=alllocallambda{iie};


[invAss,~]=assemble2d_matrix_parta(localnx,localny,h,h,locallambda,localmu,localA12,localA11a,localA11b,localA22a,localA22b,ir1,ic1,nodedof);


Aeli=eli_matrix0(invAss,Aaug1,D);
invArr=1./diag(Aeli(1:np,1:np));
D2=Aeli(np+1:end,np+1:end); Aaug=Aeli(1:np,np+1:end);
Aeli0=eli_matrix0(invArr',Aaug,D2);


         [L,U]=lu(Aeli0);
        alllocalL{iie}=L;
        alllocalU{iie}=U; 
        allinveli0{iie}=inv(Aeli0);
end


 tb=toc(ts);
  fprintf('T setup is %2.2f seconds\n',tb);