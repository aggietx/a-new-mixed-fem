function id1=getid(i1,i2,i3)
 id1=(i3-1)*4+(i2-1)*2+i1;

return
i1a=3;i2a=3;i3a=3;
for i3a=1:nz
  for i2a=1:ny
    for i1a=1:nx
% [i1,i2,i3]=deal(1,2,2);
% fprintf('i1 i2 i3 are %d %d %d\n',i1a,i2a,i3a);
 id = i1a + ny * (i2a-1) + ny*nz * (i3a-1);

 id = i1a + (ny+1) * (i2a-1) + (ny+1)*(nz+1) * (i3a-1);

i3 = ceil(id / (ny * nz));
i2 = ceil((id - (i3-1) * ny * nz) / ny);
i1 = id - ny * (i2-1 + nz * (i3-1));

% fprintf('i1 i2 i3 are %d %d %d\n',i1,i2,i3);

if norm([i1,i2,i3]-[i1a,i2a,i3a])~=0
disp('error')
end

% disp('....')
    end
  end
end