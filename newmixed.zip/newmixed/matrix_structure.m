%%% test matrix structure
clear;
close all

nx=60;ny=nx;ne=nx*ny;nvet=2*ny*(nx+1);nhor=2*nx*(ny+1);nvdof=nvet+nhor;nedge=ny*(nx+1)+nx*(ny+1);
Lx=60;Ly=60;hx=Lx/nx;hy=Ly/ny;vol=hx*hy;np=(nx+1)*(ny+1);
n=10;Nx=nx/n;Ny=ny/n;
nmaxbasis=14;gs=0;q0=0;eigvalue_tol=10;tol=10^(-5);regvalue=10^(-18);
poission_ratio=0.3;
% load k1;young_modulus=k1;
% young_modulus=k1(1:100,1:100);young_modulus=repmat(young_modulus,ny/100,nx/100);
% young_modulus=1*ones(ny,nx);% % depends on x

% young_modulus=young_modulus.^(5/4);
young_modulus=ones(ny,nx);
lambda=poission_ratio/((1+poission_ratio)*(1-2*poission_ratio))*young_modulus;
mu=1/2/(1+poission_ratio)*young_modulus;
lambda=3*ones(ny,nx);mu=5*ones(ny,nx);
lambda=lambda(:);mu=mu(:);

s=lambda(1,1);t=mu(1,1);
lambda_bar=-lambda./(4*mu.*(lambda+mu));
mu_bar=1/2./(mu);
lambdabar_mubar=lambda_bar+mu_bar;
% fprintf('contrast is %2.1e\n',max(young_modulus(:))/min(young_modulus(:)) );

%% (As,s) matrix
localA12=zeros(16,16);
localA12(1,10)=1;localA12(3,12)=1;localA12(5,14)=1;localA12(7,16)=1;
localA12(10,1)=1;localA12(12,3)=1;localA12(14,5)=1;localA12(16,7)=1;
localA11a=zeros(16,16);localA11b=zeros(16,16);localA22a=zeros(16,16);localA22b=zeros(16,16);

for i=1:2:7;localA11a(i,i)=1;end
for i=[9,11,13,15];localA11b(i,i)=1;end
for i=2:2:8;localA22a(i,i)=1;end
for i=[10,12,14,16];localA22b(i,i)=1;end
tic
[Aaug1,D,ir1,ic1,nodedof,~,nodedge]=assemble2d_matrix_partb(nx,ny,hx,hy,mu_bar);
[invAss,Ass]=assemble2d_matrix_parta(nx,ny,hx,hy,lambda,mu,localA12,localA11a,localA11b,localA22a,localA22b,ir1,ic1,nodedof);
toc
%% solve
F=zeros(2*ne+2*nvdof+np,1);
F(2*nvdof+1+np:2*nvdof+2*ne+np)=-1*vol;
tic

    %Aaug1=A(1:nvdof*2,nvdof*2+1:end);
 [Aeli,Feli]=eli_matrix(invAss,Aaug1,D,F);
invArr=sparse(1:np,1:np,1./diag(Aeli(1:np,1:np)));D=Aeli(np+1:end,np+1:end); Aaug=Aeli(1:np,np+1:end);
[Aeli0,Feli0,u0,uf0]=eli(invArr,Aaug,D,Feli);

toc
% imagescsquare1(u0(1:ne));title('u1')
% imagescsquare1(u0(1+ne:2*ne));title('u2')
% Aeli0(265,:)
u=Aeli0\Feli0;A=Aeli0;
% imagescsquare1(u(1:ne))
a=[Aeli0(265,214:216);Aeli0(265,264:266);Aeli0(265,314:316)];full(a')