%%%% basis are the same as rt0, all vector basis are (1,0) or (0,1), no
%%%% negative, stress and rotation elimination
%%% (x,y,z)
%%%% continuous rotation
%%%% homogeneous bd
clear;
close all
nx1=32;nx2=nx1;nx3=nx1;nx=nx1;ny=nx2;nz=nx3;
Lx1=1;Lx2=1;Lx3=1;ne=nx1*nx2*nx3;hx1=1/nx1;hx2=1/nx2;hx3=1/nx3;vol=hx1*hx2*hx3;np=(nx1+1)*(nx2+1)*(nx3+1);
nface=(nx1+1)*nx2*nx3+(nx2+1)*nx1*nx3+(nx3+1)*nx1*nx2;nvdof=4*nface;hx=hx1;hy=hx2;hz=hx3;
[nodedge,nodv,facex1,facex2,facey1,facey2,facez1,facez2,nodedof]=local2globaldof3d_inveli_elastic(nx,ny,nz);

fprintf('nx is %d\n',nx);

lambda=1*ones(ne,1);mu=1*ones(ne,1);

lambda=lambda(:);mu=mu(:);
s=lambda(1,1);t=mu(1,1);
lambda_bar=-lambda./(2*mu.*(3*lambda+2*mu));
mu_bar=1/2./(mu);
lambdabar_mubar=lambda_bar+mu_bar;
fprintf('s is, s over t is %2.2f %2.2f\n',s,s/t);
%% (As,s) matrix
map=zeros(72,1);id1=1:3:72;id2=2:3:72;id3=3:3:72;
map(1:24)=1:3:72;map(1:24)=1:3:72;map(25:48)=2:3:72;map(49:72)=3:3:72;
%iv11=[ones(8,1)*lambdabar_mubar';ones(8,1)*mu_bar';ones(8,1)*mu_bar'];
iv11=zeros(72,ne);iv22=zeros(72,ne);iv33=zeros(72,ne);
iv11(id1,:)=[ones(8,1)*lambdabar_mubar';ones(8,1)*mu_bar';ones(8,1)*mu_bar'];
iv22(id2,:)=[ones(8,1)*mu_bar';ones(8,1)*lambdabar_mubar';ones(8,1)*mu_bar'];
iv33(id3,:)=[ones(8,1)*mu_bar';ones(8,1)*mu_bar';ones(8,1)*lambdabar_mubar'];

Ass11=sparse(nodedge,nodedge,iv11)*vol/8;
Ass22=sparse(nodedge,nodedge,iv22)*vol/8;
Ass33=sparse(nodedge,nodedge,iv33)*vol/8;

ir1=zeros( (3*6*4)^2,ne);%%%3：3d，6，6 faces, 4, each face 4 dof
ic1=zeros( (3*6*4)^2,ne);
localA12=zeros(72,72);

pair=[1*3-2,9*3-1,17*3;
     2*3-2,13*3-1,19*3;
     3*3-2,11*3-1,21*3;
     4*3-2,15*3-1,23*3;
     5*3-2,10*3-1,18*3;
     6*3-2,14*3-1,20*3;
     7*3-2,12*3-1,22*3;
     8*3-2,16*3-1,24*3];
for i=1:8
localA12(pair(i,1),pair(i,2))=1;
localA12(pair(i,1),pair(i,3))=1;
localA12(pair(i,2),pair(i,1))=1;
localA12(pair(i,3),pair(i,1))=1;
localA12(pair(i,2),pair(i,3))=1;
localA12(pair(i,3),pair(i,2))=1;
end


id=1;
%nodedge=zeros(72,ne);
for i3=1:nx3
  for i2=1:nx2
    for i1=1:nx1
%localedof=[nodv(:,id);nodv(:,id)+nvdof;nodv(:,id)+2*nvdof];
%nodedge(:,id)=localedof;
localedof=nodedge(:,id);
ir1(:,id)=repmat(localedof,72,1);
temp=repmat(localedof,1,72);temp=temp';ic1(:,id)=temp(:);
id=id+1;
    end
  end
end
Ass=Ass11+Ass22+Ass33+sparse(ir1,ic1,localA12(:)*lambda_bar'*vol/8);
% tic;a=Ass\speye(size(Ass,1));toc
% spy(Ass)

invAss_local=cell(np,1);
id=0;
for i=1:np
ndof=nodedof(i)*3;

invAss_local{i}=inv(Ass(id+1:id+ndof,id+1:id+ndof));
id=id+ndof;
end
invAss=blkdiag(invAss_local{:});



%% stress and rotation
index1=[1,3,5,7,2,4,6,8];index2=[1,2,5,6,3,4,7,8];index3=1:8;
localsr=zeros(72,3*8);
for i=9:16;localsr(map(i),16+index2(i-8))=-1;end
for i=17:24;localsr(map(i),8+index3(i-16))=-1;end
for i=25:32;localsr(map(i),16+index1(i-24))=1;end
for i=41:48;localsr(map(i),index3(i-40))=-1;end
for i=49:56;localsr(map(i),8+index1(i-48))=1;end
for i=57:64;localsr(map(i),index2(i-56))=1;end

localsr=localsr*vol/8;
allrdof=reshape(1:(nx+1)*(ny+1)*(nz+1),nx+1,ny+1,nz+1);
ir=zeros(72*3*8,ne);
ic=zeros(72*3*8,ne);
id=1;
for i3=1:nx3
  for i2=1:nx2
    for i1=1:nx1
localedof=nodedge(:,id); ir(:,id)=repmat(localedof,3*8,1);
localrdof=allrdof(i1:i1+1,i2:i2+1,i3:i3+1);localrdof=localrdof(:);
localrdof1=[localrdof;localrdof+np;localrdof+2*np];
temp=repmat(localrdof1,1,72);temp=temp';ic(:,id)=temp(:);

id=id+1;
    end
   end
end
Ars=sparse(ir,ic,repmat(localsr(:),1,ne));


%% stress and displacement
ir=zeros(72*3,ne);
ic=zeros(72*3,ne);
id=1;
for i3=1:nx3
  for i2=1:nx2
    for i1=1:nx1
localedof=nodedge(:,id); ir(:,id)=repmat(localedof,3,1);
localrdof=[id,id+ne,id+2*ne];localrdof=localrdof(:);
temp=repmat(localrdof,1,72);temp=temp';ic(:,id)=temp(:);

id=id+1;
    end
   end
end
localsp=zeros(72,3);
for i=[1:4,9:12,17:20];localsp(map(i),1)=-1;end
for i=[1:4,9:12,17:20]+24;localsp(map(i),2)=-1;end
for i=[1:4,9:12,17:20]+48;localsp(map(i),3)=-1;end
for i=[1:4,9:12,17:20]+4;localsp(map(i),1)=1;end
for i=[1:4,9:12,17:20]+4+24;localsp(map(i),2)=1;end
for i=[1:4,9:12,17:20]+4+48;localsp(map(i),3)=1;end
localsp=localsp*hx1*hx2/4;
ivalue=repmat(localsp(:),1,ne);

Asp=sparse(ir,ic,ivalue);clear ivalue ix 


%% 

F=zeros(nvdof*3+3*ne+3*np,1);

% F(nvdof*3+1:nvdof*3+3*ne)=vol;

% disp('solve linear system...')
% tic;u=A\F;toc
%% post
[ye,xe,ze]=meshgrid(hx/2:hx:1,hy/2:hy:1,hz/2:hz:1);%%[x,y,z]=meshgrid(0:1/5:1,0:1/4:1,0:1/3:1);
uexact1=@(x,y,z) sin(pi*x).*sin(pi*y).*sin(pi*z);ue1=uexact1(xe,ye,ze);ue1=ue1(:);
uexact2=@(x,y,z) sin(pi*x).*sin(pi*y).*sin(pi*z);ue2=ue1;ue3=ue1;
uexact3=@(x,y,z) sin(pi*x).*sin(pi*y).*sin(pi*z);
uxx=@(x,y,z) -pi^2*sin(pi*x).*sin(pi*y).*sin(pi*z);
uyy=@(x,y,z) -pi^2*sin(pi*x).*sin(pi*y).*sin(pi*z);
uzz=@(x,y,z) -pi^2*sin(pi*x).*sin(pi*y).*sin(pi*z);
uxy=@(x,y,z) pi^2*cos(pi*x).*cos(pi*y).*sin(pi*z);
uyz=@(x,y,z) pi^2*sin(pi*x).*cos(pi*y).*cos(pi*z);
uxz=@(x,y,z) pi^2*cos(pi*x).*sin(pi*y).*cos(pi*z);
f1=@(x,y,z) (s+4*t)*(-pi^2*sin(pi*x).*sin(pi*y).*sin(pi*z))+...
    (s+t)*(pi^2*cos(pi*x).*cos(pi*y).*sin(pi*z)+pi^2*cos(pi*x).*sin(pi*y).*cos(pi*z));
f2=@(x,y,z) (s+4*t)*(-pi^2*sin(pi*x).*sin(pi*y).*sin(pi*z))+...
    (s+t)*(pi^2*cos(pi*x).*cos(pi*y).*sin(pi*z)+pi^2*sin(pi*x).*cos(pi*y).*cos(pi*z));
f3=@(x,y,z) (s+4*t)*(-pi^2*sin(pi*x).*sin(pi*y).*sin(pi*z))+...
    (s+t)*(pi^2*cos(pi*x).*sin(pi*y).*cos(pi*z)+pi^2*sin(pi*x).*cos(pi*y).*cos(pi*z));
F1=f1(xe,ye,ze);
F2=f2(xe,ye,ze);
F3=f3(xe,ye,ze);
F(3*nvdof+3*np+1:end)=[F1(:);F2(:);F3(:)]*vol;




if 0
    A=[Ass, Ars,Asp;
   Ars',sparse(3*np,3*ne+3*np);
   Asp',sparse(3*ne,3*ne+3*np)];
    disp('solve linear system...')
tic;u=A\F;toc;uu=u(nvdof*3+1+3*np:nvdof*3+3*ne+3*np);

else
    tic
    disp('solve with elimination....')
    Aaug1=[Ars,Asp];D=sparse(3*ne+3*np,3*ne+3*np);
[Aeli,Feli]=eli_matrix(invAss,Aaug1,D,F);
% tic;uur=Aeli\Feli;toc;uu=uur(1+3*np:3*ne+3*np);
%  rnorm(uu,u(nvdof*3+1+3*np:nvdof*3+3*ne+3*np));
invArr=sparse(1:3*np,1:3*np,1./diag(Aeli(1:3*np,1:3*np)));
D=Aeli(3*np+1:end,3*np+1:end); Aaug=Aeli(1:3*np,3*np+1:end);
% [Aeli0,Feli0,u0,uf0]=eli(invArr,Aaug,D,Feli);
[Aeli0,Feli0]=eli_matrix(invArr,Aaug,D,Feli);
u0=ilu_solver(Aeli0,Feli0,10^(-10));
uur=zeros(3*np+3*ne,1);uur(1+3*np:end)=u0;
uur(1:3*np)=invArr*(Feli(1:3*np)-Aaug*u0);
u=zeros(size(F,1),1);u(nvdof*3+3*np+1:end)=u0;
u(1:nvdof*3)=invAss*(F(1:3*nvdof)-Aaug1*uur);

%rnorm(u0,uu);
toc

end

% ua1=u(nvdof*3+1:nvdof*3+ne);
% imagesc3dsquare(ua1,1);title('approx u1')
% imagesc3dsquare(ue1(:),1);title('exact u1')
%% post
ua1=u(nvdof*3+1+0+3*np:nvdof*3+1*ne+3*np);
ua2=u(nvdof*3+1+ne+3*np:nvdof*3+2*ne+3*np);
ua3=u(nvdof*3+1+2*ne+3*np:nvdof*3+3*ne+3*np);

ua=sqrt(ua1.^2+ua2.^2+ua3.^2);ue=sqrt(ue1.^2+ue2.^2+ue3.^2);
% imagesc3dsquare(ue2(:),0);title('exact u2');imagesc3dsquare(ua2,0);title('approx u2')
% imagesc3dsquare(ue(:),0);title('exact u');imagesc3dsquare(ua,0);title('approx u')

diff=sqrt(ua1.^2+ua2.^2+ua3.^2)-sqrt(ue1.^2+ue2.^2+ue3.^2);
exact=sqrt(ue1.^2+ue2.^2+ue3.^2);
Mass=vol*speye(ne);
err=sqrt(diff'*Mass*diff);
rerr=sqrt(diff'*Mass*diff)/sqrt(exact'*Mass*exact);
% fprintf('size is %d\n',nx)
fprintf('relative error and error of displacement are %2.4e %2.4e\n',norm(diff)/norm(exact),sqrt(sum(diff.^2)*vol) );
