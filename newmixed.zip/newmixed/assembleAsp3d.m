function Asp=assembleAsp3d(map,hx1,hx2,ne,nodedge,np,nvdof)
% tic
% disp('generate stress and displacement matrix...')
localsp=zeros(72,3);
for i=[1:4,9:12,17:20];localsp(map(i),1)=-1;end
for i=[1:4,9:12,17:20]+24;localsp(map(i),2)=-1;end
for i=[1:4,9:12,17:20]+48;localsp(map(i),3)=-1;end
for i=[1:4,9:12,17:20]+4;localsp(map(i),1)=1;end
for i=[1:4,9:12,17:20]+4+24;localsp(map(i),2)=1;end
for i=[1:4,9:12,17:20]+4+48;localsp(map(i),3)=1;end
localsp=localsp*hx1*hx2/4;nzid=find(localsp(:));
tic

nodele=zeros(3,ne);nodele(1,:)=1:ne;nodele(2,:)=1+ne:2*ne;nodele(3,:)=1+2*ne:3*ne;
ir=kron(nodedge,ones(1,3));ir=reshape(ir(:),72*3,ne);ir=ir(nzid,:);
ic=kron(nodele,ones(72,1));



ic=ic(nzid,:);

Asp=sparse(ir,ic+3*np,repmat(localsp(nzid),1,ne),3*nvdof,3*ne+3*np);clear ivalue ix 
% toc