
function  phimatrix_pa=assemble_poly2d_elastic(Nx,Ny,n,order)
%%% with oversampling, no tolerance adatpvitiy
nb=(order+1)^2;nlocal_basis=2*nb;
basis0=get_2d_polybasis_cell(n,n,order);basis=zeros(2*n^2,2*nb);
basis(1:n^2,1:nb)=basis0;basis(1+n^2:2*n^2,nb+1:end)=basis0;

disp('generate 2d poly basis...')

nx=Nx*n;ny=Ny*n;ne=nx*ny;

ts=tic;



p_dof=reshape(1:nx*ny,ny,nx);



dim_pc=2*nb*Nx*Ny;
ixp=zeros(dim_pc,2*n^2);
ivaluep=zeros(dim_pc,2*n^2);
iyp=(1:dim_pc)'*ones(1,2*n^2);
ind=1;

    for ii2=1:Nx
        for ii1=1:Ny
                 global_p_dof=p_dof( (ii1-1)*n+1:ii1*n,(ii2-1)*n+1:ii2*n);
   global_p_dof=[global_p_dof(:);global_p_dof(:)+ne];
global_p_dof=sort( global_p_dof(:));

    ixp(ind:ind+nlocal_basis-1,:)= repmat( global_p_dof,1,nlocal_basis)';
    ivaluep(ind:ind+nlocal_basis-1,:)=basis';   
ind=ind+nlocal_basis;  

        end
    end



disp('assembling coarse matrix...')
clear alllocal_pdof allbasis p_dof
 phimatrix_pa=sparse(iyp,ixp,ivaluep,dim_pc,ne*2);clear ixp iyp ivaluep
 fprintf('dim of are %d %d\n',dim_pc,ne);
 fprintf('average basis number is %2.2f\n',dim_pc/(Nx*Ny));
 disp('END of generating gms basis')
 tb=toc(ts);
  fprintf('Tbasis is %2.2f seconds\n',tb);