function polybasis=get_2d_polybasis_cell(nx,ny,order)



[xo,yo]=getcoor_sem(-1,1,-1,1,nx-1,ny-1,order);
polyo=get_coarseleg(xo,yo,order);
mesh_nodes=get_meshdof(nx-1,ny-1,order);
polybasis=polyo(mesh_nodes,:);
