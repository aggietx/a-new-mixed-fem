function k=slope(x1,x2,y1,y2)

k=(y1-y2)/(x1-x2);