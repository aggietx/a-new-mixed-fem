function Avp=assembleAvp3d(hx1,hx2,ne,nodv)

localvp=zeros(24,1);
for i=[1:4,9:12,17:20];localvp(i)=-1;end
for i=[1:4,9:12,17:20]+4;localvp(i)=1;end
localvp=localvp*hx1*hx2/4;
ivalue=repmat(localvp,1,ne);
ix=repmat(1:ne,24,1);
Avp=sparse(nodv,ix,ivalue);clear ivalue ix 
