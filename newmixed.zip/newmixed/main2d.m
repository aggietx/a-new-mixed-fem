clear;
close all

nx=8*2;ny=nx;ne=nx*ny;nvet=2*ny*(nx+1);nhor=2*nx*(ny+1);nvdof=nvet+nhor;
Lx=1;Ly=1;hx=Lx/nx;hy=Ly/ny;vol=hx*hy;
nodv=local2globaldofb(nx,ny);
perm=ones(ny,nx);
% load k1;perm=k1;
alpha=1./perm;
Avv=sparse(nodv,nodv,ones(8,1)*alpha(:)')*vol/4;

fprintf('nx is %d\n',nx);
T=zeros(nvdof,1);
localvp=[-1,-1,1,1,-1,-1,1,1]'*hx/2;
ivalue=repmat(localvp,1,ne);
ix=repmat(1:ne,8,1);
Avp=sparse(nodv,ix,ivalue);clear ivalue ix 

A=[Avv,Avp;
   Avp',sparse(ne,ne)];

F=zeros(ne+nvdof,1);
F(nvdof+1:end)=-1*vol;


u=A\F;
ua=u(nvdof+1:end);
% imagescsquare1(ua)

uexact=@(x,y) sin(2*pi*x).*sin(2*pi*y);
ux=@(x,y) 2*pi*cos(2*pi*x).*sin(2*pi*y);
uy=@(x,y) 2*pi*sin(2*pi*x).*cos(2*pi*y);
uxx=@(x,y) -4*pi^2*sin(2*pi*x).*sin(2*pi*y);
uyy=@(x,y) -4*pi^2*sin(2*pi*x).*sin(2*pi*y);
f=@(x,y) -8*pi^2*sin(2*pi*x).*sin(2*pi*y);
[xe,ye]=meshgrid(hx/2:hx:Lx-hx/2,hy/2:hy:Ly-hy/2);
force=f(xe,ye);
F(nvdof+1:end)=force(:)*vol;
u=A\F;
[xe2,ye2]=meshgrid(hx/4:hx/2:Lx,hy/4:hy/2:Ly);
vxe=ux(xe2,ye2);vye=uy(xe2,ye2);
vxave=zeros(ny,nx);vyave=zeros(ny,nx);
  for i2=1:2
    for i1=1:2
vxave=vxave+vxe(i1:2:end,i2:2:end);
vyave=vyave+vye(i1:2:end,i2:2:end);
    end
  end
vxave=vxave/4;vyave=vyave/4;

%% post
ua=u(nvdof+1:end);
ue=uexact(xe,ye);
rnorm(ua,ue);

id=1;
vxa=zeros(ne,1);vya=zeros(ne,1);
  for i2=1:nx
    for i1=1:ny
localsdof=nodv(:,id); 
localv=u(localsdof);
vxa(id)=mean(localv(1:4));
vya(id)=mean(localv(5:8));
id=id+1;
    end
   end
va=sqrt(vxa.^2+vya.^2);
ve=sqrt(vxave.^2+vyave.^2);
% rnorm(vxa,vxave);
rnorm(va,ve);
if 0
    disp('velocity elimination....')
diagAvv=fsparse(ones(size(nodv)),nodv,ones(8,1)*alpha(:)')*vol/4;diagAvv=1./diagAvv;
Aeli=-(Avp'.*diagAvv)*Avp;
F=-1*vol*ones(ne,1);
ueli=Aeli\F;
imagescsquare1(ueli)
end