function  [u,relres2,iter2]=gs_solver(Kd,F,varargin)
ne=size(F,1);
    opt = struct('tol'     , 10^(-8)                      , ...
                 'omega'    , 1.8, ...
                 'step', 5                            , ...
                 'initype' , 1              , ...
                 'bicg', 1 );
    opt = merge_options(opt, varargin{:});
    tol=opt.tol;
    omega=opt.omega;
    step=opt.step;

    bicg=opt.bicg;

fprintf('dof is %d\n',ne);
uinit=zeros(ne,1);

        t2grid0=tic ;

    D=sparse(1:ne,1:ne,diag(Kd));
    L1 = tril(Kd,-1);
    N = D + omega*L1;
    M = (1 - omega)*D - omega*triu(Kd,1);
      tsolve2grid0=toc(t2grid0);
      t2grid1=tic ;
         precond2=@(inc)pre_gs(inc, N,M,zeros(ne,1),step);
disp('solve with gs smoother...')
% ua=precond2(F);
% rnorm(ua,Kd\F);
if bicg
 [u,~,relres2,iter2]=bicgstab(Kd,F,tol, 5000,precond2,[],uinit);tsolve2grid1=toc(t2grid1);
 relres2=norm(F-Kd*u)/norm(F);
  fprintf('bicgstab number,residual,tsolve(gs) are %d %2.2e %2.2f + %2.2f = %2.2f seconds\n',ceil(iter2*2),relres2,tsolve2grid0,tsolve2grid1,tsolve2grid0+tsolve2grid1);   %%floor(iter2(size(iter2,2)))
else
  [u,~,relres2,iter2]=gmres(Kd,F,10,tol, 50,precond2,[],uinit);tsolve2grid1=toc(t2grid1);
   relres2=norm(F-Kd*u)/norm(F);
 fprintf('gmres number,residual,tsolve(gs) are %d %2.2e %2.2f + %2.2f = %2.2f seconds\n',ceil(iter2(1)*iter2(2)),relres2,tsolve2grid0,tsolve2grid1,tsolve2grid0+tsolve2grid1);   %%floor(iter2(size(iter2,2)))
end
end


function  x=pre_gs(Fpre, N,M,x,step1)




%% smooothing
   for k = 1:step1
     x =  N\(Fpre + M*x);
   end


end
