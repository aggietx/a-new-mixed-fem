disp('generate all matrix in dual grid, continuous case...')
tic
%%% generate Ass in dual mesh
nodedof=nodeface(nx,ny,nz);
nodedofv=zeros(36,np);nodedofv(1:3:end,:)=nodedof*3-2;nodedofv(2:3:end,:)=nodedof*3-1;
nodedofv(3:3:end,:)=nodedof*3;%find(nodedofv(:,1)==1);
nodedofv2=nodedofv;nodedofv2(nodedofv<=0)=1;
toc
tic

invAss_local=cell(np,1);

%%% stress rotation
ir=kron(nodedofv2,ones(1,3));ir=reshape(ir,36*3,np);
nodelr=zeros(3,np);nodelr(1,:)=1:np;nodelr(2,:)=1+np:2*np;nodelr(3,:)=1+2*np:3*np;
ic=kron(nodelr,ones(36,1));
ivaluesr=zeros(36*3,np);
%%%% stress displacement
ir1=kron(nodedofv2,ones(1,24));ir1=reshape(ir1,36*24,np);
maske=ones(nx+2,ny+2,nz+2);
maske(2:end-1,2:end-1,2:end-1)=reshape(1:nx*ny*nz,nx,ny,nz);
nodee=zeros(24,np); %%% element dof associate with a node
id=1;
for i3=1:nx3+1
  for i2=1:nx2+1
    for i1=1:nx1+1
        locale=maske(i1:i1+1,i2:i2+1,i3:i3+1);locale=locale(:);
nodee(:,id)=[locale;locale+ne;locale+2*ne];
id=id+1;
    end
  end
end
ic1=kron(nodee,ones(36,1));
ivaluesp=zeros(36*24,np);
maskcoeff=zeros(nx+2,ny+2,nz+2);maskcoeff(2:end-1,2:end-1,2:end-1)=1;
allm=cell(np,1);alll=cell(np,1);allmc=cell(np,1);
markudof=ones(nx+2,ny+2,nz+2);markudof(2:end-1,2:end-1,2:end-1)=reshape(1:nx*ny*nz,nx,ny,nz);
markudof1=zeros(nx+2,ny+2,nz+2);markudof1(2:end-1,2:end-1,2:end-1)=reshape(1:nx*ny*nz,nx,ny,nz);
alludof=zeros(24,np);
alludof1=zeros(24,np);

id=1;
for i3=1:nx3+1
  for i2=1:nx2+1
    for i1=1:nx1+1
alll{id}=lambda_bare(i1:i1+1,i2:i2+1,i3:i3+1);
allm{id}=mu_bare(i1:i1+1,i2:i2+1,i3:i3+1);
allmc{id}=maskcoeff(i1:i1+1,i2:i2+1,i3:i3+1);
temp0=markudof(i1:i1+1,i2:i2+1,i3:i3+1);temp0=temp0(:);
temp=[temp0;temp0+ne;temp0+2*ne];alludof(:,id)=temp;

id=id+1;
    end
  end
end

%%% i1=2;i2=2;i3=2;
%%% i1=1;i1=1;i1=1;
%%% (i3-1)*(nx1+1)*(nx2+1)+(i2-1)*(nx1+1)+i1
parfor id=1:np   
% for id=1:np 

% i3 = ceil(id / ( (ny+1) * (nz+1)));
% i2 = ceil((id - (i3-1) * (ny+1) * (nz+1)) / (ny+1));
% i1 = id - (ny+1) * (i2-1 + (nz+1) * (i3-1));
% id=1;
% for i3=1:nx3+1
%       for i2=1:nx2+1
%           for i1=1:nx1+1
              
 % if ismember(i1,2:nx1) && ismember(i2,2:nx2) && ismember(i3,2:nx3)
 %           nzid=1:36;
 % else
     localdof=nodedof(:,id);
          nzid=find(localdof);nzid=vectorize_eli(nzid);   
 % end

% l=lambda_bare(i1:i1+1,i2:i2+1,i3:i3+1);
% m=mu_bare(i1:i1+1,i2:i2+1,i3:i3+1);
% mc=maskcoeff(i1:i1+1,i2:i2+1,i3:i3+1);
% lm=l+m;
l=alll{id};m=allm{id};mc=allmc{id};
lm=l+m;
% getlocaldualmatrix_continuous%%%%%%%%%%%
[localAss1,localAsr1,localAsp1]=computelocaldualmatrix_continuous(lm,l,m,mc,vol,hx,hy);
localAss=localAss1(nzid,nzid);
localAss=sparse(localAss);
invAss_local{id}=inv(localAss);
% invAss_local{id}=localAss\speye(length(nzid));
ivaluesr(:,id)=localAsr1(:);
ivaluesp(:,id)=localAsp1(:);



% id=id+1;
%         end
%     end
end
salocalAsr=ivaluesr(:,3 + (ny+1) * (3-1) + (ny+1)*(nz+1) * (3-1));
salocalAsp=ivaluesp(:,3 + (ny+1) * (3-1) + (ny+1)*(nz+1) * (3-1));
invAss=blkdiag(invAss_local{:});
nzid=find(salocalAsr);nzid1=find(salocalAsp);
ivaluesr=ivaluesr(nzid,:);ivaluesp=ivaluesp(nzid1,:);
Ars=sparse(ir(nzid,:),ic(nzid,:),-ivaluesr,3*nvdof,3*np+3*ne);
Asp=-sparse(ir1(nzid1,:),ic1(nzid1,:)+3*np,ivaluesp,3*nvdof,3*ne+3*np);



clear ivaluesr ir ic invAss_local ir1 ic1 ivaluesr ivaluesp maskcoeff mu_bare lambda_bare nodedofv2 nodedofv alleli iru icu alludof
clear alllocalF1
toc
disp('.............')