%%%% coefficient example from poroelasticity paper
clear;
close all

nx=16*32;ny=nx;ne=nx*ny;nvet=2*ny*(nx+1);nhor=2*nx*(ny+1);nvdof=nvet+nhor;nedge=ny*(nx+1)+nx*(ny+1);
Lx=1;Ly=1;hx=Lx/nx;hy=Ly/ny;vol=hx*hy;np=(nx+1)*(ny+1);
n=20;Nx=nx/n;Ny=ny/n;
nmaxbasis=10;gs=0;q0=1;eigvalue_tol=10;tol=10^(-5);regvalue=10^(-18);
poission_ratio=0.149999;
[xe,ye]=meshgrid(hx/2:hx:Lx,hy/2:hy:Ly);
young_modulus=sin(5*pi*xe).*sin(5*pi*ye)+5;
% young_modulus=5*ones(ny,nx);
c1=poission_ratio/((1+poission_ratio)*(1-2*poission_ratio));
c2=1/2/(1+poission_ratio);
% c1=1;c2=1;
lambda=c1*young_modulus;
mu=c2*young_modulus;
lambda=lambda(:);mu=mu(:);


% s=lambda(1,1);t=mu(1,1);
lambda_bar=-lambda./(4*mu.*(lambda+mu));
mu_bar=1/2./(mu);
lambdabar_mubar=lambda_bar+mu_bar;
ratio=max(young_modulus(:))/min(young_modulus(:));
fprintf('contrast is %2.1e\n',ratio );
fprintf('nx is %d\n',nx);
%% (As,s) matrix
localA12=zeros(16,16);
localA12(1,10)=1;localA12(3,12)=1;localA12(5,14)=1;localA12(7,16)=1;
localA12(10,1)=1;localA12(12,3)=1;localA12(14,5)=1;localA12(16,7)=1;
localA11a=zeros(16,16);localA11b=zeros(16,16);localA22a=zeros(16,16);localA22b=zeros(16,16);

for i=1:2:7;localA11a(i,i)=1;end
for i=[9,11,13,15];localA11b(i,i)=1;end
for i=2:2:8;localA22a(i,i)=1;end
for i=[10,12,14,16];localA22b(i,i)=1;end
tic
[Aaug1,D,ir1,ic1,nodedof,~,nodedge,dofx1,dofx2,dofy1,dofy2]=assemble2d_matrix_partb(nx,ny,hx,hy,mu_bar);
[invAss,Ass]=assemble2d_matrix_parta(nx,ny,hx,hy,lambda,mu,localA12,localA11a,localA11b,localA22a,localA22b,ir1,ic1,nodedof);
toc

%% force
u1_exact=@(x,y) (x.^3.*y.^4+x.^2+sin( (x-1).*(y-1)).*cos(y-1) );
u2_exact=@(x,y) ( -(x-1).^4.*(y-1).^3+(y-1).^2+cos(x.*y).*sin(x) );
ue1=u1_exact(xe(:),ye(:));
ue2=u2_exact(xe(:),ye(:));

cigma_11_fa=@(x,y) (lambda+2*mu).*du1dx+lambda.*du2dy;
cigma_12_fa=@(x,y) mu*(du1dy+du2dx);
cigma_22_fa=@(x,y) (lambda+2*mu).*du2dy+lambda.*du1dx;
cigma_21_fa=cigma_12_fa;
% lambda=c1*(sin(5*pi*xe).*sin(5*pi*ye)+5);
% mu=c2*(sin(5*pi*xe).*sin(5*pi*ye)+5);
du1dx=@(x,y) 3*x.^2.*y.^4+2.*x+(y-1).*cos((x-1).*(y-1)).*cos(y-1);
du1dy=@(x,y) x.^3.*y.^3*4+(x-1).*cos( (x-1).*(y-1)).*cos(y-1)-sin( (x-1).*(y-1)).*sin(y-1) ;
du2dx=@(x,y) -4*(x-1).^3.*(y-1).^3-y.*sin(x.*y).*sin(x)+cos(x.*y).*cos(x);
du2dy=@(x,y) -(x-1).^4.*3.*(y-1).^2+2*(y-1)-x.*sin(x.*y).*sin(x);

cigma_11_f=@(x,y) (c1+2*c2).*(sin(5*pi*x).*sin(5*pi*y)+5).*( 3*x.^2.*y.^4+2.*x+(y-1).*cos((x-1).*(y-1)).*cos(y-1) )+...
                  c1.*(sin(5*pi*x).*sin(5*pi*y)+5).*(-(x-1).^4.*3.*(y-1).^2+2*(y-1)-x.*sin(x.*y).*sin(x));

cigma_12_f=@(x,y) c2.*(sin(5*pi*x).*sin(5*pi*y)+5).*(x.^3.*y.^3*4+(x-1).*cos( (x-1).*(y-1)).*cos(y-1)-sin( (x-1).*(y-1)).*sin(y-1)-...
                    4*(x-1).^3.*(y-1).^3-y.*sin(x.*y).*sin(x)+cos(x.*y).*cos(x));

cigma_22_f=@(x,y) (c1+2*c2).*(sin(5*pi*x).*sin(5*pi*y)+5).*(-(x-1).^4.*3.*(y-1).^2+2*(y-1)-x.*sin(x.*y).*sin(x))+...
                  (c1).*(sin(5*pi*x).*sin(5*pi*y)+5).*(3*x.^2.*y.^4+2.*x+(y-1).*cos((x-1).*(y-1)).*cos(y-1));
cigma_21_f=cigma_12_f;
% f1=d cigma_11_f/dx+d cigma_12_f/dy;
% f2=d cigma_12_f/dx+d cigma_22_f/dy;

f1=@(x,y) (c1+2*c2).*(5*pi*cos(5*pi*x).*sin(5*pi*y)).*( 3*x.^2.*y.^4+2.*x+(y-1).*cos((x-1).*(y-1)).*cos(y-1) )+...   %%dx
           (c1+2*c2).*(sin(5*pi*x).*sin(5*pi*y)+5).*( 6*x.^1.*y.^4+2-(y-1).^2.*sin((x-1).*(y-1)).*cos(y-1) )+...
    c1.*(5*pi*cos(5*pi*x).*sin(5*pi*y)).*(-(x-1).^4.*3.*(y-1).^2+2*(y-1)-x.*sin(x.*y).*sin(x))+...
    c1.*(sin(5*pi*x).*sin(5*pi*y)+5).*(-4*(x-1).^3.*3.*(y-1).^2-sin(x.*y).*sin(x)-x.*(y.*cos(x.*y).*sin(x)+sin(x.*y).*cos(x) ))+.... 
          c2.*(sin(5*pi*x).*5*pi.*cos(5*pi*y)).*( x.^3.*y.^3.*4+(x-1).*cos( (x-1).*(y-1)).*cos(y-1)-sin( (x-1).*(y-1)).*sin(y-1)-... %%dy
                    4*(x-1).^3.*(y-1).^3-y.*sin(x.*y).*sin(x)+cos(x.*y).*cos(x) ) +....
         c2.*(sin(5*pi*x).*sin(5*pi*y)+5).*( x.^3.*y.^2*4*3-(x-1).*cos( (x-1).*(y-1)).*sin(y-1)-(x-1).^2.*sin( (x-1).*(y-1)).*cos(y-1)...
         -sin( (x-1).*(y-1)).*cos(y-1)-(x-1).*cos( (x-1).*(y-1)).*sin(y-1)-4*(x-1).^3.*(y-1).^2*3-1.*sin(x.*y).*sin(x)-x.*y.*cos(x.*y).*sin(x)+...
         -x.*sin(x.*y).*cos(x) ) ;
f2=@(x,y) c2.*(5*pi*cos(5*pi*x).*sin(5*pi*y)).*(x.^3.*y.^3*4+(x-1).*cos( (x-1).*(y-1)).*cos(y-1)-sin( (x-1).*(y-1)).*sin(y-1)-... %%dx
                    4*(x-1).^3.*(y-1).^3-y.*sin(x.*y).*sin(x)+cos(x.*y).*cos(x))+...
          c2.*(sin(5*pi*x).*sin(5*pi*y)+5).*(3*x.^2.*y.^3*4+(1).*cos( (x-1).*(y-1)).*cos(y-1)-(x-1).*(y-1).*sin( (x-1).*(y-1)).*cos(y-1)-...
          (y-1).*cos( (x-1).*(y-1)).*sin(y-1)-12*(x-1).^2.*(y-1).^3-y.*y.*cos(x.*y).*sin(x)-y.*sin(x.*y).*cos(x)-...
          y.*sin(x.*y).*cos(x)-cos(x.*y).*sin(x))+...       
          (c1+2*c2).*(5*pi*sin(5*pi*x).*cos(5*pi*y)).*(-(x-1).^4.*3.*(y-1).^2+2*(y-1)-x.*sin(x.*y).*sin(x))+... %%dy
          (c1+2*c2).*(sin(5*pi*x).*sin(5*pi*y)+5).*(-(x-1).^4.*3.*(y-1).^1*2+2*(1)-x.*x.*cos(x.*y).*sin(x))+...
          (c1).*(5*pi*sin(5*pi*x).*cos(5*pi*y)).*(3*x.^2.*y.^4+2.*x+(y-1).*cos((x-1).*(y-1)).*cos(y-1))+...
          (c1).*(sin(5*pi*x).*sin(5*pi*y)+5).*(3*x.^2.*y.^3*4+cos((x-1).*(y-1)).*cos(y-1)+(y-1).*(-cos((x-1).*(y-1)).*sin(y-1)-...
          (x-1).*sin((x-1).*(y-1)).*cos(y-1) ));



c11e=cigma_11_f(xe(:),ye(:));
c12e=cigma_12_f(xe(:),ye(:));
c22e=cigma_22_f(xe(:),ye(:));

F1=f1(xe(:),ye(:));
F2=f2(xe(:),ye(:));
F=zeros(2*ne+2*nvdof+np,1);

%%%% diri for u1
ya=(2*hy/4:hy:1);yb=(2*hy/4:hy:1);x=zeros(1,ny);
F(dofx1(1:2:end,1))=-u1_exact(x,ya)*hy/2;F(dofx1(2:2:end,1))=-u1_exact(x,yb)*hy/2;%%% u1,x=0,
ya=(2*hy/4:hy:1);yb=(2*hy/4:hy:1);x=ones(1,ny);
F(dofx2(1:2:end,1))=u1_exact(x,ya)*hy/2;F(dofx2(2:2:end,1))=u1_exact(x,yb)*hy/2;%%% u1,x=1,%%
xa=(2*hx/4:hx:1);xb=(2*hx/4:hx:1);y=zeros(1,nx);
F(dofy1(1:2:end,1))=-u1_exact(xa,y)*hx/2;F(dofy1(2:2:end,1))=-u1_exact(xb,y)*hx/2;%%% u1,y=0,%%
xa=(2*hx/4:hx:1);xb=(2*hx/4:hx:1);y=ones(1,nx);
F(dofy2(1:2:end,1))=u1_exact(xa,y)*hx/2;F(dofy2(2:2:end,1))=u1_exact(xb,y)*hx/2;%%% u1,y=1,


%%%% diri for u2
ya=(2*hy/4:hy:1);yb=(2*hy/4:hy:1);x=zeros(1,ny);
F(dofx1(1:2:end,2))=-u2_exact(x,ya)*hy/2;F(dofx1(2:2:end,2))=-u2_exact(x,yb)*hy/2;%%% u2,x=0,
ya=(2*hy/4:hy:1);yb=(2*hy/4:hy:1);x=ones(1,ny);
F(dofx2(1:2:end,2))=u2_exact(x,ya)*hy/2;F(dofx2(2:2:end,2))=u2_exact(x,yb)*hy/2;%%% u2,x=1,%%
xa=(2*hx/4:hx:1);xb=(2*hx/4:hx:1);y=zeros(1,nx);
F(dofy1(1:2:end,2))=-u2_exact(xa,y)*hx/2;F(dofy1(2:2:end,2))=-u2_exact(xb,y)*hx/2;%%% u2,y=0,%%
xa=(2*hx/4:hx:1);xb=(2*hx/4:hx:1);y=ones(1,nx);
F(dofy2(1:2:end,2))=u2_exact(xa,y)*hx/2;F(dofy2(2:2:end,2))=u2_exact(xb,y)*hx/2;%%% u2,y=1,

F(2*nvdof+1+np:2*nvdof+2*ne+np)=[F1;1*F2]*vol;

[Aeli,Feli]=eli_matrix(invAss,Aaug1,D,F);
invArr=sparse(1:np,1:np,1./diag(Aeli(1:np,1:np)));D=Aeli(np+1:end,np+1:end); Aaug=Aeli(1:np,np+1:end);
[Aeli0,Feli0,u0,uf0]=eli(invArr,Aaug,D,Feli);

uf=zeros(2*nvdof+2*ne+np,1);uf(2*nvdof+1:end)=uf0;uf(1:2*nvdof)=invAss*(F(1:2*nvdof)-Aaug1*uf0);
u=uf;

% A=[Ass,Aaug1;
%     Aaug1',zeros(np+2*ne,np+2*ne)];
% u=A\F;
%% displacement
ua=sqrt(u0(1:ne).^2+u0(1+ne:2*ne).^2);
ue=sqrt(ue1.^2+ue2.^2);
% rnorm(ua,ue);
% rnorm(u0(1+ne:2*ne),ue2);
imagescsquare1(ua);title('app norm u')
% imagescsquare1(ue);title('exact norm u')
% imagescsquare1(ua-ue);title('diff norm u')
fprintf('relative error of displacement is %2.4e\n', norm(ue-ua)/norm(ue));
%% stress
s11e=zeros(ne,1);s11a=zeros(ne,1);s12e=zeros(ne,1);s12a=zeros(ne,1);
s21e=zeros(ne,1);s21a=zeros(ne,1);s22e=zeros(ne,1);s22a=zeros(ne,1);
id=1;
for i=1:nx
    for j=1:ny
localsdof=nodedge(:,id);
locals=u(localsdof);
y1=(j-1)*hy+hy/4;x1=(i-1)*hx+hx/4;
y2=(j-1)*hy+3*hy/4;x2=x1;
y3=y1;x3=(i-1)*hx+3*hx/4;
y4=y2;x4=x3;

s11e(id)=(cigma_11_f(x1,y1)+cigma_11_f(x2,y2)+cigma_11_f(x3,y3)+cigma_11_f(x4,y4))/4;s11a(id)=(locals(1)+locals(3)+locals(5)+locals(7))/4;
s12e(id)=(cigma_12_f(x1,y1)+cigma_12_f(x2,y2)+cigma_12_f(x3,y3)+cigma_12_f(x4,y4))/4;s12a(id)=(locals(9)+locals(13)+locals(11)+locals(15))/4;
s21e(id)=(cigma_21_f(x1,y1)+cigma_21_f(x2,y2)+cigma_21_f(x3,y3)+cigma_21_f(x4,y4))/4;s21a(id)=(locals(2)+locals(4)+locals(6)+locals(8))/4;
s22e(id)=(cigma_22_f(x1,y1)+cigma_22_f(x2,y2)+cigma_22_f(x3,y3)+cigma_22_f(x4,y4))/4;s22a(id)=(locals(10)+locals(14)+locals(12)+locals(16))/4;



        id=id+1;
    end
end
s11a=s11a(:);s12a=s12a(:);s21a=s21a(:);s22a=s22a(:);s11e=s11e(:);s12e=s12e(:);s21e=s21e(:);s22e=s22e(:);

se=sqrt(s11e.^2+s12e.^2+s21e.^2+s22e.^2);sa=sqrt(s11a.^2+s12a.^2+s21a.^2+s22a.^2);
s11e2=cigma_11_f( xe,ye);s12e2=cigma_12_f( xe,ye);
s21e2=cigma_21_f( xe,ye);s22e2=cigma_22_f( xe,ye);
se2=sqrt(s11e2.^2+s12e2.^2+s21e2.^2+s22e2.^2);se2=se2(:);
diff1=se-sa;diff2=se2-sa;
% fprintf('ave vs ave, relative error and error of stress are %2.4e %2.4e\n',norm(diff1)/norm(se),sqrt(sum(diff1.^2)*vol) );
fprintf('ave vs center, relative error and error of stress are %2.4e %2.4e\n',norm(diff2)/norm(se2),sqrt(sum(diff2.^2)*vol) );
% imagescsquare1(sa);title('app norm stress')
% imagescsquare1(se);title('exact norm stress')

%% full stress
s11e=zeros(2*ny,2*nx);s11a=zeros(2*ny,2*nx);s12e=zeros(2*ny,2*nx);s12a=zeros(2*ny,2*nx);s21e=zeros(2*ny,2*nx);s21a=zeros(2*ny,2*nx);s22e=zeros(2*ny,2*nx);s22a=zeros(2*ny,2*nx);
id=1;
for i=1:nx
    for j=1:ny
localsdof=nodedge(:,id);
locals=u(localsdof);
y1=(j-1)*hy+hy/4;x1=(i-1)*hx+hx/4;
y2=(j-1)*hy+3*hy/4;x2=x1;
y3=y1;x3=(i-1)*hx+3*hx/4;
y4=y2;x4=x3;

s11e(id)=(cigma_11_f(x1,y1)+cigma_11_f(x2,y2)+cigma_11_f(x3,y3)+cigma_11_f(x4,y4))/4;s11a(id)=(locals(1)+locals(3)+locals(5)+locals(7))/4;
s12e(id)=(cigma_12_f(x1,y1)+cigma_12_f(x2,y2)+cigma_12_f(x3,y3)+cigma_12_f(x4,y4))/4;s12a(id)=(locals(9)+locals(13)+locals(11)+locals(15))/4;
s21e(id)=(cigma_21_f(x1,y1)+cigma_21_f(x2,y2)+cigma_21_f(x3,y3)+cigma_21_f(x4,y4))/4;s21a(id)=(locals(2)+locals(4)+locals(6)+locals(8))/4;
s22e(id)=(cigma_22_f(x1,y1)+cigma_22_f(x2,y2)+cigma_22_f(x3,y3)+cigma_22_f(x4,y4))/4;s22a(id)=(locals(10)+locals(14)+locals(12)+locals(16))/4;

s11e( j*2-1:j*2,i*2-1:i*2)=[cigma_11_f(x1,y1),cigma_11_f(x3,y3);cigma_11_f(x2,y2),cigma_11_f(x4,y4)];
s12e( j*2-1:j*2,i*2-1:i*2)=[cigma_12_f(x1,y1),cigma_12_f(x3,y3);cigma_12_f(x2,y2),cigma_12_f(x4,y4)];
s21e( j*2-1:j*2,i*2-1:i*2)=[cigma_21_f(x1,y1),cigma_21_f(x3,y3);cigma_21_f(x2,y2),cigma_21_f(x4,y4)];
s22e( j*2-1:j*2,i*2-1:i*2)=[cigma_22_f(x1,y1),cigma_22_f(x3,y3);cigma_22_f(x2,y2),cigma_22_f(x4,y4)];
s11a( j*2-1:j*2,i*2-1:i*2)=[locals(1),locals(3);locals(5),locals(7)];
s12a( j*2-1:j*2,i*2-1:i*2)=[locals(9),locals(13);locals(11),locals(15)];
s21a( j*2-1:j*2,i*2-1:i*2)=[locals(2),locals(4);locals(6),locals(8)];
s22a( j*2-1:j*2,i*2-1:i*2)=[locals(10),locals(14);locals(12),locals(16)];

        id=id+1;
    end
end
s11a=s11a(:);s12a=s12a(:);s21a=s21a(:);s22a=s22a(:);s11e=s11e(:);s12e=s12e(:);s21e=s21e(:);s22e=s22e(:);

se=sqrt(s11e.^2+s12e.^2+s21e.^2+s22e.^2);sa=sqrt(s11a.^2+s12a.^2+s21a.^2+s22a.^2);
s11e2=cigma_11_f( xe,ye);s12e2=cigma_12_f( xe,ye);
s21e2=cigma_21_f( xe,ye);s22e2=cigma_22_f( xe,ye);
se2=sqrt(s11e2.^2+s12e2.^2+s21e2.^2+s22e2.^2);se2=se2(:);
diff1=se-sa;
fprintf('full relative error and error of stress are %2.4e %2.4e\n',norm(diff1)/norm(se),sqrt(sum(diff1.^2)*vol/4) );



%% rotation
[xp,yp]=meshgrid(0:hx:Lx,0:hy:Ly);xp=xp(:);yp=yp(:);
rota=u(nvdof*2+1:nvdof*2+np);
rota=reshape(rota,ny+1,nx+1);
rota=rota(1:end-1,1:end-1)+rota(2:end,1:end-1)+rota(1:end-1,2:end)+rota(2:end,2:end);rota=rota(:)/4;
rote=du2dx(xe,ye)-du1dy(xe,ye);rote=rote(:)/2;
rota=rota.*mu_bar;
% rote=rote./mu_bar;

fprintf('relative error and error of rotation are %2.4e %2.4e\n',norm(rote-rota)/norm(rote),sqrt(sum((rote-rota).^2)*vol) );
imagescsquare1(rota);title('app norm rot')
imagescsquare1(rote);title('exact norm rot')

