function [Urecord]=onlinewaveabc(AA2,AA1,FF1,ft,step,snapshot,dt,nprint)
fprintf('wave marching.... \n');
U1=zeros(size(AA2,1),1);
U2=U1;
% sei=zeros(size(true_receiver,1),step);
% tic
 for k=1:step  
     if mod(step-k,floor(step/nprint))==0
        fprintf('rest step is %d\n', step-k);
     end
     U3=AA2*U2-AA1*U1+FF1*ft(k+1);
     U1=U2; U2=U3;
 
      if k==floor(snapshot/dt)
      Urecord=U3; % % record the steps we need 
      end
%       sei(:,k+1)=U3(true_receiver,:);
     
       
end 
% toc


return
