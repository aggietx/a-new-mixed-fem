%%% ex 3 in yotov's paper, heterogeneous media, scaled rotation
%%% no stress elimination
clear;
close all
errcase=1;%%%% 1:average or 2 (switch for genrated full error or mean error of stress)
nx=3*2^3;%%%% must be divided by 3
ny=nx;ne=nx*ny;nvet=2*ny*(nx+1);nhor=2*nx*(ny+1);nvdof=nvet+nhor;nedge=ny*(nx+1)+nx*(ny+1);
Lx=1;Ly=1;hx=Lx/nx;hy=Ly/ny;vol=hx*hy;np=(nx+1)*(ny+1);
[nodv,dofx1,dofx2,dofy1,dofy2]=local2globaldof(nx,ny);nodv2=[nodv;nodv+2*nedge];
chi=zeros(ny,nx);
chi(ny/3+1:2*ny/3,nx/3+1:2*nx/3)=1;
maxval=1*10^6;
lambda=(1-chi)+maxval*chi;
mu=lambda;
lambda=lambda(:);mu=mu(:);

s=lambda(1,1);t=mu(1,1);
lambda_bar=-lambda./(4*mu.*(lambda+mu));
mu_bar=1/2./(mu);
lambdabar_mubar=lambda_bar+mu_bar;

Ass11=sparse(nodv,nodv,[ones(4,1)*lambdabar_mubar';ones(4,1)*mu_bar'])*vol/4;
Ass22=sparse(nodv,nodv,[ones(4,1)*mu_bar';ones(4,1)*lambdabar_mubar'])*vol/4;
ir1=zeros(16^2,ne);
ic1=zeros(16^2,ne);
localA12=zeros(16,16);
localA12(1,5+8)=-1;localA12(2,6+8)=1;localA12(3,7+8)=1;localA12(4,8+8)=-1;
localA12(5+8,1)=-1;localA12(6+8,2)=1;localA12(7+8,3)=1;localA12(8+8,4)=-1;
id=1;
for i=1:nx
    for j=1:ny
localedof=[nodv(:,id);nodv(:,id)+nvdof];  ir1(:,id)=repmat(localedof,16,1);
temp=repmat(localedof,1,16);temp=temp';ic1(:,id)=temp(:);
id=id+1;
    end
end
Ass=[1*Ass11,sparse(nedge*2,nedge*2);
    sparse(nedge*2,nedge*2), 1*Ass22]+sparse(ir1,ic1,localA12(:)*lambda_bar'*vol/4);


%%
localsp=[-1,1,1,-1,1,-1,-1,1]'*hx/2;
ivalue=repmat(localsp,1,ne);
ix=repmat(1:ne,8,1);
Asp0=sparse(nodv,ix,ivalue);clear ivalue ix 
Asp=[Asp0,sparse(2*nedge,ne);
    sparse(2*nedge,ne),Asp0];

%% 
localsr=zeros(16,4);
localsr(5,1)=1;localsr(6,2)=1;localsr(7,3)=-1;localsr(8,4)=-1;
localsr(9,1)=1;localsr(10,2)=-1;localsr(11,3)=1;localsr(12,4)=-1;
alllocalsr=zeros(16*4,ne);
allpdof=reshape(1:(nx+1)*(ny+1),ny+1,nx+1);
ir=zeros(16*4,ne);
ic=zeros(16*4,ne);
id=1;
for i=1:nx
    for j=1:ny

alllocalsr(:,id)=localsr(:)*mu_bar(id);
        
localedof=[nodv(:,id);nodv(:,id)+nvdof];  ir(:,id)=repmat(localedof,4,1);
localpdof=allpdof(j:j+1,i:i+1);localpdof=localpdof(:);temp=repmat(localpdof,1,16);temp=temp';ic(:,id)=temp(:);

id=id+1;
    end
end
Ars=sparse(ir,ic,repmat(localsr(:),1,ne).*(mu_bar*ones(1,64))'*vol/4);
A=[Ass, Asp,Ars;
   -Asp',sparse(2*ne,2*ne+np);
   Ars',sparse(np,2*ne+np)];
[xe,ye]=meshgrid(hx/2:hx:Lx-hx/2,hy/2:hy:Ly-hy/2);
u1_exact_f=@(x,y,chi) 1./( (1-chi)+maxval*chi).*sin(3*pi*x).*sin(3*pi*y);ue1=u1_exact_f(xe(:),ye(:),chi(:));
u2_exact_f=@(x,y,chi) 1./( (1-chi)+maxval*chi).*sin(3*pi*x).*sin(3*pi*y);ue2=u2_exact_f(xe(:),ye(:),chi(:));

cigma_11_f=@(x,y,s,t) 1./s.*(3*pi*(s+2*t).*cos(3*pi*x).*sin(3*pi*y)+3*pi*s.*sin(3*pi*x).*cos(3*pi*y));
cigma_12_f=@(x,y,s,t) 1./s.*(pi*3*t.*cos(3*pi*y).*sin(3*pi*x)+3*pi*t.*sin(3*pi*y).*cos(3*pi*x));
cigma_22_f=@(x,y,s,t) 1./s.*(3*pi*(s+2*t).*sin(3*pi*x).*cos(3*pi*y)+3*pi*s.*cos(3*pi*x).*sin(3*pi*y));
cigma_21_f=cigma_12_f;
% return
f1 =@(x,y,s,t) 1./s.*(-(9*(s+t).*pi^2.*cos(3*pi*x).*cos(3*pi*y)-9*(s+3*t).*pi^2.*sin(3*pi*x).*sin(3*pi*y)));
F1=f1(xe(:),ye(:),lambda(:),mu(:));
F=zeros(2*ne+2*nvdof+np,1);
F(2*nvdof+1:2*nvdof+2*ne)=[F1;1*F1]*vol;

u=A\F;
int_u1exactx=@(x,y)-1/(3*pi).*cos(3*pi*y);
int_u1exacty=@(x,y)-1/(3*pi).*cos(3*pi*x);
% imagescsquare1(ue1);title('exact u1');imagescsquare1(u(2*nvdof+1:2*nvdof+ne));title('app u1');
% imagescsquare1(ue2);title('exact u2');imagescsquare1(u(2*nvdof+1+ne:2*nvdof+2*ne));title('app u2');
ua1=u(2*nvdof+1:2*nvdof+ne);
ua2=u(2*nvdof+1+ne:2*nvdof+2*ne);
rnorm(sqrt(ua1.^2+ua2.^2),sqrt(ue1.^2+ue2.^2));
% imagescsquare1(sqrt(ue1.^2+ue2.^2));title('exact norm u');
% imagescsquare1(sqrt(ua1.^2+ua2.^2));title('app norm u');
% fprintf('error is %2.6f %2.3e\n',sum(abs(ua1-ue1)*vol),sum(abs(ua1-ue1)*vol));
% fprintf('error is %2.6f %2.3e\n',sum(abs(ua2-ue2)*vol),sum(abs(ua2-ue2)*vol));
%fprintf('size is %d\n',nx)
% sum(abs(ue1-ua1))*vol 
diff=sqrt(ua1.^2+ua2.^2)-sqrt(ue1.^2+ue2.^2);
exact=sqrt(ue1.^2+ue2.^2);
Mass=vol*speye(ne);
err=sqrt(diff'*Mass*diff);
rerr=sqrt(diff'*Mass*diff)/sqrt(exact'*Mass*exact);
fprintf('size is %d\n',nx)
fprintf('relative error and error of displacement are %2.4e %2.4e\n',norm(diff)/norm(exact),sqrt(sum(diff.^2)*vol) );

% imagescsquare(u(2*nvdof+1+ne:2*nvdof+2*ne))
if errcase==1
s11e=zeros(ne,1);s11a=zeros(ne,1);s12e=zeros(ne,1);s12a=zeros(ne,1);s21e=zeros(ne,1);s21a=zeros(ne,1);s22e=zeros(ne,1);s22a=zeros(ne,1);
else
s11e=zeros(2*ny,2*nx);s11a=zeros(2*ny,2*nx);s12e=zeros(2*ny,2*nx);s12a=zeros(2*ny,2*nx);s21e=zeros(2*ny,2*nx);s21a=zeros(2*ny,2*nx);s22e=zeros(2*ny,2*nx);s22a=zeros(2*ny,2*nx);
end
a=zeros(ne,1);
Pu1e=zeros(ne,1);
id=1;
for i=1:nx
    for j=1:ny
localsdof=[nodv(:,id);nodv(:,id)+nvdof];
locals=u(localsdof);
y1=(j-1)*hy+hy/4;x1=(i-1)*hx+hx/4;
y2=(j-1)*hy+3*hy/4;x2=x1;
y3=y1;x3=(i-1)*hx+3*hx/4;
y4=y2;x4=x3;
if errcase==1 %% average
s11e(id)=(cigma_11_f(x1,y1,lambda(id),mu(id))+cigma_11_f(x2,y2,lambda(id),mu(id))+cigma_11_f(x3,y3,lambda(id),mu(id))+cigma_11_f(x4,y4,lambda(id),mu(id)))/4;s11a(id)=(locals(1)-locals(2)+locals(3)-locals(4))/4;
s12e(id)=(cigma_12_f(x1,y1,lambda(id),mu(id))+cigma_12_f(x2,y2,lambda(id),mu(id))+cigma_12_f(x3,y3,lambda(id),mu(id))+cigma_12_f(x4,y4,lambda(id),mu(id)))/4;
s12a(id)=(-locals(5)-locals(6)+locals(7)+locals(8))/4;
% s12e(id)= harmmean ( [cigma_12_f(x1,y1,lambda(id),mu(id)),cigma_12_f(x2,y2,lambda(id),mu(id)),cigma_12_f(x3,y3,lambda(id),mu(id)),cigma_12_f(x4,y4,lambda(id),mu(id))] );
% s12a(id)= harmmean([-locals(5),-locals(6),locals(7),locals(8)]);
s21e(id)=(cigma_21_f(x1,y1,lambda(id),mu(id))+cigma_21_f(x2,y2,lambda(id),mu(id))+cigma_21_f(x3,y3,lambda(id),mu(id))+cigma_21_f(x4,y4,lambda(id),mu(id)))/4;s21a(id)=(locals(9)-locals(10)+locals(11)-locals(12))/4;
s22e(id)=(cigma_22_f(x1,y1,lambda(id),mu(id))+cigma_22_f(x2,y2,lambda(id),mu(id))+cigma_22_f(x3,y3,lambda(id),mu(id))+cigma_22_f(x4,y4,lambda(id),mu(id)))/4;s22a(id)=(-locals(13)-locals(14)+locals(15)+locals(16))/4;

% disp('............')
% fprintf('exact %2.3f %2.3f %2.3f %2.3f\n',cigma_11_f(x1,y1,lambda(id),mu(id)),cigma_11_f(x2,y2,lambda(id),mu(id)),cigma_11_f(x3,y3,lambda(id),mu(id)),cigma_11_f(x4,y4,lambda(id),mu(id)) );
% fprintf('app %2.3f %2.3f %2.3f %2.3f\n',locals(1), -locals(2),locals(3),-locals(4));
% % % % fprintf('app %2.3f %2.3f %2.3f %2.3f\n',-locals(1), -locals(1),locals(7),locals(8));
% fprintf('exact %2.3f %2.3f %2.3f %2.3f\n',cigma_12_f(x1,y1,lambda(id),mu(id)),cigma_12_f(x2,y2,lambda(id),mu(id)),cigma_12_f(x3,y3,lambda(id),mu(id)),cigma_12_f(x4,y4,lambda(id),mu(id)) );
% fprintf('app %2.3f %2.3f %2.3f %2.3f\n',-locals(5), -locals(6),locals(7),locals(8));
else
s11e( j*2-1:j*2,i*2-1:i*2)=[cigma_11_f(x1,y1,lambda(id),mu(id)),cigma_11_f(x3,y3,lambda(id),mu(id));cigma_11_f(x2,y2,lambda(id),mu(id)),cigma_11_f(x4,y4,lambda(id),mu(id))];
s12e( j*2-1:j*2,i*2-1:i*2)=[cigma_12_f(x1,y1,lambda(id),mu(id)),cigma_12_f(x3,y3,lambda(id),mu(id));cigma_12_f(x2,y2,lambda(id),mu(id)),cigma_12_f(x4,y4,lambda(id),mu(id))];
s21e( j*2-1:j*2,i*2-1:i*2)=[cigma_21_f(x1,y1,lambda(id),mu(id)),cigma_21_f(x3,y3,lambda(id),mu(id));cigma_21_f(x2,y2,lambda(id),mu(id)),cigma_21_f(x4,y4,lambda(id),mu(id))];
s22e( j*2-1:j*2,i*2-1:i*2)=[cigma_22_f(x1,y1,lambda(id),mu(id)),cigma_22_f(x3,y3,lambda(id),mu(id));cigma_22_f(x2,y2,lambda(id),mu(id)),cigma_22_f(x4,y4,lambda(id),mu(id))];
s11a( j*2-1:j*2,i*2-1:i*2)=[locals(1),locals(3);-locals(2),-locals(4)];
s12a( j*2-1:j*2,i*2-1:i*2)=[-locals(5),locals(7);-locals(6),locals(8)];
s21a( j*2-1:j*2,i*2-1:i*2)=[locals(9),locals(11);-locals(10),-locals(12)];
s22a( j*2-1:j*2,i*2-1:i*2)=[-locals(13),locals(15);-locals(14),locals(16)];
end
% Pu1e(id)=(int_u1exactx(x1,j*hy)-int_u1exactx(x1,(j-1)*hy))*(int_u1exacty(i*hx,y1)-int_u1exacty((i-1)*hx,y1))/vol/lambda(id);
% a(id)=-locals(6);

        id=id+1;
    end
end
s11a=s11a(:);s12a=s12a(:);s21a=s21a(:);s22a=s22a(:);s11e=s11e(:);s12e=s12e(:);s21e=s21e(:);s22e=s22e(:);

se=sqrt(s11e.^2+s12e.^2+s21e.^2+s22e.^2);sa=sqrt(s11a.^2+s12a.^2+s21a.^2+s22a.^2);
[xec,yec]=meshgrid(hx/2:hx:Lx-hx/2,hy/2:hy:Ly-hy/2);
xec=xec(:);yec=yec(:);
s11e2=cigma_11_f( xec,yec,lambda,mu);s12e2=cigma_12_f( xec,yec,lambda,mu);
s21e2=cigma_21_f( xec,yec,lambda,mu);s22e2=cigma_22_f( xec,yec,lambda,mu);
se2=sqrt(s11e2.^2+s12e2.^2+s21e2.^2+s22e2.^2);se2=se2(:);
diff1=se-sa;
if errcase==1
    diff2=se2-sa;
%fprintf('ave vs ave, relative error and error of stress are %2.4e %2.4e\n',norm(diff1)/norm(se),sqrt(sum(diff1.^2)*vol) );
fprintf('ave vs center, relative error and error of stress are %2.4e %2.4e\n',norm(diff2)/norm(se2),sqrt(sum(diff2.^2)*vol) );
% norm(s11a-s11e)
% norm(s12a-s12e)
% norm(s21a-s21e)
% norm(s22a-s22e)
else
fprintf('relative error and error of stress are %2.4e %2.4e\n',norm(diff1)/norm(se),sqrt(sum(diff1.^2)*vol/4) );

end

% meshsquare(a)
% imagescsquare1(ua1)
% imagescsquare1(Pu1e)
% rnorm(ua1,Pu1e);
% rnorm(s11a,s11e);
% rnorm(s12a,s12e);

% rnorm(1./lambda.*s12a,1./lambda.*s12e);
% rnorm(lambda.*s12a,lambda.*s12e);
% rnorm(s21a,s21e);
% rnorm(s22a,s22e);

% rnorm(sqrt(s11a.^2+s12a.^2),sqrt(s11e.^2+s12e.^2));
% imagescsquare1(sqrt(s11e.^2+s12e.^2));title('exact x component of stress');
% imagescsquare1(sqrt(s11a.^2+s12a.^2));title('app x component of stress');

rota=u(end-np+1:end);
rota=reshape(rota,ny+1,nx+1);
rota=rota(1:end-1,1:end-1)+rota(2:end,1:end-1)+rota(1:end-1,2:end)+rota(2:end,2:end);
rota=rota(:)/4;

% rote=reshape(rote,ny+1,nx+1);
% rote=rote(1:end-1,1:end-1)+rote(2:end,1:end-1)+rote(1:end-1,2:end)+rote(2:end,2:end);
% rote=rote(:)/4;
du1dy=@(x,y,chi) 3*pi*1./( (1-chi)+maxval*chi).*sin(3*pi*x).*cos(3*pi*y);
du2dx=@(x,y,chi) 3*pi*1./( (1-chi)+maxval*chi).*cos(3*pi*x).*sin(3*pi*y);
[xp,yp]=meshgrid(0:hx:Lx,0:hy:Ly);
% rote=du2dx(xp,yp,chi)-du1dy(xp,yp,chi);rote=rote(:)/2;
rote=du2dx(xe,ye,chi)-du1dy(xe,ye,chi);rote=rote(:)/2;
rota=rota.*mu_bar;
% rote=rote./mu_bar;

% rotp=du2dx(xp,yp,chi)-du1dy(xe,ye,chi);rotp=rotp(:)/2;
% chip=zeros(ny+1,nx+1);
% chip(ny/3+1:2*ny/3,nx/3+1:2*nx/3)=1;

fprintf('relative error and error of rotation are %2.4e %2.4e\n',norm(rote-rota)/norm(rote),sqrt(sum((rote-rota).^2)*vol) );

disp('...................................................................')

return
tempv=zeros(ny*nx,1);
id=1;
for i=1:nx
    for j=1:ny
localsdof=[nodv(:,id);nodv(:,id)+nvdof];
locals=u(localsdof);
y1=(j-1)*hy+hy/4;x1=(i-1)*hx+hx/4;
y2=(j-1)*hy+3*hy/4;x2=x1;
y3=y1;x3=(i-1)*hx+3*hx/4;
y4=y2;x4=x3;

tempv(id)=(-locals(5)-locals(6)+locals(7)+locals(8));
%  tempv(id)=(-locals(7));
        id=id+1;
    end
end
 % imagescsquare1(tempv)

%   imagescsquare1(1./lambda.*tempv)
% imagescsquare1(lambda.*tempv)
return
if 1
    disp('velocity elimination....')
diagAvv=fsparse(ones(size(nodv)),nodv,ones(8,1)*alpha(:)')*vol/4;diagAvv=1./diagAvv;
Aeli=-(Asp'.*diagAvv)*Asp;
F=-1*vol*ones(ne,1);
ueli=Aeli\F;
imagescsquare1(ueli)
end