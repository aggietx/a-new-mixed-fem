function rate=computerate(data)

data=data(:);

n=size(data,1);

rate=zeros(n-1,1);

for i=1:n-1
rate(i)=log2(data(i)/data(i+1));
end

fprintf('rate is %2.4f\n',rate)
disp('.......')