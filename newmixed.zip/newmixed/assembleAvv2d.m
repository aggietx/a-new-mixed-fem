function [invAvv,Avv]=assembleAvv2d(ne,invk11,invk22,invk12,nodedof,nodv,vol,np)
localA12=zeros(8,8);
localA12(1,5)=1;localA12(2,6)=1;localA12(3,7)=1;localA12(4,8)=1;
localA12(5,1)=1;localA12(6,2)=1;localA12(7,3)=1;localA12(8,4)=1;

ir1=kron(nodv,ones(1,8));ir1=reshape(ir1(:),8^2,ne);
ic1=kron(nodv,ones(8,1));

Avv=sparse(nodv,nodv,[ones(4,1)*invk11';ones(4,1)*invk22'])*vol/4+...
    sparse(ir1,ic1,localA12(:)*invk12'*vol/4);

invAvv_local=cell(np,1);
id=0;
for i=1:np
localdof=nodedof(:,i);ndof=length(find(localdof));

invAvv_local{i}=inv(Avv(id+1:id+ndof,id+1:id+ndof));
id=id+ndof;
end
invAvv=blkdiag(invAvv_local{:});