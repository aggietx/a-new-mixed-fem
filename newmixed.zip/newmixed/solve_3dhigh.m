ts=tic;
    if gs
%if twogridsolve; u0=gs_2gridsolver(Aeli0,Feli0,phimatrix_pa,'tol',tol,'initype',1,'step',nsm);end

 if twogridsolve; u0=gs_2gridsolver1(Aeli0,Feli0,phimatrix_pa,'tol',tol,'initype',1,'step',nsm);end

% % % if twogridsolve; u0=gs_2gridsolver_pcg(Aeli0,Feli0,phimatrix_pa,'tol',tol,'cgtype',1,'initype',1,'step',nsm);end

% % % if threegrid; u0=gs_ilu_3grid_solver(Aeli0,Feli0,phimatrix_pa,phimatrix_p1,'tol',tol,'initype',1);end

% if threegrid; u0=gs_gs_3grid_solver(Aeli0,Feli0,phimatrix_pa,phimatrix_p1,'tol',tol,'initype',1,'step',nsm,'step',nsm);end
%if threegrid; u0=gs_gs_3grid_solver1(Aeli0,Feli0,phimatrix_pa,phimatrix_p1,'tol',tol,'initype',1,'step',nsm,'step',nsm);end
if threegrid; u0=gs_gs_3grid_solver2(Aeli0,Feli0,phimatrix_pa,phimatrix_p1,'tol',tol,'initype',1,'step',nsm,'step',nsm);end

    else %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

% if twogridsolve;   
% u0=ilu_2grid_solver_pcg(Aeli0,Feli0,phimatrix_pa,'cgtype',0,'tol',tol,'initype',0);
    % end
if twogridsolve
    % u0=ilu_2grid_solver_pcg(Aeli0,Feli0,phimatrix_pa,'cgtype',1,'tol',tol,'initype',1);
end
    if twogridsolve 
 u0=ilu_2grid_solver1(Aeli0,Feli0,phimatrix_pa,'tol',tol,'initype',1);
    end

    if threegrid
% u0=ilu_3grid_solver_pcg0(Aeli0,Feli0,phimatrix_pa,phimatrix_p1,'cgtype',0,'initype',0,'ip1',1,'tol',tol);
% u0=ilu_3grid_solver_pcg0(Aeli0,Feli0,phimatrix_pa,phimatrix_p1,'cgtype',1,'initype',1,'ip1',1,'tol',tol);
u0=ilu_3grid_solver(Aeli0,Feli0,phimatrix_pa,phimatrix_p1,'ip1',1,'tol',tol,'initype',1);
    end

    end
if threegrid==0;t3g=0;end;%if twogridsolve;t3g=0;end
% amgcl_solver(Aeli0,Feli0,tol);
%     uc=ilu_2grid_solver1( phimatrix_pa*Aeli0*phimatrix_pa',phimatrix_pa*Feli0,phimatrix_p1,'tol',tol,'initype',0);
ts=toc(ts);