%%%% basis are the same as rt0, all vector basis are (1,0) or (0,1), no
%%%% negative, stress elimination
%%% (x,y,z)
%%%% discontinuous rotation
%%%% yotov's 3D example ,dual assemble
clear;
close all
disp('generate mesh...');
tic
nx1=16*2;nx2=nx1;nx3=nx1;nx=nx1;ny=nx2;nz=nx3;fprintf('nx is %d\n',nx);
Lx1=1;Lx2=1;Lx3=1;ne=nx1*nx2*nx3;hx1=1/nx1;hx2=1/nx2;hx3=1/nx3;vol=hx1*hx2*hx3;np=(nx1+1)*(nx2+1)*(nx3+1);
nface=(nx1+1)*nx2*nx3+(nx2+1)*nx1*nx3+(nx3+1)*nx1*nx2;nvdof=4*nface;hx=hx1;hy=hx2;hz=hx3;
[nodedge,nodv,facex1,facex2,facey1,facey2,facez1,facez2,nodedof]=local2globaldof3d_inveli_elastic(nx,ny,nz);
twogrid=0;n=8;Nx=nx/n;Ny=nz/n;Nz=nz/n;
%[phimatrix_pa]=assemble_3dphi(Nx,Ny,Nz,n,1);uur=gs_2gridsolver(Aeli,Feli,phimatrix_pa,'tol',10^(-10));

if 0
poission_ratio=0.499999;
young_modulus=1*ones(nx1,nx2,nx3);% % depends on x
lambda=poission_ratio/((1+poission_ratio)*(1-2*poission_ratio))*young_modulus;
mu=1/2/(1+poission_ratio)*young_modulus;
else
lambda=100*ones(nx,ny,nz);mu=100*ones(nx,ny,nz);
%lambda=100*randn(nx,ny,nz);mu=100*randn(nx,ny,nz);
end
lambda=lambda(:);mu=mu(:);
s=lambda(1,1);t=mu(1,1);
lambda_bar=-lambda./(2*mu.*(3*lambda+2*mu));
mu_bar=1/2./(mu);
lambdabar_mubar=lambda_bar+mu_bar;
mu_bare=zeros(nx+2,ny+2,nz+2);lambda_bare=zeros(nx+2,ny+2,nz+2);
mu_bare(2:end-1,2:end-1,2:end-1)=reshape(mu_bar,nx,ny,nz);
lambda_bare(2:end-1,2:end-1,2:end-1)=reshape(lambda_bar,nx,ny,nz);

fprintf('s is, s over t is %2.2f %2.2f\n',s,s/t);
toc
map=zeros(72,1);id1=1:3:72;id2=2:3:72;id3=3:3:72;
map(1:24)=1:3:72;map(1:24)=1:3:72;map(25:48)=2:3:72;map(49:72)=3:3:72;
%% assemble matrix
assembledual_dis;  
F=zeros(nvdof*3+3*ne+3*ne,1);
%% boundary condition
[ye,xe,ze]=meshgrid(hx/2:hx:1,hy/2:hy:1,hz/2:hz:1);%%[x,y,z]=meshgrid(0:1/5:1,0:1/4:1,0:1/3:1);
uexact1=@(x,y,z) 0;
uexact2=@(x,y,z) -(exp(x)-1).*(y-cos(pi/12).*(y-1/2)+sin(pi/12).*(z-1/2)-1/2);
uexact3=@(x,y,z) -(exp(x)-1).*(z-sin(pi/12).*(y-1/2)-cos(pi/12).*(z-1/2)-1/2);
ue2=uexact2(xe,ye,ze);ue2=ue2(:);ue3=uexact3(xe,ye,ze);ue3=ue3(:);ue1=uexact1(xe,ye,ze);ue1=ue1(:);
du1dy=@(x,y,z) 0;du1dz=@(x,y,z) 0;
du2dx=@(x,y,z) -(exp(x)).*(y-cos(pi/12).*(y-1/2)+sin(pi/12).*(z-1/2)-1/2); 
du2dy=@(x,y,z)-(exp(x)-1).*(1-cos(pi/12));
du2dz=@(x,y,z)-(exp(x)-1).*(sin(pi/12));
du3dx=@(x,y,z) -(exp(x)).*(z-sin(pi/12).*(y-1/2)-cos(pi/12).*(z-1/2)-1/2);   
du3dy=@(x,y,z)-(exp(x)-1).*(-sin(pi/12));
du3dz=@(x,y,z) -(exp(x)-1).*(1-cos(pi/12));

rote12=du2dx(xe,ye,ze)-du1dy(xe,ye,ze);rote12=rote12(:)/2;
rote13=du3dx(xe,ye,ze)-du1dz(xe,ye,ze);rote13=rote13(:)/2;
rote23=du3dy(xe,ye,ze)-du2dz(xe,ye,ze);rote23=rote23(:)/2;

cigma11a=@(x,y,z) (s+2*t)*0+s*du2dy+s*du3dz;cigma12a=@(x,y,z) t*(du2dx);cigma13a=@(x,y,z) t*(du3dx);
cigma21a=cigma12a;cigma22a=@(x,y,z) (s+2*t)*du2dy+0+s*du3dz;cigma23a=@(x,y,z) t*(du2dz+du3dy);
cigma31a=cigma13a;cigma32a=cigma23a;cigma33a=@(x,y,z) (s+2*t)*du3dz+0+s*du2dy;

cigma11=@(x,y,z) s*(-(exp(x)-1).*(1-cos(pi/12)))+s*(-(exp(x)-1).*(1-cos(pi/12)));
cigma12=@(x,y,z) t*(-(exp(x)).*(y-cos(pi/12).*(y-1/2)+sin(pi/12).*(z-1/2)-1/2));
cigma13=@(x,y,z) t*( -(exp(x)).*(z-sin(pi/12).*(y-1/2)-cos(pi/12).*(z-1/2)-1/2));
cigma21=cigma12;cigma22=@(x,y,z) (s+2*t)*(-(exp(x)-1).*(1-cos(pi/12)))+0+s*(-(exp(x)-1).*(1-cos(pi/12)));
cigma23=@(x,y,z) t*(-(exp(x)-1).*(sin(pi/12))-(exp(x)-1).*(-sin(pi/12)));
cigma31=cigma13;cigma32=cigma23;
cigma33=@(x,y,z) (s+2*t)*(-(exp(x)-1).*(1-cos(pi/12)))+0+s*(-(exp(x)-1).*(1-cos(pi/12)));

f1=@(x,y,z) s*(-(exp(x)).*(1-cos(pi/12)))+s*(-(exp(x)).*(1-cos(pi/12)))+t*(-(exp(x)).*(1-cos(pi/12)))+t*( -(exp(x)).*(1-cos(pi/12)));
f2=@(x,y,z) t*(-(exp(x)).*(y-cos(pi/12).*(y-1/2)+sin(pi/12).*(z-1/2)-1/2))+0+0;
f3=@(x,y,z) t*(-(exp(x)).*(z-sin(pi/12).*(y-1/2)-cos(pi/12).*(z-1/2)-1/2))+0+0;
F1=f1(xe,ye,ze);F2=f2(xe,ye,ze);F3=f3(xe,ye,ze);
%%%% diribd
[ze1,ye1]=meshgrid(hy/2:hy:1,hz/2:hz:1);x1a=zeros(ny,nz);x1b=ones(ny,nz);%[aa,bb]=meshgrid(0:1/5:1,0:1/4:1);
[ze2,xe2]=meshgrid(hx/2:hx:1,hz/2:hz:1);y2a=zeros(nx,nz);y2b=ones(nx,nz);
[ye3,xe3]=meshgrid(hx/2:hx:1,hy/2:hy:1);z3a=zeros(nx,ny);z3b=ones(nx,ny);
for i=1:2
    for j=1:2
F(facex1(j:2:end,i:2:end,2))=-uexact2(x1a,ye1,ze1)*hz*hy/4;%%% u2,x=0,
F(facex2(j:2:end,i:2:end,2))=uexact2(x1b,ye1,ze1)*hz*hy/4;%%% u2,x=1,
F(facey1(j:2:end,i:2:end,2))=-uexact2(xe2,y2a,ze2)*hz*hx/4;%%% u2,y=0,
F(facey2(j:2:end,i:2:end,2))=uexact2(xe2,y2b,ze2)*hz*hx/4;%%% u2,y=1,
F(facez1(j:2:end,i:2:end,2))=-uexact2(xe3,ye3,z3a)*hx*hy/4;%%% u2,z=0,
F(facez2(j:2:end,i:2:end,2))=uexact2(xe3,ye3,z3b)*hx*hy/4;%%% u2,z=1,

F(facex1(j:2:end,i:2:end,3))=-uexact3(x1a,ye1,ze1)*hz*hy/4;%%% u3,x=0,
F(facex2(j:2:end,i:2:end,3))=uexact3(x1b,ye1,ze1)*hz*hy/4;%%% u3,x=1,
F(facey1(j:2:end,i:2:end,3))=-uexact3(xe2,y2a,ze2)*hz*hx/4;%%% u3,y=0,
F(facey2(j:2:end,i:2:end,3))=uexact3(xe2,y2b,ze2)*hz*hx/4;%%% u3,y=1,
F(facez1(j:2:end,i:2:end,3))=-uexact3(xe3,ye3,z3a)*hx*hy/4;%%% u3,z=0,
F(facez2(j:2:end,i:2:end,3))=uexact3(xe3,ye3,z3b)*hx*hy/4;%%% u3,z=1,
    end
end
F(3*nvdof+3*ne+1:end)=[F1(:);F2(:);F3(:)]*vol;clear F1 F2 F3

% a=zeros(16,16);a1=rand(8,8);
% for i=1:2
%     for j=1:2
%         a(j:2:end,i:2:end)=a1;
%     end
% end
if 0
h=1/32;[ye,xe,ze]=meshgrid(h/2:h:1,h/2:h:1,h/2:h:1);
u2e=uexact2(xe,ye,ze);u3e=uexact3(xe,ye,ze);
un=sqrt(u2e.^2+u3e.^2);
imagesc3dsquare(un(:),0)
a=sqrt(cigma11(xe,ye,ze).^2+cigma12(xe,ye,ze).^2+cigma13(xe,ye,ze).^2);imagesc3dsquare(a(:),0)
b=sqrt(cigma21(xe,ye,ze).^2+cigma22(xe,ye,ze).^2+cigma23(xe,ye,ze).^2);imagesc3dsquare(b(:),0)
c=sqrt(cigma31(xe,ye,ze).^2+cigma32(xe,ye,ze).^2+cigma33(xe,ye,ze).^2);imagesc3dsquare(c(:),0)
end 

%%
if 0
    disp('solve linear system...')
% A=[Ass, Ars,Asp;
%    Ars',sparse(3*ne,3*ne+3*ne);
%    Asp',sparse(3*ne,3*ne+3*ne)];

A=[Ass, Ars+Asp;
   Ars'+Asp',sparse(6*ne,6*ne)];

tic;u=A\F;toc

else
tic
    % Aaug1=[Ars,Asp];
    Aaug1=Ars+Asp;
    D=sparse(6*ne,6*ne);
    clear ir ir1 iv11 iv22 ic1  Ars Asp  Ass  Ass11  Ass33 Ass22
[Aeli,Feli]=eli_matrix(invAss,Aaug1,D,F);
% [Aeli,Feli,u2,u]=eli(invAss,Aaug1,D,F);
 % 
 if twogrid
[phimatrix_pa]=assemble_3dphi(Nx,Ny,Nz,n,1);uur=gs_2gridsolver(Aeli,Feli,...
    phimatrix_pa,'tol',10^(-10));
 else
 uur=gs_solver(Aeli,Feli,'tol',10^(-10));
 end
% tic;uur=Aeli\Feli;toc;
% uur=ilu_solver(Aeli,Feli,10^(-10));
uu=uur(1+3*ne:3*ne+3*ne);
u=zeros(size(F));u(1+3*nvdof:end)=uur;
u(1:nvdof*3)=invAss*(F(1:3*nvdof)-Aaug1*uur);
%rnorm(uu,u(nvdof*3+1+3*ne:nvdof*3+3*ne+3*ne));
toc
end
%% 
% ua1=u(nvdof*3+1:nvdof*3+ne);
% imagesc3dsquare(ua1,1);title('approx u1')
% imagesc3dsquare(ue1(:),1);title('exact u1')
%% post
ua1=u(nvdof*3+1+0+3*ne:nvdof*3+1*ne+3*ne);
ua2=u(nvdof*3+1+ne+3*ne:nvdof*3+2*ne+3*ne);
ua3=u(nvdof*3+1+2*ne+3*ne:nvdof*3+3*ne+3*ne);

ua=sqrt(ua1.^2+ua2.^2+ua3.^2);ue=sqrt(ue1.^2+ue2.^2+ue3.^2);
% imagesc3dsquare(ue2(:),0);title('exact u2');imagesc3dsquare(ua2,0);title('approx u2')
% imagesc3dsquare(ue(:),0);title('exact u');imagesc3dsquare(ua,0);title('approx u')

diff=sqrt(ua1.^2+ua2.^2+ua3.^2)-sqrt(ue1.^2+ue2.^2+ue3.^2);
exact=sqrt(ue1.^2+ue2.^2+ue3.^2);
Mass=vol*speye(ne);
err=sqrt(diff'*Mass*diff);
rerr=sqrt(diff'*Mass*diff)/sqrt(exact'*Mass*exact);
% fprintf('size is %d\n',nx)
fprintf('relative error and error of displacement are %2.4e %2.4e\n',norm(diff)/norm(exact),sqrt(sum(diff.^2)*vol) );

% rnorm(ua2,ue2);rnorm(ua3,ue3);
sa=zeros(ne,9);safull=zeros(2*nx,2*ny,2*nz,9);
[ye2,xe2,ze2]=meshgrid(hx/4:hx/2:1,hy/4:hy/2:1,hz/4:hz/2:1);
se11=cigma11(xe2,ye2,ze2);se12=cigma12(xe2,ye2,ze2);se13=cigma13(xe2,ye2,ze2);
se22=cigma22(xe2,ye2,ze2);se23=cigma23(xe2,ye2,ze2);se33=cigma33(xe2,ye2,ze2);
s11ave=zeros(nx,ny,nz);s12ave=zeros(nx,ny,nz);s13ave=zeros(nx,ny,nz);
s22ave=zeros(nx,ny,nz);s23ave=zeros(nx,ny,nz);s33ave=zeros(nx,ny,nz);
for i3=1:2
  for i2=1:2
    for i1=1:2
s11ave=s11ave+se11(i1:2:end,i2:2:end,i3:2:end);
s12ave=s12ave+se12(i1:2:end,i2:2:end,i3:2:end);
s13ave=s13ave+se13(i1:2:end,i2:2:end,i3:2:end);
s22ave=s22ave+se22(i1:2:end,i2:2:end,i3:2:end);
s23ave=s23ave+se23(i1:2:end,i2:2:end,i3:2:end);
s33ave=s33ave+se33(i1:2:end,i2:2:end,i3:2:end);
    end
  end
end
s11ave=s11ave(:)/8;s12ave=s12ave(:)/8;s13ave=s13ave(:)/8;
s22ave=s22ave(:)/8;s23ave=s23ave(:)/8;s33ave=s33ave(:)/8;
id=1;
for i3=1:nx3
  for i2=1:nx2
    for i1=1:nx1
localsdof=nodedge(:,id); 
locals=u(localsdof);
locals=locals(map);
for i=1:9
sa(id,i)=mean(locals((i-1)*8+1:i*8));
temp=locals((i-1)*8+1:i*8);
safull(i1*2-1:i1*2,i2*2-1:i2*2,i3*2-1:i3*2,i)=reshape(temp([1,5,2,6,3,7,4,8]),2,2,2);
end

id=id+1;
    end
   end
end
safull=reshape(safull,8*ne,9);
if 0
rnorm(sa(:,1),s11ave);
rnorm(sa(:,2),s12ave);
rnorm(sa(:,3),s13ave);
rnorm(sa(:,4),s12ave);
rnorm(sa(:,5),s22ave);
rnorm(sa(:,6),s23ave);
rnorm(sa(:,7),s13ave);
rnorm(sa(:,8),s23ave);
rnorm(sa(:,9),s33ave);
end
sasum=zeros(ne,1);
safullsum=zeros(ne*8,1);
for i=1:9
sasum=sasum+sa(:,i).^2;
safullsum=safullsum+safull(:,i).^2;
end
sasum=sqrt(sasum);safullsum=sqrt(safullsum);
sesum=sqrt(s11ave.^2+s12ave.^2+s13ave.^2+s12ave.^2+s22ave.^2+s23ave.^2+s13ave.^2+s23ave.^2+s33ave.^2);
sefullsum=sqrt(se11.^2+se12.^2+se13.^2+se12.^2+se22.^2+se23.^2+se13.^2+se23.^2+se33.^2);sefullsum=sefullsum(:);


% rnorm(sasum,sesum);

diff1=sasum-sesum;diff2=safullsum-sefullsum;

fprintf('full vs full, relative error and error of stress are %2.4e %2.4e\n',norm(diff2)/norm(sefullsum),...
    sqrt(sum(diff2.^2)*vol/8) );
fprintf('average vs average, relative error and error of stress are %2.4e %2.4e\n',norm(diff1)/norm(sesum),sqrt(sum(diff1.^2)*vol) );
se11center=cigma11(xe,ye,ze);se12center=cigma12(xe,ye,ze);se13center=cigma13(xe,ye,ze);
se22center=cigma22(xe,ye,ze);se23center=cigma23(xe,ye,ze);se33center=cigma33(xe,ye,ze);
secenter=sqrt(se11center.^2+se12center.^2+se13center.^2+se12center.^2+se22center.^2+se23center.^2+...
    +se13center.^2+se23center.^2+se33center.^2);
secenter=secenter(:);
diff3=sasum-secenter;
fprintf('average vs center, relative error and error of stress are %2.4e %2.4e\n',norm(diff3)/norm(secenter),...
    sqrt(sum(diff3.^2)*vol/8) );

rota=u(3*nvdof+1:3*nvdof+3*ne);
rota23=rota(1:ne);rota13=rota(1+ne:2*ne);rota12=rota(1+2*ne:3*ne);

rotan=sqrt(rota23.^2+rota13.^2+rota12.^2);
roten=sqrt(rote23.^2+rote13.^2+rote12.^2);
diff4=roten-rotan;
fprintf('relative error and error of rotation are %2.4e %2.4e\n',norm(diff4)/norm(roten),...
    sqrt(sum(diff4.^2)*vol) );

if 0
imagesc3dsquare(se11(:),1);
imagesc3dsquare(safull(:,1),1);
% imagesc3dsquare(sa(:,1),1);

imagesc3dsquare(se12(:),1);
imagesc3dsquare(safull(:,2),1);

imagesc3dsquare(se22(:),1);
imagesc3dsquare(safull(:,5),1);
end
