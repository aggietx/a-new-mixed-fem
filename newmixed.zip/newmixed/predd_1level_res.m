function  x=predd_1level_res( Fpre, x,Nx1,Nx2,Nx3,localL,localU,alllocal_pdof,alltruedof,alllocal_pdof0)
% tic
   r=Fpre ;  
   Mr=zeros(size(x));
   


 for iix=1:Nx3
    for iiz=1:Nx2
        for iiy=1:Nx1
    iie=(iix-1)*Nx2*Nx1+(iiz-1)*Nx1+iiy;
global_p_dof=alllocal_pdof{iie};
localr=r(global_p_dof);
L1=localL{iie};
U1=localU{iie};



localup=U1\(L1\((localr)));
global_p_dof0=alllocal_pdof0{iie};
truedof=alltruedof{iie};
     Mr(global_p_dof0)=Mr(global_p_dof0)+ localup(truedof);

        end
    end
 end
x=Mr;