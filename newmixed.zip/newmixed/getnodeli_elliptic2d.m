function [nodedge,nodedof,dofx1,dofx2,dofy1,dofy2]=getnodeli_elliptic2d(nx,ny)
ne=nx*ny;
[edge_hor,edge_vec,nodedof] = getedgedof(ny,nx);
dofx1=edge_vec(:,1);dofx2=edge_vec(:,end);
dofy1=edge_hor(1,:)';dofy2=edge_hor(end,:)';

nodedge=zeros(8,ne);

id=1;
for i=1:nx
    for j=1:ny
        dof1=edge_vec(j*2-1,i);dof2=edge_vec(j*2,i); dof3=edge_vec(j*2-1,i+1);dof4=edge_vec(j*2,i+1);
        dof5=edge_hor(j,i*2-1);dof6=edge_hor(j+1,i*2-1);dof7=edge_hor(j,i*2);dof8=edge_hor(j+1,i*2);%%%%%%%%%%%%%%%%%%%%%%%
localedof=[dof1,dof2,dof3,dof4,dof5,dof6,dof7,dof8]';
nodedge(:,id)=localedof;
id=id+1;
    end
end

