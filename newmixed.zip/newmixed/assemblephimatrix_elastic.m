function phimatrix_p=assemblephimatrix_elastic(basismap,Nx,Ny,Nz,n,iivaluecell)
dim_pc=sum(basismap(:));
ix=zeros(dim_pc,n^3*3);ivalue=zeros(dim_pc,n^3*3);
% iy=repmat((1:dim_pc)',1,n^3);
iy=(1:dim_pc)'*ones(1,3*n^3);
ind=1;
ne=Nx*Ny*Nz*n^3;
p_dof=reshape(1:Nx*Ny*Nz*n^3,Ny*n,Nz*n,Nx*n);
iie=1;
for ii3=1:Nz
    for ii2=1:Ny
        for ii1=1:Nx
             global_p_dof=p_dof( (ii1-1)*n+1:ii1*n,(ii2-1)*n+1:ii2*n,(ii3-1)*n+1:ii3*n);
             global_p_dof=global_p_dof(:);
             
             global_p_dof=[global_p_dof;global_p_dof+ne;global_p_dof+2*ne];
            
%     iie=(iix-1)*Nz*Ny+(iiz-1)*Ny+iiy;
    basis=iivaluecell{iie};
    nlocal_basis=basismap(iie);
%     allbasis(:,1:nlocal_basis,iie)=basis; 
    ivalue(ind:ind+nlocal_basis-1,:)=basis';   
    ix(ind:ind+nlocal_basis-1,:)= repmat( global_p_dof,1,nlocal_basis)';
%     ix(ind:ind+nlocal_basis-1,:)=  (global_p_dof*ones(1,nlocal_basis))';
ind=ind+nlocal_basis;  
iie=iie+1;
        end
    end
end
% if max(imag(allbasis(:)))>10^(-8)
%     disp('complex eigenfunction')
% end
% clear iivaluecell
% disp('assembling coarse matrix...')
% clear alllocal_pdof allbasis p_dof
 phimatrix_p=sparse(iy,ix,ivalue,dim_pc,3*ne);clear ix iy ivalue
