function  [u,relres2,iter2,report]=ilu_2grid_solver_pcg(Kd,F,phi,varargin)

    opt = struct('tol'     , 10^(-8)                      , ...
                 'initype' , 1              , ...
                 'cgtype', 1,...
                 'ip',0);
    opt = merge_options(opt, varargin{:});
    tol=opt.tol;
    initype=opt.initype;
    cgtype=opt.cgtype;
    ip=opt.ip;
    ndof=size(F,1);
if initype
    disp('zero initial')
uinit=zeros(ndof,1);
end
disp('solve with two_grid preconditioner with ilu smoother...')

        t2grid0=tic ;
        if ip==0
        [Lilu_p,Uilu_p]=ilu(Kd);
        else
        [Lilu_p,Uilu_p]=iluk(Kd,ip);
        end
      phiA=phi*Kd; Apms=phiA*phi';
%       Apms=Apms+10^(-12)*diag(diag(Apms));
      [L,U,P,Q] = lu(Apms); 
   if initype~=1;  disp('ms initial');  uc=Q*(U\(L\(P*(phi*F))));uinit=phi'*uc;end
      tsolve2grid0=toc(t2grid0);
      t2grid1=tic ;
         precond2=@(inc)pre2grid2_ilu(Kd, inc,zeros(size(F,1),1),L,U,P,Q,phi,1,Lilu_p,Uilu_p, phiA);

% ua=precond2(F);
% rnorm(ua,Kd\F);
if cgtype
[u, relres2, iter2, flag,condn,tpre] = pcg0_cond(Kd, uinit, F, 5000, tol,precond2);tsolve2grid1=tpre;
else
    [u, relres2, iter2, flag,condn,tpre] = pcg0_cond1(Kd, uinit, F, 5000, tol,precond2);tsolve2grid1=tpre;
end
fprintf('ip, dim are %d, %d %d\n',ip,size(phi,1),size(phi,2));
  fprintf('pcg iter number, condition number, residual,tsolve(2grid) are %d & %2.2e %2.2e %2.2f + %2.2f = %2.2f seconds\n',ceil(iter2),condn, relres2,tsolve2grid0,tsolve2grid1,tsolve2grid0+tsolve2grid1);   %%floor(iter2(size(iter2,2)))

            report.Iterations=prod(iter2);
              report.Residual=relres2;
            report.SolverTime=0;
    report.LinearSolutionTime=tsolve2grid0+tsolve2grid1;
       report.PreparationTime=0;
       report.PostProcessTime=0;
          if flag==0;   report.Converged=true;end
disp('...................')
          
end


function  x=pre2grid2_ilu(Apre, Fpre, x,L,U,P,Q,phimatrix_enriched,ncycle,Lilu,Uilu,RA)
for ii=1:ncycle

% %    r=Fpre - Apre*x;
   x1=Uilu\(Lilu\Fpre);
  
 
% % %    r1=Fpre - Apre*x1;r0=phimatrix_enriched*r1;     
   
   r0=phimatrix_enriched*Fpre-RA*x1;
   uc=Q*(U\(L\(P*(r0))));
   x2=x1 + phimatrix_enriched.'*uc;
   
    r2=Fpre - Apre*x2;
   x=x2+Uilu\(Lilu\r2);
% 
end
end