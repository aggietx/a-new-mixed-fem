
clear;
close all
errcase=1;%%%% 1:average
nx=4*2^4;ny=nx;ne=nx*ny;nvet=2*ny*(nx+1);nhor=2*nx*(ny+1);nvdof=nvet+nhor;nedge=ny*(nx+1)+nx*(ny+1);
Lx=1;Ly=1;hx=Lx/nx;hy=Ly/ny;vol=hx*hy;np=(nx+1)*(ny+1);
[nodv,dofx1,dofx2,dofy1,dofy2]=local2globaldofb(nx,ny);nodv2=[nodv;nodv+2*nedge];
correct=1;
lambda=10^0*ones(ny,nx);
mu=1*ones(ny,nx);
lambda=lambda(:);mu=mu(:);

s=lambda(1,1);t=mu(1,1);
lambda_bar=-lambda./(4*mu.*(lambda+mu));
mu_bar=1/2./(mu);
lambdabar_mubar=lambda_bar+mu_bar;

Ass11=sparse(nodv,nodv,[ones(4,1)*lambdabar_mubar';ones(4,1)*mu_bar'])*vol/4;
Ass22=sparse(nodv,nodv,[ones(4,1)*mu_bar';ones(4,1)*lambdabar_mubar'])*vol/4;
ir1=zeros(16^2,ne);
ic1=zeros(16^2,ne);
localA12=zeros(16,16);
if correct

localA12(1,5+8)=1;localA12(2,15)=1;localA12(3,14)=1;localA12(4,8+8)=1;
localA12(5+8,1)=1;localA12(15,2)=1;localA12(14,3)=1;localA12(8+8,4)=1;
else
localA12(1,5+8)=1;localA12(2,14)=1;localA12(3,15)=1;localA12(4,8+8)=1;
localA12(5+8,1)=1;localA12(14,2)=1;localA12(15,3)=1;localA12(8+8,4)=1;
end
id=1;
for i=1:nx
    for j=1:ny
localedof=[nodv(:,id);nodv(:,id)+nvdof];  ir1(:,id)=repmat(localedof,16,1);
temp=repmat(localedof,1,16);temp=temp';ic1(:,id)=temp(:);
id=id+1;
    end
end
Ass=[1*Ass11,sparse(nedge*2,nedge*2);
    sparse(nedge*2,nedge*2), 1*Ass22]+sparse(ir1,ic1,localA12(:)*lambda_bar'*vol/4);
% Ass=diag(sum(Ass,2));
% invAss11=sparse(1:2*nedge,1:2*nedge,1./diag(Ass11));
% B=Ass(1:2*nedge,2*nedge+1:end);
% C=B';
% D=Ass22;
% temp=D-C*invAss11*B;

%%
localsp=[-1,-1,1,1,-1,-1,1,1]'*hx/2;
ivalue=repmat(localsp,1,ne);
ix=repmat(1:ne,8,1);
Asp0=sparse(nodv,ix,ivalue);clear ivalue ix 
Asp=[Asp0,sparse(2*nedge,ne);
    sparse(2*nedge,ne),Asp0];

%% stress, rotation
localsr=zeros(16,1);
localsr(5,1)=-1;localsr(6,1)=-1;localsr(7,1)=-1;localsr(8,1)=-1;
localsr(9,1)=1;localsr(10,1)=1;localsr(11,1)=1;localsr(12,1)=1;

localsr=localsr*vol/4;
allpdof=reshape(1:(nx+1)*(ny+1),ny+1,nx+1);
ir=zeros(16*1,ne);
ic=zeros(16*1,ne);
id=1;
for i=1:nx
    for j=1:ny
localedof=[nodv(:,id);nodv(:,id)+nvdof];  ir(:,id)=repmat(localedof,1,1);
localpdof=id;localpdof=localpdof(:);temp=repmat(localpdof,1,16);temp=temp';ic(:,id)=temp(:);

id=id+1;
    end
end
Ars=sparse(ir,ic,repmat(localsr(:),1,ne));
A=[Ass, Asp,Ars;
   -Asp',sparse(2*ne,2*ne+ne);
   Ars',sparse(ne,2*ne+ne)];
%% post
[xe,ye]=meshgrid(hx/2:hx:Lx-hx/2,hy/2:hy:Ly-hy/2);
u1_exact=@(x,y) sin(pi*x).*sin(pi*y)+1/2/s.*x;ue1=u1_exact(xe(:),ye(:));
u2_exact=@(x,y) cos(pi*x).*cos(pi*y)+1/2/s.*y;ue2=u2_exact(xe(:),ye(:));

cigma_11_f=@(x,y) (s+2*t)*(pi*cos(pi*x).*sin(pi*y)+1/2/s)+s*(-pi*cos(pi*x).*sin(pi*y)+1/2/s);
cigma_12_f=@(x,y) t*pi*cos(pi*y).*sin(pi*x)-t*pi*sin(pi*x).*cos(pi*y);
cigma_22_f=@(x,y) (s+2*t)*(-pi*cos(pi*x).*sin(pi*y)+1/2/s)+s*(pi*cos(pi*x).*sin(pi*y)+1/2/s);
cigma_21_f=cigma_12_f;

% return
f1 =@(x,y) 2*pi^2*sin(pi*x).*sin(pi*y);
f2 =@(x,y) 2*pi^2*cos(pi*x).*cos(pi*y);
F1=f1(xe(:),ye(:));F2=f2(xe(:),ye(:));
F=zeros(2*ne+2*nvdof+ne,1);

%%%% diri for u1
ya=(2*hy/4:hy:1);yb=(2*hy/4:hy:1);x=zeros(1,ny);
F(dofx1(1:2:end))=-u1_exact(x,ya)*hy/2;F(dofx1(2:2:end))=-u1_exact(x,yb)*hy/2;%%% u1,x=0,
x=ones(1,ny);
F(dofx2(1:2:end))=u1_exact(x,ya)*hy/2;F(dofx2(2:2:end))=u1_exact(x,yb)*hy/2;%%% u1,x=1,
xa=(2*hx/4:hx:1);xb=(2*hx/4:hx:1);y=zeros(1,nx);
F(dofy1(1:2:end))=-u1_exact(xa,y)*hx/2;F(dofy1(2:2:end))=-u1_exact(xb,y)*hx/2;%%% u1,y=0,
y=ones(1,nx);
F(dofy2(1:2:end))=u1_exact(xa,y)*hx/2;F(dofy2(2:2:end))=u1_exact(xb,y)*hx/2;%%% u1,y=1,

%%%% diri for u2
ya=(2*hy/4:hy:1);yb=(2*hy/4:hy:1);x=zeros(1,ny);
F(dofx1(1:2:end)+2*nedge)=-u2_exact(x,ya)*hy/2;F(dofx1(2:2:end)+2*nedge)=-u2_exact(x,yb)*hy/2;%%% u1,x=0,
x=ones(1,ny);
F(dofx2(1:2:end)+2*nedge)=u2_exact(x,ya)*hy/2;F(dofx2(2:2:end)+2*nedge)=u2_exact(x,yb)*hy/2;%%% u1,x=1,
xa=(2*hx/4:hx:1);xb=(2*hx/4:hx:1);y=zeros(1,nx);
F(dofy1(1:2:end)+2*nedge)=-u2_exact(xa,y)*hx/2;F(dofy1(2:2:end)+2*nedge)=-u2_exact(xb,y)*hx/2;%%% u1,y=0,
y=ones(1,nx);
F(dofy2(1:2:end)+2*nedge)=u2_exact(xa,y)*hx/2;F(dofy2(2:2:end)+2*nedge)=u2_exact(xb,y)*hx/2;%%% u1,y=1,

F(2*nvdof+1:2*nvdof+2*ne)=[F1;1*F2]*vol;
u=A\F;


% imagescsquare1(ue1);title('exact u1');imagescsquare1(u(2*nvdof+1:2*nvdof+ne));title('app u1');
% imagescsquare1(ue2);title('exact u2');imagescsquare1(u(2*nvdof+1+ne:2*nvdof+2*ne));title('app u2');
ua1=u(2*nvdof+1:2*nvdof+ne);
ua2=u(2*nvdof+1+ne:2*nvdof+2*ne);
% rnorm(sqrt(ua1.^2+ua2.^2),sqrt(ue1.^2+ue2.^2));
% imagescsquare1(sqrt(ue1.^2+ue2.^2));title('exact norm u');
% imagescsquare1(sqrt(ua1.^2+ua2.^2));title('app norm u');

diff=sqrt(ua1.^2+ua2.^2)-sqrt(ue1.^2+ue2.^2);
exact=sqrt(ue1.^2+ue2.^2);
Mass=vol*speye(ne);
err=sqrt(diff'*Mass*diff);
rerr=sqrt(diff'*Mass*diff)/sqrt(exact'*Mass*exact);
fprintf('size is %d\n',nx)
fprintf('relative error and error of displacement are %2.4e %2.4e\n',norm(diff)/norm(exact),sqrt(sum(diff.^2)*vol) );
