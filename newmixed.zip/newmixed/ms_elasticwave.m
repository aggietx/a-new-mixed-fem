close all;
bt=3;regvalue=10^(-10);
%% basis
if bt==1
    disp('poly basis')
        overelement=0;   order=4;nmaxbasis=2*(order+1)^2;basismap=nmaxbasis*ones(Nx*Ny,1);
phi=assemble_poly2d_elastic(Nx,Ny,n,order);
elseif bt==2
        disp('poly bd driven ms basis')
  overelement=0;order=4;nmaxbasis=2*(order+1)^2;basismap=nmaxbasis*ones(Nx*Ny,1);
[phi,tb,iivaluepcell]=assemble_gmspoly2d_elastic_stresseli_ov(overelement,Nx,Ny,n,...
  lambda,mu,basismap,regvalue,localA12,...
  localA11a,localA11b,localA22a,localA22b,mu_bar,order,hx,hy);
% a=iivaluepcell{1};imagescsquare1(a(1:n^2,3))
elseif bt==3
    disp('ms basis')
    overelement=6;nmaxbasis=25;basismap=nmaxbasis*ones(Nx*Ny,1);
[phi,alleigval,tb]=assemble_gms2d_elastic_stresseli_ov(overelement,Nx,Ny,n,...
  lambda,mu,basismap,regvalue,localA12,...
  localA11a,localA11b,localA22a,localA22b,mu_bar);
end

%% ms
   Mms=phi* (sparse(1:2*ne,1:2*ne,Mass_weight_v+beta_b*dt*Mass_damp_v))* phi.';   
   Mms=(Mms+Mms')/2;Mms=Mms+regvalue*diag(diag(Mms));
   % Mmsa=chol(Mms);Mmsb=Mmsa.';
tic
 invmms_local=cell(np,1);
id=0;
for i=1:Nx*Ny
ndof=basismap(i);
invmms_local{i}=inv(Mms(id+1:id+ndof,id+1:id+ndof));
id=id+ndof;
end
invMms=blkdiag(invmms_local{:});
toc
   A2ms=phi* A2*  phi.';
   A1ms=phi* A1*  phi.';
   % % AA2ms=Mmsa\(Mmsb\(A2ms));
   % % AA1ms=Mmsa\(Mmsb\(A1ms));
   % % FF1ms=Mmsa\(Mmsb\(phi*FF));
      AA2ms=invMms*(A2ms);
   AA1ms=invMms*(A1ms);
   FF1ms=invMms*(phi*FF);
tms=tic;
     ums=onlinewaveabc(AA2ms,AA1ms,FF1ms,ft,step,0.9*T,dt,5);
     umsf=phi'*ums; 
   tms=toc(tms);
fprintf('t fine and ms are %2.1f %2.1f seconds\n',tf,tms);
    
 imagescsquare1(umsf(1:ne));title('ms solution')
fprintf('# basis and overelement are %d %d\n',nmaxbasis,overelement);

 rnorm(umsf,u);