function invAvv=assembleAvv_partb(invk11,invk22,invk33,invk23,localA23,vol,np,nodedof,nodv,ir1,ic1,ne)


% Avvdiag=sparse(nodv,nodv,[ones(8,1)*invk11';ones(8,1)*invk22';ones(8,1)*invk33'])*vol/8;
% Avv=Avvdiag+1*sparse(ir1,ic1,localA23(:)*invk23'*vol/8);

Avvdiag=sparse(nodv,ones(24,ne),[ones(8,1)*invk11';ones(8,1)*invk22';ones(8,1)*invk33'])*vol/8;
Avv=diag(Avvdiag)+1*sparse(ir1,ic1,localA23(:)*invk23'*vol/8);

invAvv_local=cell(np,1);
id=0;
all_localmatrix=cell(np,1);
for i=1:np
ndof=nodedof(i);
all_localmatrix{i}=Avv(id+1:id+ndof,id+1:id+ndof);
id=id+ndof;
end
parfor i=1:np
invAvv_local{i}=inv(all_localmatrix{i});
end
clear Ass
invAvv=blkdiag(invAvv_local{:});clear invAvv_local

