function A=diri_setA(A,diridof)

if size(diridof,1)==1
    diridof=diridof.';
end
A(diridof,:)=sparse(1:size(diridof,1),diridof',ones(1,size(diridof,1)),size(diridof,1),size(A,2));

% A=A+diag(diag(A))*10^(-8);
