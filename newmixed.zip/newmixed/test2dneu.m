%%%% test zero neumann
clear;
close all

nx=32*1;ny=nx;ne=nx*ny;nvet=2*ny*(nx+1);nhor=2*nx*(ny+1);nvdof=nvet+nhor;nedge=ny*(nx+1)+nx*(ny+1);
Lx=1;Ly=1;hx=Lx/nx;hy=Ly/ny;vol=hx*hy;np=(nx+1)*(ny+1);
maxval=10^10;
[edge_hor,edge_vec,nodedof] = getedgedof(ny,nx);
nodv=zeros(16,ne);
bddof=[edge_hor(1,:)';edge_hor(end,:)';edge_vec(:,1);edge_vec(:,end)];bddof=sort(bddof);bddof=[bddof*2-1;bddof*2];
poission_ratio=0.1;
% load k1;young_modulus=k1;
young_modulus=1*ones(ny,nx);% % depends on x
young_modulus(10:15,5:25)=maxval;
young_modulus(18:25,5:25)=maxval;
young_modulus(4:30,28:31)=maxval;
lambda=poission_ratio/((1+poission_ratio)*(1-2*poission_ratio))*young_modulus;
mu=1/2/(1+poission_ratio)*young_modulus;
lambda=lambda(:);mu=mu(:);

s=lambda(1,1);t=mu(1,1);
lambda_bar=-lambda./(4*mu.*(lambda+mu));
mu_bar=1/2./(mu);
lambdabar_mubar=lambda_bar+mu_bar;
if 0
    %% (As,s) matrix
localA12=zeros(16,16);
localA12(1,10)=-1;localA12(3,12)=1;localA12(5,14)=1;localA12(7,16)=-1;
localA12(10,1)=-1;localA12(12,3)=1;localA12(14,5)=1;localA12(16,7)=-1;
localA11a=zeros(16,16);localA11b=zeros(16,16);localA22a=zeros(16,16);localA22b=zeros(16,16);

ir1=zeros(16^2,ne);
ic1=zeros(16^2,ne);

for i=1:2:7;localA11a(i,i)=1;end
for i=[9,11,13,15];localA11b(i,i)=1;end
for i=2:2:8;localA22a(i,i)=1;end
for i=[10,12,14,16];localA22b(i,i)=1;end

nodedge=zeros(16,ne);
id=1;
for i=1:nx
    for j=1:ny
        dof1=edge_vec(j*2-1,i);dof2=edge_vec(j*2,i); dof3=edge_vec(j*2-1,i+1);dof4=edge_vec(j*2,i+1);
        dof5=edge_hor(j,i*2-1);dof6=edge_hor(j+1,i*2-1);dof7=edge_hor(j,i*2);dof8=edge_hor(j+1,i*2);
localedof=[dof1*2-1:dof1*2,dof2*2-1:dof2*2,dof3*2-1:dof3*2,dof4*2-1:dof4*2,dof5*2-1:dof5*2,dof6*2-1:dof6*2,dof7*2-1:dof7*2,dof8*2-1:dof8*2]';
nodedge(:,id)=localedof;
ir1(:,id)=repmat(localedof,16,1);
temp=repmat(localedof,1,16);temp=temp';ic1(:,id)=temp(:);
id=id+1;
    end
end

Ass=sparse(ir1,ic1,localA11a(:)*lambdabar_mubar'*vol/4+localA11b(:)*mu_bar'*vol/4+...
                     1*localA12(:)*lambda_bar'*vol/4+...
                     localA22a(:)*mu_bar'*vol/4+localA22b(:)*lambdabar_mubar'*vol/4);
% spy(Ass)
invAss_local=cell(np,1);
id=0;
for i=1:np
localdof=nodedof(:,i);ndof=length(find(localdof))*2;

invAss_local{i}=inv(Ass(id+1:id+ndof,id+1:id+ndof));
id=id+ndof;
end
invAss=blkdiag(invAss_local{:});


%% 
localsp=zeros(16,2);
localsp([1,3,5,7,9,11,13,15],1)=[-1,1,1,-1,1,-1,-1,1]'*hx/2;
localsp([2,4,6,8,10,12,14,16],2)=[-1,1,1,-1,1,-1,-1,1]'*hx/2;


ir=zeros(16*2,ne);
ic=zeros(16*2,ne);
id=1;
for i=1:nx
    for j=1:ny
localedof=nodedge(:,id); ir(:,id)=repmat(localedof,2,1);
localudof=[id,id+ne];localudof=localudof(:);temp=repmat(localudof,1,16);temp=temp';ic(:,id)=temp(:);

id=id+1;
    end
end
Asu=sparse(ir,ic,repmat(localsp(:),1,ne));
% return
%% 
localsr=zeros(16,4);
localsr(9,1)=1;localsr(11,2)=1;localsr(13,3)=-1;localsr(15,4)=-1;
localsr(2,1)=1;localsr(4,2)=-1;localsr(6,3)=1;localsr(8,4)=-1;

localsr=localsr*vol/4;
allrdof=reshape(1:(nx+1)*(ny+1),ny+1,nx+1);
ir=zeros(16*4,ne);
ic=zeros(16*4,ne);
id=1;
for i=1:nx
    for j=1:ny
localedof=nodedge(:,id); ir(:,id)=repmat(localedof,4,1);
localrdof=allrdof(j:j+1,i:i+1);localrdof=localrdof(:);temp=repmat(localrdof,1,16);temp=temp';ic(:,id)=temp(:);

id=id+1;
    end
end
Ars=sparse(ir,ic,repmat(localsr(:),1,ne));


A=[Ass, Ars,Asu;
   Ars',sparse(np,2*ne+np);
   Asu',sparse(2*ne,2*ne+np)];
A=dirisetA2(A,bddof);

% 

% Aaug1=A(1:nvdof*2,nvdof*2+1:end);D=sparse(np+2*ne,np+2*ne);[Aeli,Feli,u1,uf]=eli(invAss,Aaug1,D,F);rnorm(u,uf);
% invArr=sparse(1:np,1:np,1./diag(Aeli(1:np,1:np)));D=Aeli(np+1:end,np+1:end); Aaug=Aeli(1:np,np+1:end);[Aeli0,Feli0,u0,uf0]=eli(invArr,Aaug,D,Feli);rnorm(uf0,u1);
Aaug1=[Ars,Asu];D=sparse(np+2*ne,np+2*ne);
else
localA12=zeros(16,16);
localA12(1,10)=1;localA12(3,12)=1;localA12(5,14)=1;localA12(7,16)=1;
localA12(10,1)=1;localA12(12,3)=1;localA12(14,5)=1;localA12(16,7)=1;
localA11a=zeros(16,16);localA11b=zeros(16,16);localA22a=zeros(16,16);localA22b=zeros(16,16);
for i=1:2:7;localA11a(i,i)=1;end
for i=[9,11,13,15];localA11b(i,i)=1;end
for i=2:2:8;localA22a(i,i)=1;end
for i=[10,12,14,16];localA22b(i,i)=1;end

[Aaug1,D,ir1,ic1,nodedof,bddof]=assemble2d_matrix_partb(nx,ny,hx,hy,mu_bar);
[invAss,Ass]=assemble2d_matrix_parta(nx,ny,hx,hy,lambda,mu,localA12,localA11a,localA11b,localA22a,localA22b,ir1,ic1,nodedof);
end
Aaug1(bddof,:)=0;

%% solve

Aeli=eli_matrix0(invAss,Aaug1,D);
invArr=1./diag(Aeli(1:np,1:np));
D=Aeli(np+1:end,np+1:end); Aaug=Aeli(1:np,np+1:end);
Aeli0=eli_matrix0(invArr',Aaug,D);

Aeli0=Aeli0+Aeli0.';
Meig0=sparse(1:2*ne,1:2*ne,[young_modulus(:);young_modulus(:)])*vol;
[v,d]=eigs(-Aeli0,Meig0,10,'sm');
d=diag(d);
d
% close all
% imagescsquare1(v(1:ne,1));imagescsquare1(v(1+ne:2*ne,1));
% imagescsquare1(v(1:ne,2));imagescsquare1(v(1+ne:2*ne,2));
% imagescsquare1(v(1:ne,3));imagescsquare1(v(1+ne:2*ne,3));