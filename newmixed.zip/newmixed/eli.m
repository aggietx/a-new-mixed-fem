function [Aeli,Feli,u1,uf]=eli(invAss,Aaug,D,F)

nelidof=size(Aaug,1);
notherdof=size(Aaug,2);

F1=F(1:nelidof);
F2=F(nelidof+1:end);

Aeli=-(Aaug'*invAss)*Aaug+D;
Feli=-Aaug'*invAss*F1+F2;
u1=Aeli\Feli;uf=zeros(nelidof+notherdof,1);uf(nelidof+1:end)=u1;
uf(1:nelidof)=invAss*(F1-Aaug*u1);
