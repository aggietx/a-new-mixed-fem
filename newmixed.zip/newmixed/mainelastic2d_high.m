%%%% basis are the same as rt0, all vector basis are (1,0) or (0,1), no
%%%% negative, stress elimination
clear;
close all

nx=100;ny=nx;ne=nx*ny;nvet=2*ny*(nx+1);nhor=2*nx*(ny+1);nvdof=nvet+nhor;nedge=ny*(nx+1)+nx*(ny+1);
Lx=1;Ly=1;hx=Lx/nx;hy=Ly/ny;vol=hx*hy;np=(nx+1)*(ny+1);
n=10;Nx=nx/n;Ny=ny/n;
nmaxbasis=10;gs=0;q0=1;eigvalue_tol=10;tol=10^(-5);regvalue=10^(-18);
poission_ratio=0.14999;
% load k1;young_modulus=k1;
% young_modulus=k1(1:100,1:100);young_modulus=repmat(young_modulus,ny/100,nx/100);
young_modulus=1*ones(ny,nx);% % depends on x

young_modulus=young_modulus.^(0);
lambda=poission_ratio/((1+poission_ratio)*(1-2*poission_ratio))*young_modulus;
mu=1/2/(1+poission_ratio)*young_modulus;
lambda=lambda(:);mu=mu(:);

s=lambda(1,1);t=mu(1,1);
lambda_bar=-lambda./(4*mu.*(lambda+mu));
mu_bar=1/2./(mu);
lambdabar_mubar=lambda_bar+mu_bar;
ratio=max(young_modulus(:))/min(young_modulus(:));
fprintf('contrast is %2.1e\n',ratio );

%% (As,s) matrix
localA12=zeros(16,16);
localA12(1,10)=1;localA12(3,12)=1;localA12(5,14)=1;localA12(7,16)=1;
localA12(10,1)=1;localA12(12,3)=1;localA12(14,5)=1;localA12(16,7)=1;
localA11a=zeros(16,16);localA11b=zeros(16,16);localA22a=zeros(16,16);localA22b=zeros(16,16);

for i=1:2:7;localA11a(i,i)=1;end
for i=[9,11,13,15];localA11b(i,i)=1;end
for i=2:2:8;localA22a(i,i)=1;end
for i=[10,12,14,16];localA22b(i,i)=1;end
tic
[Aaug1,D,ir1,ic1,nodedof,~,nodedge]=assemble2d_matrix_partb(nx,ny,hx,hy,mu_bar);
[invAss,Ass]=assemble2d_matrix_parta(nx,ny,hx,hy,lambda,mu,localA12,localA11a,localA11b,localA22a,localA22b,ir1,ic1,nodedof);
toc
%% solve
F=zeros(2*ne+2*nvdof+np,1);
F(2*nvdof+1+np:2*nvdof+2*ne+np)=-1*vol;
tic

    %Aaug1=A(1:nvdof*2,nvdof*2+1:end);
 [Aeli,Feli]=eli_matrix(invAss,Aaug1,D,F);
invArr=sparse(1:np,1:np,1./diag(Aeli(1:np,1:np)));D=Aeli(np+1:end,np+1:end); Aaug=Aeli(1:np,np+1:end);
[Aeli0,Feli0,u0,uf0]=eli(invArr,Aaug,D,Feli);

uf=zeros(2*nvdof+2*ne+np,1);uf(2*nvdof+1:end)=uf0;uf(1:2*nvdof)=-invAss*Aaug1*uf0;
u=uf;

toc
% imagescsquare1(u0(1:ne));title('u1')
% imagescsquare1(u0(1+ne:2*ne));title('u2')


if 1

[alllocalL,alllocalU,alltrue_dof,alllocal_pdof,alllocal_pdofov,allinveli0]=dd2d_setup(Nx,Ny,n,reshape(lambda,ny,nx),reshape(mu,ny,nx),...
    localA12,localA11a,localA11b,localA22a,localA22b,0);
U=blkdiag(alllocalU{:});L=blkdiag(alllocalL{:});
D=blkdiag(allinveli0{:});
 pre1level=@(inc)predd_1level_res( inc,zeros(2*ne,1),Ny,Nx,1,alllocalL,alllocalU,alllocal_pdofov,alltrue_dof,alllocal_pdof);
uinit=zeros(2*ne,1);
disp('1 level preconditioner solve...');preons=tic;[uref1,flag,relres,iter]=bicgstab(Aeli0,Feli0,10^(-3), 500,pre1level,[],uinit);ton=toc(preons);iter=iter*2;
fprintf('bicgstab resvec, iter, tpre, tsolve are %2.2e %d %2.2f %2.2f seconds\n',relres,prod(iter),0,ton);

end


if q0==1
    [phimatrix_pa]=assemble2dq1(Nx,Ny,n);
else
% id=find(allratio>10);a=alleigval{id(1)};a(1:10)'
[phimatrix_pa,alleigval,tb,basismap,iivaluepcell,allratio]=assemble_gms2d_elastic_stresseli(Nx,Ny,n,...
    reshape(lambda,ny,nx),reshape(mu,ny,nx),eigvalue_tol,regvalue,nmaxbasis,localA12,localA11a,localA11b,localA22a,localA22b,mu_bar);
end
% ums=solvemssol(Aeli0,Feli0,phimatrix_pa,u0);% imagescsquare1(ums(1:ne));title('ms u1')
% ilu_2grid_solver1(Aeli0,Feli0,phimatrix_pa,'tol',tol,'ip',0,'initype',0);
%  u0=ilu_2grid_solver_pcg(Aeli0,Feli0,phimatrix_pa,'cgtype',0,'tol',tol,'initype',0);
% u0=ilu_2grid_solver_pcg(Aeli0,Feli0,phimatrix_pa,'cgtype',1,'tol',tol,'initype',1);
fprintf('contrast is %2.1e\n',ratio );
Apms=phimatrix_pa*Aeli0*phimatrix_pa';
[Lms,Ums,Pms,Qms] = lu(Apms);

 pre2g=@(inc)blockjacobi_pre(Aeli0,inc,D,ne,Lms,Ums,Pms,Qms,phimatrix_pa);
 uinit=zeros(2*ne,1);
disp('2 grid preconditioner solve...');preons=tic;[uref1,flag,relres,iter]=bicgstab(Aeli0,Feli0,10^(-3), 500,pre2g,[],uinit);ton=toc(preons);iter=iter*2;
fprintf('bicgstab resvec, iter, tpre, tsolve are %2.2e %d %2.2f %2.2f seconds\n',relres,prod(iter),0,ton);

return
if 0
Ams=phimatrix_pa*Aeli0*phimatrix_pa.';
[Lms,Ums]=lu(Ams);
[alllocalL,alllocalU,alltrue_dof,alllocal_pdof,alllocal_pdofov]=dd2d_setup(Nx,Ny,n,reshape(lambda,ny,nx),reshape(mu,ny,nx),...
    localA12,localA11a,localA11b,localA22a,localA22b,2);

 pre2level=@(inc)predd_2level_res( inc,zeros(2*ne,1),Ny,Nx,1,alllocalL,alllocalU,alllocal_pdofov,alltrue_dof,alllocal_pdof,Lms,Ums,phimatrix_pa);
uinit=zeros(2*ne,1);
disp('2 level preconditioner solve...');preons=tic;[uref1,flag,relres,iter]=bicgstab(Aeli0,Feli0,10^(-6), 500,pre2level,[],uinit);ton=toc(preons);iter=iter*2;
fprintf('bicgstab resvec, iter, tpre, tsolve are %2.2e %d %2.2f %2.2f seconds\n',relres,prod(iter),0,ton);
end

% return
% ilu_solver(Aeli0,Feli0);
% uu=gs_solver(Aeli0,Feli0);
% jacobi_solver(Aeli0,Feli0); 
% return
% ilu_2grid_solver1(Aeli0,Feli0,phimatrix_pa,'tol',10^(-6),'ip',0);
% gs_2gridsolver(Aeli0,Feli0,phimatrix_pa,'tol',10^(-6));
% 
% imagescsquare1(ums(1:ne));title('ms u1')

% imagescsquare1(phimatrix_pa(2,1:ne));
return
a=zeros(ne,1);
id=1;
for i=1:nx
    for j=1:ny
localsdof=nodedge(:,id);
locals=u(localsdof);
 a(id)=locals(9);

        id=id+1;
    end
end
