
function perm=Construction_3D_perm_64_2(maxval)

%%%% repmat from 8^3 model
if 0
% 
perm=ones(16,16,16);
perm(2:5,2:5,2:end)=maxval;
perm(7:10,7:10,2:end)=maxval;
perm(11:14,11:14,2:end)=maxval;

perm=repmat(perm,4,4,4);

else
perm=ones(8,8,8);
perm(2:4,2:4,2:end)=maxval;
perm(5:6,5:6,2:end)=maxval;
perm(2:3,7:8,2:end)=maxval;
perm=repmat(perm,8,8,8);
end


