function [xp,yp]=refinequad2d(x1,y1,x2,y2,x3,y3,x4,y4)

xp=zeros(3,3);
yp=zeros(3,3);

xp(1,1)=x1;yp(1,1)=y1;
xp(1,3)=x3;yp(1,3)=y3;
xp(3,1)=x2;yp(3,1)=y2;
xp(3,3)=x4;yp(3,3)=y4;

xp(1,2)=x1/2+x3/2;yp(1,2)=y1/2+y3/2;
xp(3,2)=x2/2+x4/2;yp(3,2)=y2/2+y4/2;

xp(2,1)=x1/2+x2/2;yp(2,1)=y1/2+y2/2;
xp(2,3)=x3/2+x4/2;yp(2,3)=y3/2+y4/2;

xp(2,2)=xp(2,1)/2+xp(2,3)/2;
yp(2,2)=yp(2,1)/2+yp(2,3)/2;

