    
Nx=64;n=nx/Nx;Ny=nz/n;Nz=nz/n;
N1=16;n1=nx/N1;na=Nx/N1;%% 3 level grid, 
fprintf('grid size are %d %d %d \n',nx,Nx,N1);

[phimatrix_pa,alleigval,allbasis,allratio,tb,basismap]=assemble_gms3d_elastic_stresseli(Nx,Ny,Nz,n,lambda,mu,regvalue,vol,hx1,hx2,eigvalue_tol,nmaxbasis,0);
 
  [phimatrix_p1, t3g,balleigval1,allratio1,basismap1]=compute3g_basis(Nx,Ny,Nz,N1,n1,n,nx,ny,nz,basismap,na,vol,hx1,hx2,lambda,mu,allbasis,nmaxbasis1,nmaxbasis,eigvalue_tol1,regvalue);
    if 0
  uc=ilu_2grid_solver1( phimatrix_pa*Aeli0*phimatrix_pa',phimatrix_pa*Feli0,phimatrix_p1,'tol',tol,'initype',0);
    end
  % if 0;   u0=ilu_2grid_solver_pcg(Aeli0,Feli0,phimatrix_pa,'cgtype',0,'tol',tol,'initype',0);end
if 0;  
    u0=ilu_2grid_solver_pcg(Aeli0,Feli0,phimatrix_pa,'cgtype',1,'tol',tol,'initype',1);
end

% u0=ilu_3grid_solver_pcg0(Aeli0,Feli0,phimatrix_pa,phimatrix_p1,'cgtype',0,'ip1',1,'tol',tol,'initype',0);
u0=ilu_3grid_solver_pcg0(Aeli0,Feli0,phimatrix_pa,phimatrix_p1,'cgtype',1,'ip1',1,'tol',tol,'initype',1);
