function [localdof1,localdof]=vectorize_eli2d(localdof0)
localdof0=localdof0(:);
n=size(localdof0,1);
localdof=zeros(n,2);
localdof(:,1)=localdof0*2-1;
localdof(:,2)=localdof0*2;

localdof1=localdof';localdof1=localdof1(:);
  