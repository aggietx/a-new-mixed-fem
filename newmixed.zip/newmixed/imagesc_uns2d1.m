function imagesc_uns2d1(Lx,Ly,nx,ny,xe,ye,xp,yp,data)
G = cartGrid([nx, ny], [Lx, Ly]);
G.cells.centroids(:,1)=xe(:);
G.cells.centroids(:,2)=ye(:);
G.nodes.coords(:,1)=xp(:);
G.nodes.coords(:,2)=yp(:);

data=full(data(:));


figure()
plotCellData(G,data,'EdgeColor','none'); colormap jet;set(gca,'fontsize',18)
% c = colorbar;
% w = c.LineWidth;
% c.LineWidth = 1.0;
 view(2), axis tight off
   colorbar('Location','SouthOutside');

% colorbar('southoutside')
% axis off
