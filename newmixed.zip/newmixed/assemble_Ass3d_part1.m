function [map,ir1,ic1,localA12]=assemble_Ass3d_part1(ne,nodedge)
%% (As,s) matrix

% disp('generate (As,s) matrix part a...')
% tic
map=zeros(72,1);%id1=1:3:72;id2=2:3:72;id3=3:3:72;
map(1:24)=1:3:72;map(1:24)=1:3:72;map(25:48)=2:3:72;map(49:72)=3:3:72;
%iv11=[ones(8,1)*lambdabar_mubar';ones(8,1)*mu_bar';ones(8,1)*mu_bar'];
% iv11=zeros(72,ne);iv22=zeros(72,ne);iv33=zeros(72,ne);

% iv11(id1,:)=[ones(8,1)*lambdabar_mubar';ones(8,1)*mu_bar';ones(8,1)*mu_bar'];
% iv22(id2,:)=[ones(8,1)*mu_bar';ones(8,1)*lambdabar_mubar';ones(8,1)*mu_bar'];
% iv33(id3,:)=[ones(8,1)*mu_bar';ones(8,1)*mu_bar';ones(8,1)*lambdabar_mubar'];

% iv=iv11+iv22+iv33;clear iv11 iv22 iv33

% Assa=sparse(nodedge,nodedge,aa)*vol/8;

% diagAssa=sparse(nodedge,ones(72,ne),iv)*vol/8;clear iv

localA12=zeros(72,72);
pair=[1*3-2,9*3-1,17*3;
     2*3-2,13*3-1,19*3;
     3*3-2,11*3-1,21*3;
     4*3-2,15*3-1,23*3;
     5*3-2,10*3-1,18*3;
     6*3-2,14*3-1,20*3;
     7*3-2,12*3-1,22*3;
     8*3-2,16*3-1,24*3];

for i=1:8
localA12(pair(i,1),pair(i,2))=1;
localA12(pair(i,1),pair(i,3))=1;
localA12(pair(i,2),pair(i,1))=1;
localA12(pair(i,3),pair(i,1))=1;
localA12(pair(i,2),pair(i,3))=1;
localA12(pair(i,3),pair(i,2))=1;
end
nzid=find(localA12(:));


ir1=kron(nodedge,ones(1,72));ir1=reshape(ir1(:),72^2,ne);ir1=ir1(nzid,:);
ic1=kron(nodedge,ones(72,1));

ic1=ic1(nzid,:);
localA12=localA12(nzid);
% toc