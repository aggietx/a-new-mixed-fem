
A=Aeli0;
F=Feli0;
uref=A\F;
alleigfunoffline=iivaluepcell;
umsfine=solvemssol(A,F,phimatrix_pa,uref);
nit=10;
for i=1:nit
    fprintf('.......................iteration %d.......................\n',i);
    res=F-A*umsfine;
    if i==1
    previousfun=alleigfunoffline;
    else
previousfun=alleigfun;
    end

[onbasis,tb,basismap,alleigfun]=generate_gms_onlinebasis(Nx,Ny,n,...
    reshape(lambda,ny,nx),reshape(mu,ny,nx),10^(-10),2+nit*2,localA12,localA11a,localA11b,localA22a,localA22b,mu_bar,previousfun,res);
% else
% state_ms = incomp_gms_withsmoother(state0, G, T, fluid,onbasis.', 'MatrixOutput', true, 'Wells', W);
% end

umsfine=solvemssol(A,F,onbasis,uref);
fprintf('dof are %d %d\n',size(onbasis.',1),size(onbasis.',2));
end

imagescsquare1(umsfine(1:ne));title('ms u1')