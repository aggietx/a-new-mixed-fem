
function  [phimatrix_pa,alleigval,iivaluepcell,allratio,tb,basismap]=assemble_gms3d_elastic_stresseli(Nx,Ny,Nz,n,lambda,mu,regvalue,vol,hx1,hx2,eigvalue_tol,...
    nmaxbasis,dis)


% eigvalue_tol=100;nmaxbasis=20;regvalue=10^(-10);dis=0;
disp('generate 3d gms elastic basis...')
nx=Nx*n;ny=Ny*n;nz=Nz*n;ne=nx*ny*nz;np=(n+1)^3;
basismap=ones(Nx,Ny,Nz);
nface=(n+1)*n*n*3;nvdof=4*nface;
ts=tic;



p_dof=reshape(1:nx*ny*nz,nx,ny,nz);

Ncb=Nx*Ny*Nz;

 iivaluepcell=cell(Ncb,1);
 alllocal_pdof=cell(Ncb,1);
  alllocallambda=cell(Ncb,1);
 alllocalmu=cell(Ncb,1);
 alleigval=cell(Ncb,1);
id=1;
for ii3=1:Nz
    for ii2=1:Ny
        for ii1=1:Nx
    

global_p_dof=p_dof( (ii1-1)*n+1:ii1*n,(ii2-1)*n+1:ii2*n,(ii3-1)*n+1:ii3*n);global_p_dof=global_p_dof(:);
 alllocal_pdof{id}=global_p_dof;
  alllocallambda{id}=lambda(global_p_dof);
    alllocalmu{id}=mu(global_p_dof);
id=id+1;

        end
    end
end

[nodedge,~,facex1,facex2,facey1,facey2,facez1,facez2,nodedof]=local2globaldof3d_inveli_elastic(n,n,n);
 bddof=[facex1(:);facex2(:);facey1(:);facey2(:);facez1(:);facez2(:)];%Aaug1(bddof,:)=0;
localne=n^3;nlocale=localne;
 [map,ir1,ic1,localA12]=assemble_Ass3d_part1(localne,nodedge);
[ir,ic,localsr]=assemble_Asr3d_continuous_part1(n,n,n,localne,map,vol,np,nodedge);
Asp=assembleAsp3d(map,hx1,hx2,localne,nodedge,np,nvdof);
 D=sparse(3*localne+3*np,3*localne+3*np);allratio=zeros(Ncb,1);
parfor iie=1:Ncb

      locallambda=alllocallambda{iie};
   localmu= alllocalmu{iie};
    locallambda_bar=- locallambda./(2* localmu.*(3* locallambda+2* localmu));
 localmu_bar=1/2./( localmu);
masscoeff=zeros(nlocale*3,1);
masscoeff(1:nlocale)=locallambda(:)+2*localmu(:);
masscoeff(1+nlocale:nlocale*2)=1*locallambda(:)+2*localmu(:);
masscoeff(1+2*nlocale:end)=1*locallambda(:)+2*localmu(:);

    Ars=sparse(ir,ic,localsr*localmu_bar',3*nvdof,3*np+3*localne);
 invAss=assemble_Ass3d_part2( localmu_bar+locallambda_bar,  localmu_bar,locallambda_bar,ir1,ic1,localne,nodedge,vol,localA12,np,nodedof);
        Aaug1=Ars+Asp;Aaug1(bddof,:)=0;
  [Aeli]=eli_matrix0(invAss,Aaug1,D);
invArr=1./diag(Aeli(1:3*np,1:3*np));
D2=Aeli(3*np+1:end,3*np+1:end); Aaug=Aeli(1:3*np,3*np+1:end);
Aeig=-eli_matrix0(invArr',Aaug,D2);
Meig=2*sparse(1:3*localne,1:3*localne,masscoeff)*hx1;
Aeig=Aeig+Aeig.';
Aeig=Aeig+regvalue*diag(diag(Aeig));
Meig=Meig+regvalue*diag(diag(Meig));

 [eigfun,eigvalue]=eigs(Aeig,Meig,nmaxbasis,'sm');
%[eigfun,eigvalue]=eig(full(Aeig),full(Meig));
[d, order] = sort((diag(eigvalue)), 'ascend'); 
% eigfun(1:20,:)
% diag(eigvalue)

% if max(abs(imag(eigfun(:))))>10^(-6)
%     max(abs(imag(eigfun(:))))
%     disp('complex eigvalue, error');
% end

        eigfun=eigfun(:,order);eigvalue=eigvalue(:,order);
        thredhold=find(d>=eigvalue_tol);%% adaptive local number of basis
       if size(thredhold,2)*size(thredhold,1)==0  %%%% all eigvalue less than tolerance
        nlocalbasis=nmaxbasis;
       else
       nlocalbasis=thredhold(1);
       end 
       basis=eigfun(:,1:nlocalbasis);
%       if 1
% basis=scalar2vector(basis);
%       end
       basismap(iie)=size(basis,2);
alleigval{iie}=diag(eigvalue);
iivaluepcell{iie}=basis;
allratio(iie)=max(locallambda)/min(locallambda);
end

dim_pc=sum(basismap(:));
ixp=zeros(dim_pc,3*n^3);
ivaluep=zeros(dim_pc,3*n^3);
iyp=(1:dim_pc)'*ones(1,3*n^3);

ind=1;
iie=1;
for ii3=1:Nz
    for ii2=1:Ny
        for ii1=1:Nx
    
    basis=iivaluepcell{iie};
    nlocal_basis=basismap(iie);
    ivaluep(ind:ind+nlocal_basis-1,:)=basis';   
    global_p_dof=alllocal_pdof{iie};

   global_p_dof=[global_p_dof(:);global_p_dof(:)+ne;global_p_dof(:)+2*ne];
global_p_dof=sort( global_p_dof(:));

    ixp(ind:ind+nlocal_basis-1,:)= repmat( global_p_dof,1,nlocal_basis)';
ind=ind+nlocal_basis;  
iie=iie+1;
        end
    end
end
% if max(imag(allbasis(:)))>10^(-8)
%     disp('complex eigenfunction')
% end
% return
disp('assembling coarse matrix...')
clear alllocal_pdof allbasis p_dof
if dis
     phimatrix_pa=sparse(iyp,ixp,ivaluep,dim_pc*2,ne*3+3*ne)+...
         sparse(iyp+dim_pc,ixp+3*ne,ivaluep,dim_pc*2,ne*3+3*ne);
else
 phimatrix_pa=sparse(iyp,ixp,ivaluep,dim_pc,ne*3);
end
 fprintf('dim of are %d %d\n',dim_pc,size(phimatrix_pa,2));
 fprintf('average basis number is %2.2f\n',dim_pc/(Nx*Ny*Nz));
 fprintf('2grid basis number is %d~%d\n',min(basismap(:)),max(basismap(:)) );
 clear ixp iyp ivaluep
 disp('END of generating ms basis')
 tb=toc(ts);
  fprintf('Tbasis is %2.2f seconds\n',tb);
  disp('............')