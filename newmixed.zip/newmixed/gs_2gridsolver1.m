function  [u,relres2,iter2,report]=gs_2gridsolver1(Kd,F,phi,varargin)
%%%% inside preconditioner use coarse as initial guess
ne=size(F,1);
    opt = struct('tol'     , 10^(-8)                      , ...
                 'omega'    , 1.8, ...
                 'step', 5                            , ...
                 'initype' , 1              , ...
                 'bicg', 1 );
    opt = merge_options(opt, varargin{:});
    tol=opt.tol;
    omega=opt.omega;
    step=opt.step;
    initype=opt.initype;
    bicg=opt.bicg;
fprintf('dof are %d %d \n',size(phi,2),size(phi,1));
if initype
    disp('zero initial guess')
uinit=zeros(ne,1);
end
        t2grid0=tic ;
      phiA=phi*Kd; Apms=phiA*phi';% Apms=Apms+10^(-16)*diag(diag(Apms));
      [L,U,P,Q] = lu(Apms); 
   if initype~=1;   uc=Q*(U\(L\(P*(phi*F))));uinit=phi'*uc;end
    D=sparse(1:ne,1:ne,diag(Kd));
    L1 = tril(Kd,-1);
    N = D + omega*L1;
    M = (1 - omega)*D - omega*triu(Kd,1);
      tsolve2grid0=toc(t2grid0);
      t2grid1=tic ;
         precond2=@(inc)pre2grid_gs(Kd, inc,N,M,phi,zeros(ne,1),L,U,P,Q,step,step,phiA);
disp('solve with two_grid preconditioner with gs smoother...')
% ua=precond2(F);
% rnorm(ua,Kd\F);
if bicg
 [u,flag,relres2,iter2]=bicgstab(Kd,F,tol, 500,precond2,[],uinit);tsolve2grid1=toc(t2grid1);iter2=iter2*2;
%  relres2=norm(F-Kd*u)/norm(F);
  fprintf('bicgstab number,residual,tsolve(2grid) are %d %2.2e %2.2f + %2.2f = %2.2f seconds\n',ceil(iter2),relres2,tsolve2grid0,tsolve2grid1,tsolve2grid0+tsolve2grid1);   %%floor(iter2(size(iter2,2)))
else
  [u,flag,relres2,iter2]=gmres(Kd,F,10,tol, 50,precond2,[],uinit);tsolve2grid1=toc(t2grid1);
%    relres2=norm(F-Kd*u)/norm(F);
 fprintf('gmres number,residual,tsolve(2grid) are %d %2.2e %2.2f + %2.2f = %2.2f seconds\n',ceil(iter2(1)*iter2(2)),relres2,tsolve2grid0,tsolve2grid1,tsolve2grid0+tsolve2grid1);   %%floor(iter2(size(iter2,2)))
end
            report.Iterations=prod(iter2);
              report.Residual=relres2;
            report.SolverTime=0;
    report.LinearSolutionTime=tsolve2grid0+tsolve2grid1;
       report.PreparationTime=0;
       report.PostProcessTime=0;
          if flag==0;   report.Converged=true;end
disp('....................')
end


function  x=pre2grid_gs(Apre,Fpre, N,M,phi,x,L,U,P,Q,step1,step2,RA)

   Fms=phi*Fpre;
   uc=Q*(U\(L\(P*(Fms))));
   x=phi.'*uc; 

%% smooothing
   for k = 1:step1
     x =  N\(Fpre + M*x);
   end
%% coarse  

%    r=Fpre - Apre*x;
%    r0=phi*r;  

   r0=Fms-RA*x;
   uc=Q*(U\(L\(P*(r0))));
   umsfine=phi.'*uc; 
   x=x + umsfine;

  %% smoothing
   for k = 1:step2
       x =  N\(Fpre + M*x);
   end

end
