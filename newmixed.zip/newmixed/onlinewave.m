function Urecord=onlinewave(M_A,M_FF,ft,step,snapshot,dt,nprint)

U1=zeros(size(M_A,1),1);
U2=U1;
tic
 for k=1:step  
     if mod(step-k,nprint)==0
        fprintf('rest step is %d\n', step-k);
     end
      U3=2*U2-U1-M_A*U2+M_FF*ft(k+1);
      U1=U2; U2=U3;
 
      if k==floor(snapshot/dt)
      Urecord=U3; % % record the steps we need 
      end
 
end 
toc