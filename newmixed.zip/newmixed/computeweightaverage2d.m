function rotacell=computeweightaverage2d(ra,localarea)


rotacell=sum(ra.*localarea)/sum(localarea);
