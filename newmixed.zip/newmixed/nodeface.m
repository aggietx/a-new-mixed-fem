function [M] = nodeface(x,y,z)
point1 = cell(x+1,y+1,z+1);
pointline = zeros(12,(x+1)*(y+1)*(z+1));
a = 1;

count = 1;
for k = 1:z+1
    for j = 1:y+1
        for i = 1:x+1

            point1{i,j,k} = Point3D(i,j,k,a);
            
            %赋值X平面
            if(k>1)&&(j>1) %y-z-
                point1{i,j,k}.x1 = count;
                pointline(1,a) = count;
                count = count+1;
                
            end
            if(k>1)&&(j<y+1) %y+z-
                point1{i,j,k}.x2= count;
                pointline(2,a) = count;
                count = count+1;
            end
            if(k<z+1)&&(j>1)%y-z+
                point1{i,j,k}.x3 = count;
                pointline(3,a) = count;
                count = count+1;
            end
            if(k<z+1)&&(j<y+1)%y+z+
                point1{i,j,k}.x4 = count;
                pointline(4,a) = count;
                count = count+1;
            end
            %赋值Y平面
            if(k>1)&&(i>1)%x-z-
                point1{i,j,k}.y1 = count;
                pointline(5,a) = count;
                count = count+1;
            end
            if(i<x+1)&&(k>1)%x+z-
                point1{i,j,k}.y2 = count;
                pointline(6,a) = count;
                count = count+1;
            end
            if(i>1)&&(k<z+1)%z+x-
                point1{i,j,k}.y3= count;
                pointline(7,a) = count;
                count = count+1;
            end
            if(k<z+1)&&(i<x+1)%x+z+
                point1{i,j,k}.y4 = count;
                pointline(8,a) = count;
                count = count+1;
            end

            %赋值Z平面
            if(i>1)&&(j>1)%x-y-
                point1{i,j,k}.z1 = count;
                pointline(9,a) = count;
                count = count+1;
            end
            if(j>1)&&(i<x+1)%x+y-
                point1{i,j,k}.z2= count;
                pointline(10,a) = count;
                count = count+1;
            end
            if(j<y+1)&&(i>1)%x-y+
                point1{i,j,k}.z3 = count;
                pointline(11,a) = count;
                count = count+1;
            end
            if(i<x+1)&&(j<y+1)%x+y+
                point1{i,j,k}.z4 = count;
                pointline(12,a) = count;
                count = count+1;
            end
           
            %disp(point{i,j,k})
            a = a+1;
        end
    end
end
M = pointline;