
function   [phimatrix_p1, t3gb,alleigval1,allratio1,basismap1]=compute3g_basis(Nx,Ny,Nz,N1,n1,n,nx,ny,nz,basismap,na,vol,hx1,hx2,lambda,mu,allbasis,nmaxbasis1,nmaxbasis,eigvalue_tol1,regvalue)
disp('compute 3g basis...');
t3gb=tic;
np=(n1+1)^3;nface=(n1+1)*n1*n1*3;nvdof=4*nface;
Nx1=N1;Ny1=N1;Nz1=N1;
Ncb=Nx1*Ny1*Nz1;
 allbasis1=cell(Ncb,1);
   alllocallambda=cell(Ncb,1);
 alllocalmu=cell(Ncb,1);
  allcc=reshape(1:Nx*Ny*Nz,Ny,Nz,Nx);
  allcdof=cell(Ncb,1);
  allbasislocal=cell(na^3,Ncb);
 localbasismapcell=cell(Ncb,1);
 allic=cell(Ncb,1);
 cumbasismap=cumsum(basismap(:));
p_dof=reshape(1:nx*ny*nz,nx,ny,nz);
iie=1;
for ii3=1:Nz1
    for ii2=1:Ny1
        for ii1=1:Nx1
 
 global_p_dof=p_dof((ii1-1)*n1+1:ii1*n1,(ii2-1)*n1+1:ii2*n1,(ii3-1)*n1+1:ii3*n1);global_p_dof=global_p_dof(:);   
  alllocallambda{iie}=lambda(global_p_dof);
    alllocalmu{iie}=mu(global_p_dof);

   ic= allcc( (ii1-1)*na+1:ii1*na,(ii2-1)*na+1:ii2*na,(ii3-1)*na+1:ii3*na);
   localbasismap=basismap( (ii1-1)*na+1:ii1*na,(ii2-1)*na+1:ii2*na,(ii3-1)*na+1:ii3*na);
  ic=ic(:);localbasismap=localbasismap(:);

allic{iie}=ic;
allbasislocal(:,iie)= allbasis(ic);   
 localbasismapcell{iie}= localbasismap;   
 iie=iie+1;
        end
    end

end

[nodedge,~,facex1,facex2,facey1,facey2,facez1,facez2,nodedof]=local2globaldof3d_inveli_elastic(n1,n1,n1);
 bddof=[facex1(:);facex2(:);facey1(:);facey2(:);facez1(:);facez2(:)];%Aaug1(bddof,:)=0;
localne=n1^3;nlocale=localne;
 [map,ir1,ic1,localA12]=assemble_Ass3d_part1(localne,nodedge);
[ir,ic,localsr]=assemble_Asr3d_continuous_part1(n1,n1,n1,localne,map,vol,np,nodedge);
Asp=assembleAsp3d(map,hx1,hx2,localne,nodedge,np,nvdof);
 D=sparse(3*localne+3*np,3*localne+3*np);allratio1=zeros(Ncb,1);

alleigval1=cell(Nz1*Ny1*Nx1,1);
basismap1=zeros(Nz1*Ny1*Nx1,1);

% disp('compute gms gms basis, with adaptive selection of eigenbasis step2...');
% parfor iie=1:Nz1*Ny1*Nx1
parfor iie=1:Nz1*Ny1*Nx1    
localiivalue=allbasislocal(:,iie);
localbasismap= localbasismapcell{iie};
localsnap=assemblephimatrix_elastic(localbasismap,na,na,na,n,localiivalue);


      locallambda=alllocallambda{iie};
   localmu= alllocalmu{iie};
    locallambda_bar=- locallambda./(2* localmu.*(3* locallambda+2* localmu));
 localmu_bar=1/2./( localmu);
masscoeff=zeros(nlocale*3,1);
masscoeff(1:nlocale)=locallambda(:)+2*localmu(:);
masscoeff(1+nlocale:nlocale*2)=1*locallambda(:)+2*localmu(:);
masscoeff(1+2*nlocale:end)=1*locallambda(:)+2*localmu(:);

    Ars=sparse(ir,ic,localsr*  localmu_bar',3*nvdof,3*np+3*localne);
 invAss=assemble_Ass3d_part2( localmu_bar+locallambda_bar,  localmu_bar,locallambda_bar,ir1,ic1,localne,nodedge,vol,localA12,np,nodedof);
        Aaug1=Ars+Asp;Aaug1(bddof,:)=0;
  [Aeli]=eli_matrix0(invAss,Aaug1,D);
invArr=1./diag(Aeli(1:3*np,1:3*np));
D2=Aeli(3*np+1:end,3*np+1:end); Aaug=Aeli(1:3*np,3*np+1:end);
 % Aeig=-eli_matrix0(invArr',Aaug,D2);
 Aeig=-eli_matrix0(sparse(1:length(invArr),1:length(invArr),invArr),Aaug,D2);
Meig=2*sparse(1:3*localne,1:3*localne,masscoeff)*hx1;
Aeig=Aeig+Aeig.';
localAeli0=Aeig+regvalue*diag(diag(Aeig));
Meig=Meig+regvalue*diag(diag(Meig));


Aeig=localsnap*localAeli0*localsnap';
Meig=localsnap*Meig*localsnap';
Aeig=Aeig+regvalue*diag(diag(Aeig));Meig=Meig+regvalue*diag(diag(Meig));
Aeig=Aeig+Aeig.';Meig=Meig+Meig';

dimeigc=size(Aeig,1);
%  [eigfun,eigvalue]=eigs(Aeig,Meig,min(dimeigc,nmaxbasis1+1),'sm');
[eigfun,eigvalue]=eig(full(Aeig),full(Meig));

 [d, order] = sort(diag(eigvalue), 'ascend'); %d=d(1:min(dimeigc,nmaxbasis1+1));
        eigfun=eigfun(:,order);eigvalue=eigvalue(:,order);
        thredhold=find(d>=eigvalue_tol1);%% adaptive local number of basis
       if size(thredhold,2)*size(thredhold,1)==0  %%%% all eigvalue less than tolerance
        nlocalbasis=nmaxbasis1;
       else
       nlocalbasis=thredhold(1)-1;
       end 
% nlocalbasimin(nlocalbasis,size(eigfun,2));
       basis=eigfun(:,1:nlocalbasis);
       basismap1(iie)=size(basis,2);
alleigval1{iie}=diag(eigvalue);
allbasis1{iie}=basis;
allcdof{iie}=getlocalid1(localbasismap,cumbasismap,allic{iie});
% % allcdof{iie}=getlocalid(localbasismap,basismap,allic{iie});
allratio1(iie)=max(locallambda)/min(locallambda);
end

% disp('compute gms gms basis, with adaptive selection of eigenbasis step3...');
dim_pc=sum(basismap1(:));
ix=ones(dim_pc,na^3*nmaxbasis);ivalue=zeros(dim_pc,na^3*nmaxbasis);
% iy=repmat((1:dim_pc)',1,n^3);
iy=(1:dim_pc)'*ones(1,na^3*nmaxbasis);
ind=1;iie=1;
for ii3=1:Nx1
    for ii2=1:Ny1
        for ii1=1:Nx1
   
    basis=allbasis1{iie};
    nlocal_basis=basismap1(iie);
% %     allbasis(:,1:nlocal_basis,iie)=basis; 
    ivalue(ind:ind+nlocal_basis-1,1:size(basis,1))=basis';   
    global_p_dof= allcdof{iie};
    ix(ind:ind+nlocal_basis-1,1:size(basis,1))= repmat( global_p_dof,1,nlocal_basis)';
%     ix(ind:ind+nlocal_basis-1,:)=  (global_p_dof*ones(1,nlocal_basis))';
ind=ind+nlocal_basis; 
iie=iie+1;
        end
    end
end
% iy=(1:dim_pc)'*ones(1,size(ix,2));

% if max(imag(allbasis(:)))>10^(-8)
%     disp('complex eigenfunction')
% end
% clear allbasis
disp('assembling coarse matrix...')
clear alllocal_pdof allbasis p_dof
  phimatrix_p1=sparse(iy,ix,ivalue,dim_pc,sum(basismap(:)));clear ix iy ivalue
 fprintf('3grid basis number is %d~%d\n',min(basismap1(:)),max(basismap1(:)) );
 fprintf('dim are %d %d\n',dim_pc,sum(basismap(:)) );
 fprintf('average coarse basis number is %2.2f\n',dim_pc/(Nx1*Ny1*Nz1));
 t3gb=toc(t3gb);
 fprintf('time of 3g basis is %2.1f seconds\n',t3gb);
  disp('..................')