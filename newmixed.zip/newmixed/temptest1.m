%%%% basis are the same as rt0, all vector basis are (1,0) or (0,1), no
%%%% negative, no stress elimination
%%% (x,y,z)
%%%% discontinuous rotation
%%%% uexact=sin(x)*sin(y)*sin(z);in [0,pi]^2
clear;
close all
nx1=4*2;nx2=nx1;nx3=nx1;nx=nx1;ny=nx2;nz=nx3;
Lx1=pi;Lx2=pi;Lx3=pi;ne=nx1*nx2*nx3;hx1=Lx1/nx1;hx2=Lx2/nx2;hx3=Lx3/nx3;vol=hx1*hx2*hx3;np=(nx1+1)*(nx2+1)*(nx3+1);
nface=(nx1+1)*nx2*nx3+(nx2+1)*nx1*nx3+(nx3+1)*nx1*nx2;nvdof=4*nface;hx=hx1;hy=hx2;hz=hx3;
[nodv,facex1,facex2,facey1,facey2,facez1,facez2]=local2globaldof3d(nx,ny,nz);

fprintf('nx is %d\n',nx);
poission_ratio=0.499149;
young_modulus=5*ones(nx1,nx2,nx3);% % depends on x
lambda=poission_ratio/((1+poission_ratio)*(1-2*poission_ratio))*young_modulus;
mu=1/2/(1+poission_ratio)*young_modulus;
lambda=lambda(:);mu=mu(:);

% lambda=0*ones(ne,1);mu=1*ones(ne,1);


s=lambda(1,1);t=mu(1,1);
lambda_bar=-lambda./(4*mu.*(lambda+mu));
mu_bar=1/2./(mu);
fprintf('s over t is %2.2f\n',s/t);
lambdabar_mubar=lambda_bar+mu_bar;
%% (As,s) matrix
Ass11=sparse(nodv,nodv,[ones(8,1)*lambdabar_mubar';ones(8,1)*mu_bar';ones(8,1)*mu_bar'])*vol/8;
Ass22=sparse(nodv,nodv,[ones(8,1)*mu_bar';ones(8,1)*lambdabar_mubar';ones(8,1)*mu_bar'])*vol/8;
Ass33=sparse(nodv,nodv,[ones(8,1)*mu_bar';ones(8,1)*mu_bar';ones(8,1)*lambdabar_mubar'])*vol/8;

ir1=zeros( (3*6*4)^2,ne);%%%3：3d，6，6 faces, 4, each face 4 dof
ic1=zeros( (3*6*4)^2,ne);
localA12=zeros(72,72);
for i=1:8
localA12(i,i+32)=1;
localA12(i,i+32*2)=1;
end
for i=1+32:8+32
localA12(i,i+32)=1;
localA12(i,i-32)=1;
end
for i=1+32*2:8+32*2
localA12(i,i-32*2)=1;
localA12(i,i-32)=1;
end

id=1;
nodedge=zeros(72,ne);
for i3=1:nx3
  for i2=1:nx2
    for i1=1:nx1
localedof=[nodv(:,id);nodv(:,id)+nvdof;nodv(:,id)+2*nvdof];
nodedge(:,id)=localedof;
ir1(:,id)=repmat(localedof,72,1);
temp=repmat(localedof,1,72);temp=temp';ic1(:,id)=temp(:);
id=id+1;
    end
  end
end
Ass=[Ass11,sparse(nvdof,nvdof),sparse(nvdof,nvdof);
    sparse(nvdof,nvdof), Ass22,sparse(nvdof,nvdof);
    sparse(nvdof,nvdof),sparse(nvdof,nvdof), Ass33;]+0*sparse(ir1,ic1,localA12(:)*lambda_bar'*vol/8);
% tic;a=Ass\speye(size(Ass,1));toc
% return
%% stress and rotation

localsr=zeros(72,3);
for i=9:16;localsr(i,3)=-1;end
for i=17:24;localsr(i,2)=-1;end
for i=25:32;localsr(i,3)=1;end
for i=41:48;localsr(i,1)=-1;end
for i=49:56;localsr(i,2)=1;end
for i=57:64;localsr(i,1)=1;end

localsr=localsr*vol/8;
allrdof=reshape(1:(nx+1)*(ny+1)*(nz+1),nx+1,ny+1,nz+1);
ir=zeros(72*3,ne);
ic=zeros(72*3,ne);
id=1;
for i3=1:nx3
  for i2=1:nx2
    for i1=1:nx1
localedof=nodedge(:,id); ir(:,id)=repmat(localedof,3,1);
localrdof=[id,id+ne,id+2*ne];localrdof=localrdof(:);temp=repmat(localrdof,1,72);temp=temp';ic(:,id)=temp(:);

id=id+1;
    end
   end
end
Ars=sparse(ir,ic,repmat(localsr(:),1,ne));
%% stress and displacement
localsp=zeros(24,1);
for i=[1:4,9:12,17:20];localsp(i)=-1;end
for i=[1:4,9:12,17:20]+4;localsp(i)=1;end
localsp=localsp*hx1*hx2/4;
ivalue=repmat(localsp,1,ne);
ix=repmat(1:ne,24,1);
Asp0=sparse(nodv,ix,ivalue);clear ivalue ix 
Asp=[Asp0,sparse(nvdof,ne),sparse(nvdof,ne);
    sparse(nvdof,ne),Asp0,sparse(nvdof,ne);
    sparse(nvdof,ne),sparse(nvdof,ne),Asp0];
%% 
A=[Ass, Asp,Ars;
   -Asp',sparse(3*ne,3*ne+3*ne);
   Ars',sparse(3*ne,3*ne+3*ne)];
F=zeros(nvdof*3+3*ne+3*ne,1);

F(nvdof*3+1:nvdof*3+3*ne)=vol;

if 0
disp('solve linear system...')
tic;u=A\F;toc
ua1=u(nvdof*3+1+0:nvdof*3+1*ne);
ua2=u(nvdof*3+1+ne:nvdof*3+2*ne);
ua3=u(nvdof*3+1+2*ne:nvdof*3+3*ne);
imagesc3dsquare(ua1,1);title('approx u1')
imagesc3dsquare(ua2,1);title('approx u2')
imagesc3dsquare(ua3,1);title('approx u3')
end
% return
%% source
if 1

    [ye,xe,ze]=meshgrid(hx/2:hx:pi,hy/2:hy:pi,hz/2:hz:pi);%%[x,y,z]=meshgrid(0:1/5:1,0:1/4:1,0:1/3:1);
uexact1=@(x,y,z) sin(x).*sin(y).*sin(z);
uexact2=@(x,y,z) sin(x).*sin(y).*sin(z);
uexact3=@(x,y,z) sin(x).*sin(y).*sin(z);
ue2=uexact2(xe,ye,ze);ue2=ue2(:);ue3=uexact3(xe,ye,ze);ue3=ue3(:);ue1=uexact1(xe,ye,ze);ue1=ue1(:);

du1dx=@(x,y,z)  cos(x).*sin(y).*sin(z);
du1dy=@(x,y,z)  sin(x).*cos(y).*sin(z);
du1dz=@(x,y,z)  sin(x).*sin(y).*cos(z);

du2dx=@(x,y,z)  cos(x).*sin(y).*sin(z);
du2dy=@(x,y,z)  sin(x).*cos(y).*sin(z);
du2dz=@(x,y,z)  sin(x).*sin(y).*cos(z);

du3dx=@(x,y,z)  cos(x).*sin(y).*sin(z);
du3dy=@(x,y,z)  sin(x).*cos(y).*sin(z);
du3dz=@(x,y,z)  sin(x).*sin(y).*cos(z);

cigma11=@(x,y,z) (s+2*t)*du1dx+s*du2dy+s*du3dz;
cigma12=@(x,y,z) t*(du2dx)+t*(du1dy);
cigma13=@(x,y,z) t*(du3dx)+t*(du1dz);

cigma21=cigma12;cigma22=@(x,y,z) (s+2*t)*du2dy+s*du1dx+s*du3dz;
cigma23=@(x,y,z) t*(du2dz+du3dy);

cigma31=cigma13;cigma32=cigma23;
cigma33=@(x,y,z) (s+2*t)*du3dz+s*du1dx+s*du2dy;

cigma11=@(x,y,z) (s+2*t)*cos(x).*sin(y).*sin(z)+s*sin(x).*cos(y).*sin(z)+s*sin(x).*sin(y).*cos(z);
cigma12=@(x,y,z) t*(cos(x).*sin(y).*sin(z))+t*(sin(x).*cos(y).*sin(z));
cigma13=@(x,y,z) t*(cos(x).*sin(y).*sin(z))+t*(sin(x).*sin(y).*cos(z));

f1=@(x,y,z) (s+2*t)*(-sin(x)).*sin(y).*sin(z)+s*cos(x).*cos(y).*sin(z)+s*cos(x).*sin(y).*cos(z)+...%% dx
            t*(cos(x).*cos(y).*sin(z))+t*(sin(x).*(-sin(y)).*sin(z))+...%% dy
            t*(cos(x).*sin(y).*cos(z))+t*(sin(x).*sin(y).*(-sin(z)));%% dz

cigma21=cigma12;cigma22=@(x,y,z) (s+2*t)*sin(x).*cos(y).*sin(z)+s*cos(x).*sin(y).*sin(z)+s*sin(x).*sin(y).*cos(z);
cigma23=@(x,y,z) t*(sin(x).*sin(y).*cos(z)+sin(x).*cos(y).*sin(z));

f2=@(x,y,z)  t*(-sin(x).*sin(y).*sin(z))+t*(cos(x).*cos(y).*sin(z))+...%% dx
            (s+2*t)*sin(x).*(-sin(y)).*sin(z)+s*cos(x).*cos(y).*sin(z)+s*sin(x).*cos(y).*cos(z)+...%% dy
            t*(sin(x).*sin(y).*(-sin(z))+sin(x).*cos(y).*cos(z));%% dy

cigma31=cigma13;cigma32=cigma23;
cigma33=@(x,y,z) (s+2*t)*sin(x).*sin(y).*cos(z)+s*cos(x).*sin(y).*sin(z)+s*sin(x).*cos(y).*sin(z);

f3=@(x,y,z) t*((-sin(x)).*sin(y).*sin(z))+t*(cos(x).*sin(y).*cos(z))+...%% dx
            t*(sin(x).*cos(y).*cos(z)+sin(x).*(-sin(y)).*sin(z))+...%% dy
             (s+2*t)*sin(x).*sin(y).*(-sin(z))+s*cos(x).*sin(y).*cos(z)+s*sin(x).*cos(y).*cos(z);

F1=f1(xe,ye,ze);F2=f1(xe,ye,ze);F3=f1(xe,ye,ze);
F(3*nvdof+1:3*nvdof+3*ne)=-[F1(:);F2(:);F3(:)]*vol;
end
disp('solve linear system...')
tic;u=A\F;toc

%% post
ua1=u(nvdof*3+1+0:nvdof*3+1*ne);
ua2=u(nvdof*3+1+ne:nvdof*3+2*ne);
ua3=u(nvdof*3+1+2*ne:nvdof*3+3*ne);
rnorm(ua1,ue1);rnorm(ua2,ue2);rnorm(ua3,ue3);
ua=sqrt(ua1.^2+ua2.^2+ua3.^2);ue=sqrt(ue1.^2+ue2.^2+ue3.^2);
% imagesc3dsquare(ue2(:),0);title('exact u2');imagesc3dsquare(ua2,0);title('approx u2')
imagesc3dsquare(ue(:),0);title('exact u');imagesc3dsquare(ua,0);title('approx u')

diff=sqrt(ua1.^2+ua3.^2+ua2.^2)-sqrt(ue1.^2+ue3.^2+ue2.^2);
exact=sqrt(ue1.^2+ue3.^2+ue2.^2);
Mass=vol*speye(ne);
err=sqrt(diff'*Mass*diff);
rerr=sqrt(diff'*Mass*diff)/sqrt(exact'*Mass*exact);
fprintf('size is %d\n',nx)
fprintf('relative error and error of displacement are %2.4e %2.4e\n',norm(diff)/norm(exact),sqrt(sum(diff.^2)*vol) );
