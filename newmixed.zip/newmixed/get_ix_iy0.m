function [ix,iy]=get_ix_iy0(nov)


total_deg=size(nov,1);
ix=repmat(nov,total_deg,1);
temp_y=repmat(nov(:),1,total_deg);
iy=temp_y';iy=iy(:);clear temp_y 
iy=reshape(iy,total_deg^2,size(nov,2));
