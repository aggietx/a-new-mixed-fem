
function  [phimatrix_pa,alleigval,tb,basismap,iivaluepcell,allratio]=assemble_gms2d_elastic_stresseli(Nx,Ny,n,lambda,mu,eigvalue_tol,...
    regvalue,nmaxbasis,localA12,localA11a,localA11b,localA22a,localA22b,mu_bar)


disp('generate 2d gms basis...')

nx=Nx*n;ny=Ny*n;ne=nx*ny;h=1/nx;vol=h^2;
basismap=nmaxbasis*ones(Ny,Nx);
% % kappa=K*10^6;
overelement=5;
ts=tic;



p_dof=reshape(1:nx*ny,ny,nx);

Ncb=Nx*Ny;

 alllocalsize=zeros(2,Ncb);
 iivaluepcell=cell(Ncb,1);
 alllocallambda=cell(Ncb,1);
 alllocalmu=cell(Ncb,1);
 alllocal_pdof=cell(Ncb,1);
alltrue_dof=cell(Ncb,1);
allmu_bar=cell(Ncb,1);
    for ii2=1:Nx
        for ii1=1:Ny
    iie=(ii2-1)*Ny+ii1;
    locallambda=lambda( max( (ii1-1)*n+1-overelement,1):min(ii1*n+overelement,ny),...
        max( (ii2-1)*n+1-overelement,1):min(ii2*n+overelement,nx));
    localmu=mu( max( (ii1-1)*n+1-overelement,1):min(ii1*n+overelement,ny),...
        max( (ii2-1)*n+1-overelement,1):min(ii2*n+overelement,nx));    
[localny,localnx]=size(locallambda);
    alllocalsize(:,iie)=[localny,localnx];
             global_p_dof=p_dof( (ii1-1)*n+1:ii1*n,(ii2-1)*n+1:ii2*n);

global_p_dofov=p_dof( max( (ii1-1)*n+1-overelement,1):min(ii1*n+overelement,ny),...
        max( (ii2-1)*n+1-overelement,1):min(ii2*n+overelement,nx));
global_p_dofov=global_p_dofov(:);global_p_dof=global_p_dof(:);
[~,true_dof]=ismember([global_p_dof;global_p_dof+ne],[global_p_dofov;global_p_dofov+ne]);
alltrue_dof{iie}=true_dof;
alllocallambda{iie}=locallambda;
alllocalmu{iie}=localmu;
alllocal_pdof{iie}=global_p_dof;
allmu_bar{iie}=mu_bar(global_p_dofov);
        end
    end


alleigval=cell(Ncb,1);allratio=zeros(Ncb,1);
% np=(n+1)^2;
% [Aaug1,D,ir1,ic1,nodedof,bddof]=assemble2d_matrix_partb(n,n,h,h);
% Aaug1(bddof,:)=0;
parfor iie=1:Ny*Nx
% for iie=1:Ny*Nx
% localny=n;
% localnx=n;
locallambda=alllocallambda{iie};
[localny,localnx]=size(locallambda);
nlocale=localnx*localny;
localmu_bar=allmu_bar{iie};
np=(localnx+1)*(localny+1);
[Aaug1,D,ir1,ic1,nodedof,bddof]=assemble2d_matrix_partb(localnx,localny,h,h,localmu_bar);
Aaug1(bddof,:)=0;

localmu=alllocallambda{iie};
masscoeff=zeros(nlocale*2,1);
masscoeff(1:nlocale)=locallambda(:)+2*localmu(:);
masscoeff(1+nlocale:end)=1*locallambda(:)+2*localmu(:);

[invAss,~]=assemble2d_matrix_parta(localnx,localny,h,h,locallambda,localmu,localA12,localA11a,localA11b,localA22a,localA22b,ir1,ic1,nodedof);

Aeli=eli_matrix0(invAss,Aaug1,D);
invArr=1./diag(Aeli(1:np,1:np));
D2=Aeli(np+1:end,np+1:end); Aaug=Aeli(1:np,np+1:end);
Aeig=-eli_matrix0(invArr',Aaug,D2);
Meig=2*sparse(1:2*nlocale,1:2*nlocale,masscoeff)*h;
Aeig=Aeig+Aeig.';
Aeig=Aeig+regvalue*diag(diag(Aeig));
Meig=Meig+regvalue*diag(diag(Meig));


% Meig=sparse(1:2*nlocale,1:2*nlocale,diag(Aeig));

% [eigfun,eigvalue]=eigs(Aeig,Meig,nmaxbasis,'sm');
[eigfun,eigvalue]=eig(full(Aeig),full(Meig));

[d, order] = sort((diag(eigvalue)), 'ascend'); 
% eigfun(1:20,:)
% diag(eigvalue)

% if max(abs(imag(eigfun(:))))>10^(-6)
%     max(abs(imag(eigfun(:))))
%     disp('complex eigvalue, error');
% end
true_dof=alltrue_dof{iie};

        eigfun=eigfun(true_dof,order);eigvalue=eigvalue(:,order);
        thredhold=find(d>=eigvalue_tol);%% adaptive local number of basis
       if size(thredhold,2)*size(thredhold,1)==0  %%%% all eigvalue less than tolerance
        nlocalbasis=nmaxbasis;
       else
       nlocalbasis=thredhold(1);
       end 
       basis=eigfun(:,1:nlocalbasis);
%       if 1
% basis=scalar2vector(basis);
%       end

       basismap(iie)=size(basis,2);
alleigval{iie}=diag(eigvalue);
iivaluepcell{iie}=basis;
allratio(iie)=max(locallambda)/min(locallambda);
end

dim_pc=sum(basismap(:));
ixp=zeros(dim_pc,2*n^2);
ivaluep=zeros(dim_pc,2*n^2);
iyp=(1:dim_pc)'*ones(1,2*n^2);
ind=1;

    for ii2=1:Nx
        for ii1=1:Ny
    iie=(ii2-1)*Ny+ii1;
    basis=iivaluepcell{iie};
    nlocal_basis=basismap(iie);
    ivaluep(ind:ind+nlocal_basis-1,:)=basis';   
    global_p_dof=alllocal_pdof{iie};

   global_p_dof=[global_p_dof(:);global_p_dof(:)+ne];
global_p_dof=sort( global_p_dof(:));

    ixp(ind:ind+nlocal_basis-1,:)= repmat( global_p_dof,1,nlocal_basis)';
ind=ind+nlocal_basis;  
        end
    end

% if max(imag(allbasis(:)))>10^(-8)
%     disp('complex eigenfunction')
% end
% return
disp('assembling coarse matrix...')
clear alllocal_pdof allbasis p_dof
 phimatrix_pa=sparse(iyp,ixp,ivaluep,dim_pc,ne*2);clear ixp iyp ivaluep
 fprintf('dim of are %d %d\n',dim_pc,ne);
 fprintf('average basis number is %2.2f\n',dim_pc/(Nx*Ny));
 disp('END of generating gms basis')
 tb=toc(ts);
  fprintf('Tbasis is %2.2f seconds\n',tb);