
function  [phimatrix_pa,tb]=assemble_3dphi(Nx,Ny,Nz,n,dis)


disp('generate 3d homogeneous basis...')

nx=Nx*n;ny=Ny*n;nz=Nz*n;ne=nx*ny*nz;
basismap=3*ones(Nx,Ny,Nz);

ts=tic;



p_dof=reshape(1:nx*ny*nz,nx,ny,nz);

Ncb=Nx*Ny*Nz;

 iivaluepcell=cell(Ncb,1);
 alllocal_pdof=cell(Ncb,1);
id=1;
for ii3=1:Nz
    for ii2=1:Ny
        for ii1=1:Nx
    

global_p_dof=p_dof( (ii1-1)*n+1:ii1*n,(ii2-1)*n+1:ii2*n,(ii3-1)*n+1:ii3*n);
 alllocal_pdof{id}=global_p_dof(:);
id=id+1;

        end
    end
end


for iie=1:Ncb

      
basis=zeros(3*n^3,3);
basis(1:n^3,1)=1;basis(1+n^3:n^3*2,2)=1;basis(1+n^3*2:n^3*3,3)=1;
iivaluepcell{iie}=basis;
end

dim_pc=sum(basismap(:));
ixp=zeros(dim_pc,3*n^3);
ivaluep=zeros(dim_pc,3*n^3);
iyp=(1:dim_pc)'*ones(1,3*n^3);
ind=1;
iie=1;
for ii3=1:Nz
    for ii2=1:Ny
        for ii1=1:Nx
    
    basis=iivaluepcell{iie};
    nlocal_basis=basismap(iie);
    ivaluep(ind:ind+nlocal_basis-1,:)=basis';   
    global_p_dof=alllocal_pdof{iie};

   global_p_dof=[global_p_dof(:);global_p_dof(:)+ne;global_p_dof(:)+2*ne];
global_p_dof=sort( global_p_dof(:));

    ixp(ind:ind+nlocal_basis-1,:)= repmat( global_p_dof,1,nlocal_basis)';
ind=ind+nlocal_basis;  
iie=iie+1;
        end
    end
end
% if max(imag(allbasis(:)))>10^(-8)
%     disp('complex eigenfunction')
% end
% return
disp('assembling coarse matrix...')
clear alllocal_pdof allbasis p_dof
if dis
     phimatrix_pa=sparse(iyp,ixp,ivaluep,dim_pc*2,ne*3+3*ne)+...
         sparse(iyp+dim_pc,ixp+3*ne,ivaluep,dim_pc*2,ne*3+3*ne);
else
 phimatrix_pa=sparse(iyp,ixp,ivaluep,dim_pc,ne*3);
end
%  fprintf('dim of are %d %d\n',dim_pc,ne);
%  fprintf('average basis number is %2.2f\n',dim_pc/(Nx*Ny*Nz));

 clear ixp iyp ivaluep
 disp('END of generating constant basis')
 tb=toc(ts);
  fprintf('Tbasis is %2.2f seconds\n',tb);
  disp('........')